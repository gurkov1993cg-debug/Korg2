#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Evidence {
    std::string kind;
    std::string value;
    int weight = 0;
};

struct Candidate {
    std::string name;
    int score = 0;
    std::string confidence;
    std::vector<Evidence> evidence;
};

struct EmbeddedObject {
    std::string type;
    std::uint64_t offset = 0;
    std::string note;
};

struct KorgModelHit {
    std::string family;
    std::string model;
    std::string machineId;
    std::string confidence;
    std::string evidence;
};

struct AnalysisResult {
    std::string path;
    std::uint64_t size = 0;
    std::string format = "Unknown / raw";
    std::string architecture = "Unknown";
    std::string endian = "Unknown";
    int bits = 0;
    std::vector<Candidate> languages;
    std::vector<Candidate> toolchains;
    std::vector<Candidate> platforms;
    std::vector<EmbeddedObject> embedded;
    std::vector<KorgModelHit> korgModels;
    std::vector<std::string> notes;
};
