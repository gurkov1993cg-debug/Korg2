#include "core/Analyzer.h"
#include "core/Utils.h"
#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include <algorithm>
#include <iostream>

AnalysisResult Analyzer::analyzeFile(const std::string& path) {
    const auto data = readFile(path);
    AnalysisResult r;
    r.path = path;
    r.size = data.size();
    FormatDetector::analyze(data,r);
    LanguageDetector::analyze(data,r);
    KorgDetector::analyze(data,r);
    return r;
}

namespace {
void printCandidates(const char* title, const std::vector<Candidate>& v) {
    std::cout << "\n" << title << ":\n";
    if (v.empty()) { std::cout << "  Unknown\n"; return; }
    const std::size_t max = std::min<std::size_t>(v.size(),5);
    for (std::size_t i=0;i<max;++i) {
        const auto& c=v[i];
        std::cout << "  " << c.name << "  score=" << c.score << "  [" << c.confidence << "]\n";
        const std::size_t evmax = std::min<std::size_t>(c.evidence.size(),4);
        for (std::size_t j=0;j<evmax;++j)
            std::cout << "    - " << c.evidence[j].kind << ": " << c.evidence[j].value << " (+" << c.evidence[j].weight << ")\n";
    }
}

void jsonCandidates(const std::vector<Candidate>& v) {
    std::cout << "[";
    for (std::size_t i=0;i<v.size();++i) {
        if (i) std::cout << ",";
        const auto& c=v[i];
        std::cout << "{\"name\":\"" << jsonEscape(c.name) << "\",\"score\":" << c.score
                  << ",\"confidence\":\"" << jsonEscape(c.confidence) << "\",\"evidence\":[";
        for (std::size_t j=0;j<c.evidence.size();++j) {
            if (j) std::cout << ",";
            const auto& e=c.evidence[j];
            std::cout << "{\"kind\":\"" << jsonEscape(e.kind) << "\",\"value\":\"" << jsonEscape(e.value)
                      << "\",\"weight\":" << e.weight << "}";
        }
        std::cout << "]}";
    }
    std::cout << "]";
}
}

void Analyzer::printReport(const AnalysisResult& r) {
    std::cout << "KORG RE LAB v0.2 - static fingerprint report\n";
    std::cout << "File: " << r.path << "\nSize: " << r.size << " bytes\n";
    std::cout << "Format: " << r.format << "\nArchitecture: " << r.architecture;
    if (r.bits) std::cout << " (" << r.bits << "-bit)";
    std::cout << "\nEndian: " << r.endian << "\n";

    printCandidates("Source-language/runtime candidates", r.languages);
    printCandidates("Compiler/toolchain candidates", r.toolchains);
    printCandidates("Platform/ABI candidates", r.platforms);

    std::cout << "\nKorg model candidates:\n";
    if (r.korgModels.empty()) std::cout << "  Unknown / no proven model signature\n";
    for (const auto& m : r.korgModels)
        std::cout << "  " << m.family << " / " << m.model << "  " << m.machineId << "  [" << m.confidence << "]\n"
                  << "    - " << m.evidence << "\n";

    std::cout << "\nEmbedded objects:\n";
    if (r.embedded.empty()) std::cout << "  none recognized\n";
    for (const auto& e:r.embedded) std::cout << "  " << hexOffset(e.offset) << "  " << e.type << "  - " << e.note << "\n";

    std::cout << "\nAnalysis notes:\n";
    if (r.notes.empty()) std::cout << "  none\n";
    for (const auto& n:r.notes) std::cout << "  - " << n << "\n";
    std::cout << "\nConfidence rule: evidence is reported as Detected/Probable/Possible; unknown stays unknown.\n";
}

void Analyzer::printJson(const AnalysisResult& r) {
    std::cout << "{\"version\":\"0.2\",\"path\":\"" << jsonEscape(r.path) << "\",\"size\":" << r.size
              << ",\"format\":\"" << jsonEscape(r.format) << "\",\"architecture\":\"" << jsonEscape(r.architecture)
              << "\",\"bits\":" << r.bits << ",\"endian\":\"" << jsonEscape(r.endian) << "\",";
    std::cout << "\"languages\":"; jsonCandidates(r.languages); std::cout << ",\"toolchains\":"; jsonCandidates(r.toolchains);
    std::cout << ",\"platforms\":"; jsonCandidates(r.platforms);
    std::cout << ",\"korg_models\":[";
    for (std::size_t i=0;i<r.korgModels.size();++i) {
        if (i) std::cout << ",";
        const auto& m=r.korgModels[i];
        std::cout << "{\"family\":\"" << jsonEscape(m.family) << "\",\"model\":\"" << jsonEscape(m.model)
                  << "\",\"machine_id\":\"" << jsonEscape(m.machineId) << "\",\"confidence\":\""
                  << jsonEscape(m.confidence) << "\",\"evidence\":\"" << jsonEscape(m.evidence) << "\"}";
    }
    std::cout << "],\"embedded\":[";
    for (std::size_t i=0;i<r.embedded.size();++i) {
        if (i) std::cout << ",";
        const auto& e=r.embedded[i];
        std::cout << "{\"type\":\"" << jsonEscape(e.type) << "\",\"offset\":" << e.offset
                  << ",\"note\":\"" << jsonEscape(e.note) << "\"}";
    }
    std::cout << "],\"notes\":[";
    for (std::size_t i=0;i<r.notes.size();++i) {
        if (i) std::cout << ",";
        std::cout << "\"" << jsonEscape(r.notes[i]) << "\"";
    }
    std::cout << "]}\n";
}
