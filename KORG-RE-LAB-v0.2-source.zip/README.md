# KORG RE LAB

KORG RE LAB is a Korg-focused reverse-engineering and firmware-research framework. The project is designed for the **whole Korg product range**, not for only two models. KRONOS and Pa600 are useful research examples, but the architecture must remain model-independent.

The first target host is an **Intel iMac 2011 running macOS High Sierra 10.13.6**, so the core stays native C++14 and avoids mandatory heavy runtime dependencies.

## Current milestone — v0.2 core

- detects ELF, PE/COFF, Mach-O, Java class, DEX, WASM, ZIP-like containers, scripts, Lua bytecode, BEAM, gzip, SquashFS and CPIO;
- detects common CPU families including x86/x86_64, ARM/AArch64, MIPS, PowerPC, SuperH, SPARC and RISC-V;
- confidence-based source-language/runtime fingerprinting;
- compiler/toolchain fingerprinting including GCC, Clang/LLVM, Apple Clang, MSVC, Intel, ARM, IAR, Green Hills, CodeWarrior, Borland, Watcom, TinyCC and language-specific toolchains;
- Linux/U-Boot/ARM-EABI/BusyBox/Qt platform clues;
- Korg-specific model signature database kept separate from the generic analysis core;
- first-pass Korg package structure scanning and embedded object discovery;
- machine-readable `--json` output for the future GUI and automated diff engine;
- unit tests and GitHub Actions CI.

## Scope

The model database and research tree will cover, as evidence becomes available:

- Professional Arranger: Pa-series and related products;
- Workstations: Triton, M3/M50, Krome, Kross, OASYS, KRONOS, Nautilus and related platforms;
- other Korg synth/workstation families when their firmware, file formats or hardware architecture share useful technology.

**Important:** scope is broad, but a model is not marked as technically understood until there is evidence. Unknown stays unknown.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

On macOS the project sets a minimum deployment target of 10.13.

Run:

```sh
./build/korg-re-lab /path/to/firmware.pkg
./build/korg-re-lab --json /path/to/binary
```

## Roadmap

1. Full Korg PKG chunk parser with checksums and safe extraction.
2. Recursive analysis: package -> kernel/rootfs -> every executable/script separately.
3. ELF sections, symbols, imports, dynamic metadata, `.comment`, build IDs and DWARF.
4. External signature packs so language/compiler support can grow without rebuilding the app.
5. Disassembly and function discovery for ARM/x86 and additional CPU families found in Korg hardware.
6. OS-to-OS structural and function diff.
7. Cross-model feature dependency graph and compatibility classification.
8. Native AppKit GUI for the Intel iMac 2011.
9. Safe experimental patch/repack pipeline only after package integrity/recovery behavior is understood.

See `docs/ARCHITECTURE.md`, `docs/DETECTION_MODEL.md`, and `docs/MODEL_COVERAGE.md`.
