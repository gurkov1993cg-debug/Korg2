#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

static std::vector<std::uint8_t> bytes(const std::string& s) {
    return std::vector<std::uint8_t>(s.begin(), s.end());
}

static void expect(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}

static bool hasCandidate(const std::vector<Candidate>& v, const std::string& name) {
    for (const auto& c : v) if (c.name == name) return true;
    return false;
}

int main() {
    {
        std::vector<std::uint8_t> d(64,0);
        d[0]=0x7f; d[1]='E'; d[2]='L'; d[3]='F'; d[4]=1; d[5]=1; d[18]=40; d[19]=0;
        AnalysisResult r;
        FormatDetector::analyze(d,r);
        expect(r.format == "ELF", "ARM sample should be ELF");
        expect(r.architecture == "ARM", "ELF e_machine 40 should be ARM");
        expect(r.bits == 32, "ELF class 1 should be 32-bit");
        expect(r.endian == "Little", "ELF data 1 should be little endian");
    }
    {
        auto d = bytes("prefix __cxa_throw GLIBCXX_ GCC: (GNU) suffix");
        AnalysisResult r; r.format="ELF";
        LanguageDetector::analyze(d,r);
        expect(hasCandidate(r.languages,"C++"), "C++ fingerprints should identify C++ candidate");
        expect(hasCandidate(r.toolchains,"GCC"), "GCC fingerprint should identify GCC candidate");
    }
    {
        auto d = bytes("Z103A /update/uImage /boot/MLO /boot/u-boot.bin KORG");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(!r.korgModels.empty(), "Pa600 machine ID should create a Korg model hit");
        expect(r.korgModels[0].model == "Pa600", "Z103A should map to Pa600");
        expect(!r.notes.empty(), "Korg package paths should create a package note");
    }
    {
        auto d = bytes("nothing identifiable here");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(r.korgModels.empty(), "unknown data must not invent a Korg model");
    }
    std::cout << "detector tests passed\n";
    return 0;
}
