#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include "korg/KorgKnowledgeBase.h"
#include "korg/UpdateDetector.h"
#include "korg/UpdParser.h"
#include "korg/pkg/PkgParser.h"
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

static std::vector<std::uint8_t> bytes(const std::string& s) {
    return std::vector<std::uint8_t>(s.begin(), s.end());
}


static void put16le(std::vector<std::uint8_t>& d, std::uint16_t v) {
    d.push_back(static_cast<std::uint8_t>(v & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 8) & 0xff));
}

static void put32le(std::vector<std::uint8_t>& d, std::uint32_t v) {
    d.push_back(static_cast<std::uint8_t>(v & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 8) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 16) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 24) & 0xff));
}

static void putCString(std::vector<std::uint8_t>& d, const std::string& s) {
    d.insert(d.end(), s.begin(), s.end());
    d.push_back(0);
}

static void putChunk(std::vector<std::uint8_t>& pkg, std::uint32_t id, const std::vector<std::uint8_t>& payload) {
    put32le(pkg,id);
    put32le(pkg,static_cast<std::uint32_t>(payload.size()));
    pkg.insert(pkg.end(),payload.begin(),payload.end());
    while (pkg.size() % 4) pkg.push_back(0);
}

static std::vector<std::uint8_t> syntheticPkg() {
    std::vector<std::uint8_t> pkg(16,0); // package MD5 placeholder
    std::vector<std::uint8_t> h;
    h.push_back(3); h.push_back(6); h.push_back(4); h.push_back(3);
    put32le(h,2);
    put16le(h,2); put16le(h,1);
    putCString(h,"103ASTD");
    putCString(h,"KORG-SW1");
    putCString(h,"WorkHorse2");
    putCString(h,"01/01/2014");
    putCString(h,"12:00");
    putCString(h,"Z103A package");
    putCString(h," user package");
    putChunk(pkg,1,h);

    std::vector<std::uint8_t> sys(16,0x11); // member MD5 placeholder
    sys.push_back(0x27); sys.push_back(0x05); sys.push_back(0x19); sys.push_back(0x56);
    sys.push_back('T'); sys.push_back('E'); sys.push_back('S'); sys.push_back('T');
    putChunk(pkg,2,sys);
    return pkg;
}


static std::vector<std::uint8_t> syntheticUpdTlv() {
    std::vector<std::uint8_t> upd(16,0xAA);

    std::vector<std::uint8_t> meta;
    put16le(meta,4); put16le(meta,0x0208); put16le(meta,4); put16le(meta,0);
    put32le(meta,0x00010002);
    putCString(meta,"103ASTD");
    putCString(meta,"KORG-SW6");
    putCString(meta,"workhorse6");
    putCString(meta,"12/17/2024");
    putCString(meta,"16.33");
    putCString(meta,"Z103A package");
    putCString(meta,"'Z103A_STD_Minimal_package'");
    putChunk(upd,0x0001,meta);

    std::vector<std::uint8_t> file(16,0x11);
    put32le(file,0);
    put16le(file,0x5000);
    put16le(file,0xffff);
    put32le(file,5);
    file.push_back(0);
    putCString(file,"/omega_sys/test.txt");
    putCString(file,"12/17/2024");
    putCString(file,"16.33");
    put32le(file,0);
    put32le(file,13);
    file.push_back(0); file.push_back(0); file.push_back(0); file.push_back(5); // BE unpacked size
    file.push_back(0x78); file.push_back(0x9c); file.push_back(0x01); file.push_back(0x00);
    putChunk(upd,0x0011,file);

    std::vector<std::uint8_t> sig = {0x01,0x00,0x30,0x06,0x02,0x01,0x01,0x02,0x01,0x02};
    putChunk(upd,0x0601,sig);
    return upd;
}

static void expect(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}

static bool hasCandidate(const std::vector<Candidate>& v, const std::string& name) {
    for (const auto& c : v) if (c.name == name) return true;
    return false;
}

int main() {
    {
        std::vector<std::uint8_t> d(64,0);
        d[0]=0x7f; d[1]='E'; d[2]='L'; d[3]='F'; d[4]=1; d[5]=1; d[18]=40; d[19]=0;
        AnalysisResult r;
        FormatDetector::analyze(d,r);
        expect(r.format == "ELF", "ARM sample should be ELF");
        expect(r.architecture == "ARM", "ELF e_machine 40 should be ARM");
        expect(r.bits == 32, "ELF class 1 should be 32-bit");
        expect(r.endian == "Little", "ELF data 1 should be little endian");
    }
    {
        auto d = bytes("prefix __cxa_throw GLIBCXX_ GCC: (GNU) suffix");
        AnalysisResult r; r.format="ELF";
        LanguageDetector::analyze(d,r);
        expect(hasCandidate(r.languages,"C++"), "C++ fingerprints should identify C++ candidate");
        expect(hasCandidate(r.toolchains,"GCC"), "GCC fingerprint should identify GCC candidate");
    }
    {
        auto d = bytes("Z103A /update/uImage /boot/MLO /boot/u-boot.bin KORG");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(!r.korgModels.empty(), "Pa600 machine ID should create a Korg model hit");
        expect(r.korgModels[0].model == "Pa600", "Z103A should map to Pa600");
        expect(!r.notes.empty(), "Korg package paths should create a package note");
    }

    {
        auto d = syntheticPkg();
        AnalysisResult r;
        const bool ok = PkgParser::analyze(d,r);
        expect(ok, "synthetic known-family Korg PKG should parse");
        expect(r.korgPkg.recognized, "PKG parser should set recognized flag");
        expect(r.korgPkg.systemType == "103ASTD", "PKG system type should be decoded");
        expect(r.korgPkg.packageType == 2, "PKG package type should be decoded little-endian");
        expect(r.korgPkg.chunks.size() == 2, "PKG parser should enumerate chunks");
        expect(r.korgPkg.chunks[1].path == "/update/uImage", "system chunk id 2 should map to update kernel path");
        expect(r.korgPkg.chunks[1].dataSize == 8, "system file payload size should exclude member MD5");
    }


    {
        auto d = syntheticUpdTlv();
        AnalysisResult r;
        const bool ok = UpdParser::analyze(d,r);
        expect(ok, "synthetic Korg UPD TLV should parse");
        expect(r.korgUpdContainer.recognized, "UPD TLV parser should set recognized flag");
        expect(r.korgUpdContainer.exactEof, "UPD TLV parser should reach EOF exactly");
        expect(r.korgUpdContainer.metaStrings.size() >= 6, "UPD metadata strings should decode");
        expect(r.korgUpdContainer.metaStrings[0] == "103ASTD", "UPD metadata should expose 103ASTD");
        expect(r.korgUpdContainer.fileCount == 1, "UPD parser should count zlib file records");
        expect(r.korgUpdContainer.signatureCount == 1, "UPD parser should count 0x06xx signatures");
        expect(r.korgUpdContainer.entries[1].path == "/omega_sys/test.txt", "UPD file path should decode");
        expect(r.korgUpdContainer.entries[1].zlibStream, "UPD file should expose zlib stream");
        expect(r.korgUpdContainer.systemType == "103ASTD", "UPD named metadata should expose system type");
        expect(r.korgUpdContainer.softwareFamily == "KORG-SW6", "UPD named metadata should expose software family");
        expect(r.korgUpdContainer.platformCode == "workhorse6", "UPD named metadata should expose platform code");
        expect(r.korgUpdContainer.tagStats.size() == 3, "UPD parser should aggregate TLV tags");
        KorgKnowledgeBase::enrichUpd(r);
        expect(!r.korgReferenceProfile.empty(), "Pa600 metadata should activate the Z103A reference profile");
        expect(!r.korgPlatformFacts.empty(), "Pa600 reference profile should add structured platform facts");
    }

    {
        auto d = bytes("random outer update data with KORG marker");
        AnalysisResult r;
        UpdateDetector::analyze("Pa600_Operating_System_v211.upd", d, r);
        expect(r.korgUpdate.recognized, "UPD extension should be recognized as Korg update family");
        expect(r.korgUpdate.extension == "UPD", "UPD extension should be reported");
        expect(r.korgUpdate.modelHint == "Pa600", "Pa600 filename should create a filename model hint");
        expect(r.korgUpdate.versionHint == "v211", "v211 filename should create a version hint");
        expect(r.format.find("Korg OS Update") != std::string::npos, "UPD should have visible update format even before internal decode");
    }

    {
        auto d = bytes("nothing identifiable here");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(r.korgModels.empty(), "unknown data must not invent a Korg model");
    }
    std::cout << "detector tests passed\n";
    return 0;
}
