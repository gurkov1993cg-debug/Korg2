#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include "korg/KorgKnowledgeBase.h"
#include "korg/UpdateDetector.h"
#include "korg/UpdParser.h"
#include "korg/pkg/PkgParser.h"
#include "reverse/ElfAnalyzer.h"
#include "reverse/ArmDisassembler.h"
#include "reverse/FirmwareExecutableScanner.h"
#include "reverse/DeviceTreeAnalyzer.h"
#include <zlib.h>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <string>
#include <vector>

static std::vector<std::uint8_t> bytes(const std::string& s) {
    return std::vector<std::uint8_t>(s.begin(), s.end());
}


static void put16le(std::vector<std::uint8_t>& d, std::uint16_t v) {
    d.push_back(static_cast<std::uint8_t>(v & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 8) & 0xff));
}

static void put32be(std::vector<std::uint8_t>& d, std::uint32_t v) {
    d.push_back(static_cast<std::uint8_t>((v >> 24) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 16) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 8) & 0xff));
    d.push_back(static_cast<std::uint8_t>(v & 0xff));
}

static void put32le(std::vector<std::uint8_t>& d, std::uint32_t v) {
    d.push_back(static_cast<std::uint8_t>(v & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 8) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 16) & 0xff));
    d.push_back(static_cast<std::uint8_t>((v >> 24) & 0xff));
}

static void putCString(std::vector<std::uint8_t>& d, const std::string& s) {
    d.insert(d.end(), s.begin(), s.end());
    d.push_back(0);
}

static void putChunk(std::vector<std::uint8_t>& pkg, std::uint32_t id, const std::vector<std::uint8_t>& payload) {
    put32le(pkg,id);
    put32le(pkg,static_cast<std::uint32_t>(payload.size()));
    pkg.insert(pkg.end(),payload.begin(),payload.end());
    while (pkg.size() % 4) pkg.push_back(0);
}

static std::vector<std::uint8_t> syntheticPkg() {
    std::vector<std::uint8_t> pkg(16,0); // package MD5 placeholder
    std::vector<std::uint8_t> h;
    h.push_back(3); h.push_back(6); h.push_back(4); h.push_back(3);
    put32le(h,2);
    put16le(h,2); put16le(h,1);
    putCString(h,"103ASTD");
    putCString(h,"KORG-SW1");
    putCString(h,"WorkHorse2");
    putCString(h,"01/01/2014");
    putCString(h,"12:00");
    putCString(h,"Z103A package");
    putCString(h," user package");
    putChunk(pkg,1,h);

    std::vector<std::uint8_t> sys(16,0x11); // member MD5 placeholder
    sys.push_back(0x27); sys.push_back(0x05); sys.push_back(0x19); sys.push_back(0x56);
    sys.push_back('T'); sys.push_back('E'); sys.push_back('S'); sys.push_back('T');
    putChunk(pkg,2,sys);
    return pkg;
}


static std::vector<std::uint8_t> syntheticUpdTlv() {
    std::vector<std::uint8_t> upd(16,0xAA);

    std::vector<std::uint8_t> meta;
    put16le(meta,4); put16le(meta,0x0208); put16le(meta,4); put16le(meta,0);
    put32le(meta,0x00010002);
    putCString(meta,"103ASTD");
    putCString(meta,"KORG-SW6");
    putCString(meta,"workhorse6");
    putCString(meta,"12/17/2024");
    putCString(meta,"16.33");
    putCString(meta,"Z103A package");
    putCString(meta,"'Z103A_STD_Minimal_package'");
    putChunk(upd,0x0001,meta);

    std::vector<std::uint8_t> file(16,0x11);
    put32le(file,0);
    put16le(file,0x5000);
    put16le(file,0xffff);
    put32le(file,5);
    file.push_back(0);
    putCString(file,"/omega_sys/test.txt");
    putCString(file,"12/17/2024");
    putCString(file,"16.33");
    put32le(file,0);
    put32le(file,13);
    file.push_back(0); file.push_back(0); file.push_back(0); file.push_back(5); // BE unpacked size
    file.push_back(0x78); file.push_back(0x9c); file.push_back(0x01); file.push_back(0x00);
    putChunk(upd,0x0011,file);

    std::vector<std::uint8_t> sig = {0x01,0x00,0x30,0x06,0x02,0x01,0x01,0x02,0x01,0x02};
    putChunk(upd,0x0601,sig);
    return upd;
}


static std::vector<std::uint8_t> syntheticDtb() {
    std::string strings;
    std::map<std::string,std::uint32_t> offsets;
    auto nameOff=[&](const std::string& n)->std::uint32_t {
        auto it=offsets.find(n); if(it!=offsets.end()) return it->second;
        const std::uint32_t o=static_cast<std::uint32_t>(strings.size()); offsets[n]=o; strings += n; strings.push_back('\0'); return o;
    };
    std::vector<std::uint8_t> st;
    auto align4=[&](){ while(st.size()%4) st.push_back(0); };
    auto begin=[&](const std::string& n){ put32be(st,1); st.insert(st.end(),n.begin(),n.end()); st.push_back(0); align4(); };
    auto endNode=[&](){ put32be(st,2); };
    auto prop=[&](const std::string& n,const std::vector<std::uint8_t>& v){ put32be(st,3); put32be(st,static_cast<std::uint32_t>(v.size())); put32be(st,nameOff(n)); st.insert(st.end(),v.begin(),v.end()); align4(); };
    auto strv=[&](const std::string& x){ std::vector<std::uint8_t> v(x.begin(),x.end()); v.push_back(0); return v; };
    auto u32v=[&](std::uint32_t x){ std::vector<std::uint8_t> v; put32be(v,x); return v; };
    auto reg2=[&](std::uint32_t a,std::uint32_t z){ std::vector<std::uint8_t> v; put32be(v,a); put32be(v,z); return v; };

    begin(""); prop("#address-cells",u32v(1)); prop("#size-cells",u32v(1)); prop("compatible",strv("ti,dra7-test"));
    begin("aliases"); prop("serial0",strv("/ocp/serial@4806a000")); prop("i2c0",strv("/ocp/i2c@48070000")); endNode();
    begin("chosen"); prop("bootargs",strv("console=ttyO0,115200 root=/dev/mmcblk0p2")); endNode();
    begin("dsp@40800000"); prop("compatible",strv("ti,dra7-dsp")); prop("status",strv("okay")); prop("reg",reg2(0x40800000,0x1000)); endNode();
    begin("mcasp@48468000"); prop("compatible",strv("ti,dra7-mcasp-audio")); prop("status",strv("okay")); prop("reg",reg2(0x48468000,0x1000)); endNode();
    begin("i2c@48070000"); prop("compatible",strv("ti,omap4-i2c")); prop("status",strv("okay")); prop("reg",reg2(0x48070000,0x1000)); prop("#address-cells",u32v(1)); prop("#size-cells",u32v(0));
      begin("tlv320aic3104@18"); prop("compatible",strv("ti,tlv320aic3104")); prop("reg",u32v(0x18)); endNode();
    endNode();
    endNode(); put32be(st,9);

    const std::uint32_t offRsv=40, rsvSize=16, offStruct=offRsv+rsvSize, offStrings=offStruct+static_cast<std::uint32_t>(st.size()), total=offStrings+static_cast<std::uint32_t>(strings.size());
    std::vector<std::uint8_t> d; d.reserve(total);
    put32be(d,0xd00dfeed); put32be(d,total); put32be(d,offStruct); put32be(d,offStrings); put32be(d,offRsv); put32be(d,17); put32be(d,16); put32be(d,0); put32be(d,static_cast<std::uint32_t>(strings.size())); put32be(d,static_cast<std::uint32_t>(st.size()));
    d.resize(offStruct,0); d.insert(d.end(),st.begin(),st.end()); d.insert(d.end(),strings.begin(),strings.end()); return d;
}

static std::vector<std::uint8_t> syntheticUpdWithArmElf() {
    std::vector<std::uint8_t> upd(16,0xAA);
    std::vector<std::uint8_t> meta;
    put16le(meta,4); put16le(meta,0x0208); put16le(meta,4); put16le(meta,0);
    put32le(meta,0x00010002);
    putCString(meta,"103ASTD"); putCString(meta,"KORG-SW6"); putCString(meta,"workhorse6");
    putCString(meta,"12/17/2024"); putCString(meta,"16.33"); putCString(meta,"Z103A package");
    putCString(meta,"'Z103A_STD_Minimal_package'");
    putChunk(upd,0x0001,meta);

    std::vector<std::uint8_t> elf(64,0);
    elf[0]=0x7f; elf[1]='E'; elf[2]='L'; elf[3]='F'; elf[4]=1; elf[5]=1; elf[6]=1;
    elf[16]=2; elf[18]=40; elf[20]=1; elf[40]=52; elf[42]=32; elf[46]=40;
    uLongf bound=compressBound(static_cast<uLong>(elf.size()));
    std::vector<std::uint8_t> comp(bound);
    int z=compress2(reinterpret_cast<Bytef*>(comp.data()),&bound,reinterpret_cast<const Bytef*>(elf.data()),static_cast<uLong>(elf.size()),Z_BEST_SPEED);
    if (z != Z_OK) { std::cerr << "FAILED: test zlib compression should succeed\n"; std::exit(1); } comp.resize(bound);

    std::vector<std::uint8_t> file(16,0x11);
    put32le(file,0); put16le(file,0x5000); put16le(file,0xffff); put32le(file,static_cast<std::uint32_t>(elf.size()));
    file.push_back(0); putCString(file,"/omega_sys/audio-app"); putCString(file,"12/17/2024"); putCString(file,"16.33");
    put32le(file,0); put32le(file,static_cast<std::uint32_t>(comp.size()));
    const std::uint32_t n=static_cast<std::uint32_t>(elf.size());
    file.push_back(static_cast<std::uint8_t>((n>>24)&0xff)); file.push_back(static_cast<std::uint8_t>((n>>16)&0xff));
    file.push_back(static_cast<std::uint8_t>((n>>8)&0xff)); file.push_back(static_cast<std::uint8_t>(n&0xff));
    file.insert(file.end(),comp.begin(),comp.end()); putChunk(upd,0x0011,file);
    return upd;
}

static void expect(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}

static bool hasCandidate(const std::vector<Candidate>& v, const std::string& name) {
    for (const auto& c : v) if (c.name == name) return true;
    return false;
}

int main() {
    {
        std::vector<std::uint8_t> d(64,0);
        d[0]=0x7f; d[1]='E'; d[2]='L'; d[3]='F'; d[4]=1; d[5]=1; d[18]=40; d[19]=0;
        AnalysisResult r;
        FormatDetector::analyze(d,r);
        expect(r.format == "ELF", "ARM sample should be ELF");
        expect(r.architecture == "ARM", "ELF e_machine 40 should be ARM");
        expect(r.bits == 32, "ELF class 1 should be 32-bit");
        expect(r.endian == "Little", "ELF data 1 should be little endian");
    }
    {
        auto d = bytes("prefix __cxa_throw GLIBCXX_ GCC: (GNU) suffix");
        AnalysisResult r; r.format="ELF";
        LanguageDetector::analyze(d,r);
        expect(hasCandidate(r.languages,"C++"), "C++ fingerprints should identify C++ candidate");
        expect(hasCandidate(r.toolchains,"GCC"), "GCC fingerprint should identify GCC candidate");
    }
    {
        auto d = bytes("Z103A /update/uImage /boot/MLO /boot/u-boot.bin KORG");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(!r.korgModels.empty(), "Pa600 machine ID should create a Korg model hit");
        expect(r.korgModels[0].model == "Pa600", "Z103A should map to Pa600");
        expect(!r.notes.empty(), "Korg package paths should create a package note");
    }

    {
        auto d = syntheticPkg();
        AnalysisResult r;
        const bool ok = PkgParser::analyze(d,r);
        expect(ok, "synthetic known-family Korg PKG should parse");
        expect(r.korgPkg.recognized, "PKG parser should set recognized flag");
        expect(r.korgPkg.systemType == "103ASTD", "PKG system type should be decoded");
        expect(r.korgPkg.packageType == 2, "PKG package type should be decoded little-endian");
        expect(r.korgPkg.chunks.size() == 2, "PKG parser should enumerate chunks");
        expect(r.korgPkg.chunks[1].path == "/update/uImage", "system chunk id 2 should map to update kernel path");
        expect(r.korgPkg.chunks[1].dataSize == 8, "system file payload size should exclude member MD5");
    }


    {
        auto d = syntheticUpdTlv();
        AnalysisResult r;
        const bool ok = UpdParser::analyze(d,r);
        expect(ok, "synthetic Korg UPD TLV should parse");
        expect(r.korgUpdContainer.recognized, "UPD TLV parser should set recognized flag");
        expect(r.korgUpdContainer.exactEof, "UPD TLV parser should reach EOF exactly");
        expect(r.korgUpdContainer.metaStrings.size() >= 6, "UPD metadata strings should decode");
        expect(r.korgUpdContainer.metaStrings[0] == "103ASTD", "UPD metadata should expose 103ASTD");
        expect(r.korgUpdContainer.fileCount == 1, "UPD parser should count zlib file records");
        expect(r.korgUpdContainer.signatureCount == 1, "UPD parser should count 0x06xx signatures");
        expect(r.korgUpdContainer.entries[1].path == "/omega_sys/test.txt", "UPD file path should decode");
        expect(r.korgUpdContainer.entries[1].zlibStream, "UPD file should expose zlib stream");
        expect(r.korgUpdContainer.systemType == "103ASTD", "UPD named metadata should expose system type");
        expect(r.korgUpdContainer.softwareFamily == "KORG-SW6", "UPD named metadata should expose software family");
        expect(r.korgUpdContainer.platformCode == "workhorse6", "UPD named metadata should expose platform code");
        expect(r.korgUpdContainer.tagStats.size() == 3, "UPD parser should aggregate TLV tags");
        KorgKnowledgeBase::enrichUpd(r);
        expect(!r.korgReferenceProfile.empty(), "Pa600 metadata should activate the Z103A reference profile");
        expect(!r.korgPlatformFacts.empty(), "Pa600 reference profile should add structured platform facts");
    }

    {
        auto d = bytes("random outer update data with KORG marker");
        AnalysisResult r;
        UpdateDetector::analyze("Pa600_Operating_System_v211.upd", d, r);
        expect(r.korgUpdate.recognized, "UPD extension should be recognized as Korg update family");
        expect(r.korgUpdate.extension == "UPD", "UPD extension should be reported");
        expect(r.korgUpdate.modelHint == "Pa600", "Pa600 filename should create a filename model hint");
        expect(r.korgUpdate.versionHint == "v211", "v211 filename should create a version hint");
        expect(r.format.find("Korg OS Update") != std::string::npos, "UPD should have visible update format even before internal decode");
    }


    {
        std::vector<std::uint8_t> d(64,0);
        d[0]=0x7f; d[1]='E'; d[2]='L'; d[3]='F'; d[4]=1; d[5]=1; d[6]=1;
        d[16]=2; d[18]=40; // ET_EXEC, ARM
        d[20]=1; // version
        d[24]=0x00; d[25]=0x10; // entry 0x1000 LE
        d[40]=52; d[42]=32; d[46]=40; // header sizes
        ExecutableInfo x;
        expect(ElfAnalyzer::analyze(d,"/omega_sys/audio-app",0,false,x), "ELF analyzer should accept ARM ELF32");
        expect(x.architecture == "ARM", "ELF analyzer should report ARM");
        expect(hasCandidate(x.languages,"C"), "stripped native ELF without C++ evidence should report C as probable candidate");
    }
    {
        std::vector<std::uint8_t> d(64,0);
        d[0]=0x7f; d[1]='E'; d[2]='L'; d[3]='F'; d[4]=1; d[5]=1; d[6]=1;
        d[16]=2; d[18]=140; d[40]=52; d[42]=32; d[46]=40;
        ExecutableInfo x;
        expect(ElfAnalyzer::analyze(d,"/omega_sys/tgondsp.out",0,false,x), "ELF analyzer should accept TI C6x ELF");
        expect(x.architecture == "TI TMS320C6000", "ELF e_machine 0x8C should report TI C6000");
        expect(hasCandidate(x.platforms,"TI C6000 DSP"), "TI C6000 ELF should get DSP platform evidence");
    }
    {
        std::vector<std::uint8_t> d = {0x70,0x47}; // Thumb BX LR
        FunctionInfo f;
        ArmDisassembler::decodeFunction(d,0,0x1000,2,true,f,4);
        expect(!f.disassembly.empty() && f.disassembly[0].find("bx lr") != std::string::npos,
               "Thumb disassembler should decode BX LR");
        expect(!f.pseudocode.empty() && f.pseudocode[0] == "return;", "Thumb BX LR should create return pseudocode");
    }


    {
        auto d=syntheticDtb();
        AnalysisResult r;
        expect(DeviceTreeAnalyzer::analyze(d,"/boot/arvon-c3.dtb",0,false,r), "FDT parser should accept synthetic DTB");
        expect(r.deviceTrees.size()==1, "DTB parser should append device tree result");
        expect(r.deviceTrees[0].nodeCount==7, "DTB parser should enumerate root, aliases, chosen, buses and devices");
        expect(r.deviceTrees[0].platformHint=="TI DRA7 family", "DRA7 compatible should identify platform family");
        expect(r.deviceTrees[0].bootargs.find("console=ttyO0") != std::string::npos, "DTB parser should decode kernel bootargs");
        expect(r.deviceTrees[0].aliases.size()==2, "DTB parser should decode serial/I2C aliases");
        expect(r.deviceTrees[0].busDevices.size()==1, "DTB parser should enumerate concrete I2C child devices");
        expect(r.deviceTrees[0].busDevices[0].compatible=="ti,tlv320aic3104" && r.deviceTrees[0].busDevices[0].address==0x18, "DTB parser should decode TLV320AIC3104 I2C address");
        bool dsp=false,audio=false,codec=false; for(const auto& n:r.deviceTrees[0].nodes){if(n.category=="DSP"&&n.regAddress==0x40800000)dsp=true;if(n.category=="Audio"&&n.regAddress==0x48468000)audio=true;if(n.category=="Audio"&&n.compatible=="ti,tlv320aic3104")codec=true;}
        expect(dsp, "DTB parser should decode active DSP register address");
        expect(audio, "DTB parser should decode active McASP address");
        expect(codec, "DTB parser should classify TLV320 codec as audio hardware");
        bool codecFact=false; for(const auto& f:r.korgPlatformFacts) if(f.name=="Audio codec"&&f.value.find("TLV320AIC3104")!=std::string::npos) codecFact=true;
        expect(codecFact, "DTB parser should emit detected audio-codec platform fact");
    }

    {
        auto d=syntheticUpdWithArmElf();
        AnalysisResult r;
        expect(UpdParser::analyze(d,r), "UPD with compressed ARM ELF should parse");
        FirmwareExecutableScanner::analyze(d,r);
        expect(!r.executables.empty(), "recursive scanner should find compressed executable");
        expect(r.executables[0].path == "/omega_sys/audio-app", "recursive scanner should preserve firmware path");
        expect(r.executables[0].architecture == "ARM", "recursive scanner should analyze ARM executable CPU");
        expect(hasCandidate(r.executables[0].languages,"C"), "recursive executable should get programming-language evidence");
    }

    {
        auto d = bytes("nothing identifiable here");
        AnalysisResult r;
        KorgDetector::analyze(d,r);
        expect(r.korgModels.empty(), "unknown data must not invent a Korg model");
    }
    std::cout << "detector tests passed\n";
    return 0;
}
