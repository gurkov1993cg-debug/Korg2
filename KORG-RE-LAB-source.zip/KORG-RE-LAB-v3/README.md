# KORG RE LAB 3.0.0

**Native macOS application (Intel, macOS 10.13+)**. Double-click `KORG RE LAB.app`, press **Open File…**, then select a Korg firmware/package/binary to analyze. The app displays format, architecture, language/runtime, compiler/toolchain, platform/ABI, Korg model evidence, PKG structure and embedded objects in a native GUI.

**Version: V3 (3.0.0)**

Every push to `main` and every pull request automatically starts GitHub Actions builds. The workflow produces an **Intel macOS artifact targeting macOS 10.13** for the 2011 iMac, plus a Linux x64 validation artifact. It can also be started manually with `workflow_dispatch`.

KORG RE LAB is a Korg-focused reverse-engineering and firmware-research framework. The project is designed for the **whole Korg product range**, not for only two models. KRONOS and Pa600 are useful research examples, but the architecture must remain model-independent.

The first target host is an **Intel iMac 2011 running macOS High Sierra 10.13.6**, so the core stays native C++14 and avoids mandatory heavy runtime dependencies.

## Current milestone — V3 PKG parser

- detects ELF, PE/COFF, Mach-O, Java class, DEX, WASM, ZIP-like containers, scripts, Lua bytecode, BEAM, gzip, SquashFS and CPIO;
- detects common CPU families including x86/x86_64, ARM/AArch64, MIPS, PowerPC, SuperH, SPARC and RISC-V;
- confidence-based source-language/runtime fingerprinting;
- compiler/toolchain fingerprinting including GCC, Clang/LLVM, Apple Clang, MSVC, Intel, ARM, IAR, Green Hills, CodeWarrior, Borland, Watcom, TinyCC and language-specific toolchains;
- Linux/U-Boot/ARM-EABI/BusyBox/Qt platform clues;
- Korg-specific model signature database kept separate from the generic analysis core;
- first-pass Korg package structure scanning and embedded object discovery;
- read-only parser for the proven Professional Arranger PKG chunk family: 16-byte package hash field, little-endian chunk headers, 4-byte alignment, header metadata, system slots 2..14, installer/directory/file/rootfs metadata;
- machine-readable `--json` output for the future GUI and automated diff engine;
- unit tests and GitHub Actions CI.

## Scope

The model database and research tree will cover, as evidence becomes available:

- Professional Arranger: Pa-series and related products;
- Workstations: Triton, M3/M50, Krome, Kross, OASYS, KRONOS, Nautilus and related platforms;
- other Korg synth/workstation families when their firmware, file formats or hardware architecture share useful technology.

**Important:** scope is broad, but a model is not marked as technically understood until there is evidence. Unknown stays unknown.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

On macOS the project sets a minimum deployment target of 10.13.

Run:

```sh
./build/korg-re-lab /path/to/firmware.pkg
./build/korg-re-lab --json /path/to/binary
```

## Roadmap

1. Add cryptographic PKG/member MD5 verification and safe extraction.
2. Recursive analysis: package -> kernel/rootfs -> every executable/script separately.
3. ELF sections, symbols, imports, dynamic metadata, `.comment`, build IDs and DWARF.
4. External signature packs so language/compiler support can grow without rebuilding the app.
5. Disassembly and function discovery for ARM/x86 and additional CPU families found in Korg hardware.
6. OS-to-OS structural and function diff.
7. Cross-model feature dependency graph and compatibility classification.
8. Native AppKit GUI for the Intel iMac 2011.
9. Safe experimental patch/repack pipeline only after package integrity/recovery behavior is understood.

See `docs/ARCHITECTURE.md`, `docs/DETECTION_MODEL.md`, `docs/MODEL_COVERAGE.md`, and `docs/KORG_PKG_FORMAT.md`.
## UPD TLV parser

V3 now includes a read-only parser for the TLV-based Korg Professional Arranger UPD family, based on the user-supplied reverse-engineering notes for `Pa600_Operating_System_v211.upd`. It validates the 16-byte package prefix, 4-byte-aligned little-endian TLV chain, package metadata, directory/file/raw-file records, zlib member positions and 0x06xx DER-shaped signature records. Unknown fields remain labeled as unknown and signature candidates are not claimed cryptographically verified.

## Pa600 / Z103A UPD knowledge integration

The UPD analyzer now decodes the validated TLV container structure and keeps two evidence classes separate:

- `DETECTED`: evidence present in the currently opened update (metadata, TLV tags, file table paths, zlib/raw/signature records).
- `REFERENCE-VERIFIED`: facts validated from the supplied Pa600 v2.1.1 research profile and shown only when the metadata fingerprint `103ASTD + KORG-SW6 + workhorse6 + Z103A` matches.

The Pa600 reference profile includes LFO/Linux, ARVON, ARM32 armhf, PREEMPT_RT kernel, TI C6x DSP, OPOS, PCM layout, sound-resource mapping and MIDI-routing facts. These are not silently promoted to directly detected facts.
