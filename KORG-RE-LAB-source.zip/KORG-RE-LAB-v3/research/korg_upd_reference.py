"""Разчитане на Korg .upd контейнер (Pa600 и сродни от същото поколение).

Структура, установена от Pa600_Operating_System_v211.upd:

  0x00  16 байта   глава (хеш/идентификатор на пакета)
  0x10  начало на TLV верига до края на файла

TLV запис:
  u32 tag (little endian)
  u32 length
  length байта данни
  подравняване до кратно на 4

Тагове:
  0x0001  метаданни на пакета (версия + низове)
  0x0002  ARM образ (16 байта хеш + код)
  0x000e  повторение на 0x0002
  0x0003  голям полезен товар
  0x0004  полезен товар
  0x0005  малък запис
  0x000f  служебни записи
  0x0010  запис за директория (без съдържание)
  0x0011  ФАЙЛ: заглавка с път + zlib поток
  0x0013  файлов запис без компресия (тук: /user-release.tar, root FS)
  0x0015  служебен блок
  0x06xx  ECDSA подписи в DER (0x30 0x45/0x46 ...), по един след всяка секция

Заглавка на файлов запис (tag 0x0011 и 0x0010):
  +0x00  16 байта  MD5
  +0x10  u32       0
  +0x14  u16       атрибут (0x7000 директория/ресурс, 0x1000, 0x5000 ...)
  +0x16  u16       0xffff
  +0x18  u32 LE    размер след разкомпресиране
  +0x1c  u8        флаг
  +0x1d  низ       път ("/omega_sys/...") с NUL
         низ       дата "MM/DD/YYYY" с NUL
         низ       час "HH.MM" с NUL
         u32       (константа)
         u32 LE    компресиран размер
         u32 BE    размер след разкомпресиране (повторен)
         zlib поток
"""

import os
import struct
import zlib

HEADER_SIZE = 0x10

TAG_META = 0x0001
TAG_DIR = 0x0010
TAG_FILE = 0x0011
TAG_FILE_RAW = 0x0013
SIGNATURE_TAGS = range(0x0600, 0x0700)

TAG_NAMES = {
    0x0001: "meta", 0x0002: "arm_image", 0x0003: "payload3",
    0x0004: "payload4", 0x0005: "payload5", 0x000e: "arm_image_copy",
    0x000f: "aux", 0x0010: "dir", 0x0011: "file",
    0x0015: "aux15",
}


def walk(data, start=HEADER_SIZE, align=4):
    """Обхожда TLV веригата. Дава (offset, tag, length, data_offset)."""
    n = len(data)
    off = start
    while off + 8 <= n:
        tag, ln = struct.unpack_from("<II", data, off)
        if ln > n - off - 8:
            break
        yield off, tag, ln, off + 8
        off += 8 + ln
        if off % align:
            off += align - (off % align)


def parse_meta(blob):
    vals = struct.unpack_from("<HHHHI", blob, 0)
    strings = [s.decode("latin-1") for s in blob[12:].split(b"\x00") if s]
    return {"numbers": vals, "strings": strings}


def _cstr(blob, pos):
    end = blob.index(b"\x00", pos)
    return blob[pos:end].decode("latin-1", "replace"), end + 1


def parse_entry(blob):
    """Чете заглавката на запис 0x0010/0x0011."""
    if len(blob) < 0x1d:
        return None
    e = {
        "md5": blob[:16].hex(),
        "attr": struct.unpack_from("<H", blob, 0x14)[0],
        "size": struct.unpack_from("<I", blob, 0x18)[0],
        "flag": blob[0x1c],
    }
    try:
        p = 0x1d
        e["path"], p = _cstr(blob, p)
        if p < len(blob):
            e["date"], p = _cstr(blob, p)
        if p < len(blob):
            e["time"], p = _cstr(blob, p)
        e["header_end"] = p
    except ValueError:
        e["path"] = blob[0x1d:].split(b"\x00")[0].decode("latin-1", "replace")
        e["header_end"] = len(blob)
    return e


def find_stream(blob, start, limit=512):
    """Намира началото на zlib потока след заглавката."""
    for p in range(start, min(len(blob) - 2, start + limit)):
        if blob[p] == 0x78 and blob[p + 1] in (0x01, 0x9c, 0xda):
            try:
                out = zlib.decompressobj().decompress(blob[p:], 1 << 16)
            except zlib.error:
                continue
            if out:
                return p
    return None


def decompress_entry(blob, entry):
    """Връща (данни, метод) или (None, причина)."""
    p = find_stream(blob, entry.get("header_end", 0x1d))
    if p is None:
        return None, "няма разпознат zlib поток"
    try:
        return zlib.decompress(blob[p:]), "zlib"
    except zlib.error:
        try:
            o = zlib.decompressobj()
            return o.decompress(blob[p:]), "zlib (частично)"
        except zlib.error as ex:
            return None, "грешка: %s" % ex


def safe_join(root, path):
    rel = path.lstrip("/").replace("\\", "/")
    parts = [p for p in rel.split("/") if p not in ("", ".", "..")]
    return os.path.join(root, *parts) if parts else None


def unpack(path, outdir, verbose=True):
    """Разопакова .upd в директория. Връща статистика."""
    with open(path, "rb") as f:
        data = f.read()

    stats = {"files": 0, "dirs": 0, "failed": 0, "raw": 0, "bytes": 0}
    os.makedirs(outdir, exist_ok=True)

    for off, tag, ln, doff in walk(data):
        blob = data[doff:doff + ln]

        if tag == TAG_META:
            meta = parse_meta(blob)
            if verbose:
                print("Пакет:", " | ".join(meta["strings"]))
            continue

        if tag == TAG_DIR:
            e = parse_entry(blob)
            if e and e.get("path"):
                target = safe_join(outdir, e["path"])
                if target:
                    os.makedirs(target, exist_ok=True)
                    stats["dirs"] += 1
            continue

        if tag == TAG_FILE_RAW:
            e = parse_entry(blob)
            if e and e.get("path"):
                target = safe_join(outdir, e["path"])
                if target:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with open(target, "wb") as f:
                        f.write(blob[e["header_end"]:])
                    stats["raw"] += 1
                    if verbose:
                        print("  RAW  %-58s %9d" % (e["path"], ln))
                    continue

        if tag == TAG_FILE:
            e = parse_entry(blob)
            if not e or not e.get("path"):
                stats["failed"] += 1
                continue
            out, how = decompress_entry(blob, e)
            target = safe_join(outdir, e["path"])
            if target is None:
                stats["failed"] += 1
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            if out is None:
                with open(target + ".raw", "wb") as f:
                    f.write(blob[e["header_end"]:])
                stats["raw"] += 1
                if verbose:
                    print("  RAW  %-58s %s" % (e["path"], how))
                continue
            with open(target, "wb") as f:
                f.write(out)
            stats["files"] += 1
            stats["bytes"] += len(out)
            if verbose:
                mark = "" if len(out) == e["size"] else "  (!= обявения размер)"
                print("  OK   %-58s %9d%s" % (e["path"], len(out), mark))
            continue

        if tag in SIGNATURE_TAGS:
            continue

        name = TAG_NAMES.get(tag, "tag_%04x" % tag)
        target = os.path.join(outdir, "_sections", "%s_0x%08x.bin" % (name, off))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(blob)
        if verbose:
            print("  SEC  %-58s %9d" % (name, ln))

    return stats
