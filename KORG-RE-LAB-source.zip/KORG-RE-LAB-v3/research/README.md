# Research workspace

This tree will hold **metadata, notes, hashes and reproducible observations**, not copyrighted firmware redistribution.

Planned per-model structure:

```text
research/
  professional-arranger/
    Pa600/
      hardware.md
      firmware-map.md
      os-versions.md
      feature-map.md
  workstation/
    KRONOS/
      hardware.md
      firmware-map.md
      feature-map.md
```

Every observation should be labelled as one of:

- PROVEN
- STRONG EVIDENCE
- UNKNOWN

The purpose is to build a technical lineage map across Korg generations and later feed the OS diff / feature-porting engine.
