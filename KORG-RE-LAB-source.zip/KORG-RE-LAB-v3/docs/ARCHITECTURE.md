# Architecture

KORG RE LAB is intentionally split into generic reverse-engineering layers and Korg-specific knowledge.

```text
Input
  |
  +-- Generic format / CPU detector
  +-- Language / runtime fingerprint engine
  +-- Compiler / linker / ABI fingerprint engine
  +-- Embedded object scanner
  |
  +-- Korg platform layer
        +-- model evidence database
        +-- package/container parsers
        +-- per-family filesystem/resource parsers
        +-- OS version comparator
        +-- feature dependency graph
```

## Design rules

1. No architecture assumption is global. A single update package may contain bootloader, kernel, filesystem, binaries and scripts built with different tools.
2. A source language is a confidence result, not a guaranteed recoverable property of stripped machine code.
3. Product-range coverage is database-driven. Adding a model must not require rewriting the analysis core.
4. Proven evidence, strong evidence and unknown information remain distinct.
5. Repacking/patching is not enabled until package integrity, boot path and recovery behavior are understood for that target family.

## Future recursive model

```text
Korg package
  +-- component A -> detect -> parse -> fingerprints -> functions
  +-- component B -> decompress -> filesystem
                         +-- app 1 -> ELF analysis
                         +-- app 2 -> ELF analysis
                         +-- script -> interpreter analysis
                         +-- resources
```

The recursive result tree will be the basis of model-to-model feature comparison.
