# Korg Professional Arranger PKG — evidence map

Status: **implemented as a read-only parser in V3**.

This document records what is currently treated as evidence for the known Professional Arranger PKG family. The implementation is independent C++ code; public prior art is used as format evidence, not copied source.

## Public prior art

Archived project: `Polprzewodnikowy/KorgPackage`

- Repository: https://github.com/Polprzewodnikowy/KorgPackage
- README format notes: https://github.com/Polprzewodnikowy/KorgPackage/blob/master/README.md
- PackageReader reference: https://github.com/Polprzewodnikowy/KorgPackage/blob/master/src/main/korgpkg/PackageReader.java

## Proven structural facts used by V3

- package starts with a 16-byte MD5 field covering the remainder of the package;
- chunk id and chunk-size fields are little-endian 32-bit values;
- chunks are padded/aligned to 4-byte boundaries;
- chunk 1 is the package header;
- chunks 2..14 are known system-file slots;
- chunk 15 is an installer script;
- chunk 16 is a directory record;
- chunk 17 is a link record (not yet decoded by our parser);
- chunk 18 is a file record;
- chunk 19 is a root-filesystem record.

Known system slots:

| ID | Meaning | Canonical path |
|---:|---|---|
| 2 | update kernel | `/update/uImage` |
| 3 | update ramdisk | `/update/ramdisk.gz` |
| 4 | update installer | `/update/lfo-pkg-install` |
| 5 | update installer config | `/update/lfo-pkg-install.xml` |
| 6 | service kernel | `/service/uImage` |
| 7 | service ramdisk | `/service/ramdisk.gz` |
| 8 | service app | `/service/lfo-service` |
| 9 | service app config | `/service/lfo-service.xml` |
| 10 | package launcher | `/service/lfo-pkg-launcher` |
| 11 | launcher config | `/service/lfo-pkg-launcher.xml` |
| 12 | first-stage bootloader | `/boot/MLO` |
| 13 | U-Boot | `/boot/u-boot.bin` |
| 14 | user kernel | `/kernel/uImage` |

## Header fields decoded in V3

- package-library version (4 bytes);
- package type (`2` observed as update, `3` as full installation);
- two still-unknown 16-bit fields;
- system type / machine-customization string;
- two build-system strings;
- creation date/time strings;
- two package-description strings.

## Integrity status

V3 records package and member MD5 fields but **does not yet verify them cryptographically**. That is intentionally reported as unverified, not valid.

## Next work

1. cryptographic MD5 verification;
2. safe extraction of raw system chunks;
3. zlib block decoding for file chunk compression type 1;
4. preserve but do not bypass compression/encryption type 16 until its semantics are proven;
5. recursive analysis of extracted uImage, ramdisk/rootfs and ELF files;
6. collect additional model/package generations and determine where the PKG family changes.
