# Detection model

The detector treats these as separate questions:

- file/container format;
- CPU architecture and endian mode;
- source-language/runtime fingerprints;
- compiler/linker/toolchain fingerprints;
- OS/platform/ABI fingerprints;
- Korg family/model evidence.

## Confidence policy

- **Detected**: strong distinctive evidence.
- **Probable**: multiple or moderately strong indicators.
- **Possible**: weak evidence that must not be presented as fact.
- **Unknown**: insufficient defensible evidence.

Optimization, stripping, LTO, static linking and obfuscation can erase language/toolchain fingerprints. The eventual ELF/DWARF parser will increase confidence where metadata survives.

## Current language/runtime families

C/C++, Objective-C, Swift, Rust, Go, D, Nim, Zig, Delphi/Object Pascal, Free Pascal, Ada, Fortran, Haskell, OCaml, Crystal, Java/JVM, Kotlin, Scala, .NET IL, C#, F#, VB.NET, Erlang/Elixir/BEAM, Lua, Python, JavaScript/Node, Ruby, Perl, POSIX shell, Bash, PHP and WebAssembly.

The goal is **extensible coverage**, not a false claim that every possible historical language can always be inferred from machine code.

## Self-signature caution

A signature-driven detector can encounter literal signature strings inside analysis tools themselves. Later versions will score evidence by binary section/import/symbol context rather than raw string presence alone. Until then, reports remain confidence-based and expose the exact evidence used.
