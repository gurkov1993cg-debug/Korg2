# Pa600 ARVON device-tree reference

Reference source: supplied parse of `arvon-c3.dtb.raw` from the Pa600 research set.

## Verified observations from the supplied DTB parse

- 591 device-tree nodes were enumerated.
- Peripheral compatibles place the platform in the TI DRA7 family (`ti,dra7-*`, `ti,dra742-*`). This is a family-level observation, not a claim of an exact SoC part number.
- Active DSP node: `dsp@40800000`, compatible `ti,dra7-dsp`.
- Active DSP IOMMUs: `0x40d01000` and `0x40d02000`, compatible `ti,dra7-dsp-iommu`.
- Active mailboxes include `0x48840000` and `0x48842000`.
- Active McASP audio controller: `mcasp@48468000`, compatible `ti,dra7-mcasp-audio`.
- Active MMC controllers: `0x4809c000` and `0x480b4000`.
- Active McSPI controller: `0x48098000`.
- Active I2C controllers include `0x48070000`, `0x48060000`, `0x4807a000`.
- Ethernet CPSW: `0x48484000`, compatible `ti,dra7-cpsw`.
- DRA7 IPU nodes at `0x58820000` and `0x55020000` are disabled in the supplied reference DTB.

## How KORG RE LAB uses this

The program now contains a generic Flattened Device Tree (FDT/DTB) parser. It detects the standard `0xD00DFEED` magic, parses the FDT header, structure and strings blocks, enumerates nodes/properties, resolves `compatible`, `status`, and `reg`, and builds a hardware map. When a DTB is present inside a Korg UPD file, the UPD scanner decompresses the member and feeds it to the device-tree analyzer automatically.

Facts extracted from the current DTB are marked `DETECTED`. The Pa600 ARVON observations listed above are stored as `REFERENCE-VERIFIED` facts only when the Pa600/Z103A metadata profile matches.
## Additional verified bus topology

A second supplied parse of the same ARVON DTB exposes the bus aliases and concrete devices attached below the I2C controllers:

- `i2c0` -> `/ocp/i2c@48070000`, through `i2c4` -> `/ocp/i2c@4807c000`.
- `serial0` through `serial9` map to the ten UART nodes reported by the DTB.
- `spi0` aliases `/ocp/qspi@4b300000`.
- `i2c@48070000` address `0x58`: `ti,tps65917` power-management IC.
- `i2c@48070000` address `0x48`: `ti,tmp102` temperature sensor.
- `i2c@48070000` address `0x18`: `ti,tlv320aic3104` audio codec.
- `i2c@48060000` address `0x6f`: `microchip,mcp7941x` RTC.
- `i2c@48060000` address `0x38`: `edt,edt-ft5406` touch controller.

The supplied SPI listing enumerated SPI controller nodes themselves as if their `reg` values were chip-select values. KORG RE LAB does **not** copy that interpretation: its generic parser reports SPI devices only when they are child nodes of an SPI/QSPI controller, so controller MMIO addresses are not mislabeled as chip selects.

The DTB analyzer now also decodes `/aliases`, any `bootargs` property when present, bus child addresses, and `spi-max-frequency` for actual SPI children. These fields are emitted in both the GUI report and JSON output.
