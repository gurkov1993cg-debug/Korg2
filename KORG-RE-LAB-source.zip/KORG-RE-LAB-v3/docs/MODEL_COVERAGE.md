# Korg model coverage map

The project target is the full Korg range. This document separates **coverage target** from **proven fingerprints**.

## Professional Arranger target families

Pa50/60/80, Pa1X, Pa2X, Pa3X, Pa300, Pa500, Pa600, Pa700, Pa800, Pa900, Pa1000, Pa4X, Pa5X, Pa3XLe, Havian and related regional/derived models.

## Workstation / synth target families

Triton family, OASYS, M3/M50, Krome, Kross, KRONOS, Nautilus and other Korg platforms for which firmware/file-format/hardware evidence can be obtained.

## Proven machine-ID signatures currently in code

| Family | Model | Machine ID | Evidence state |
|---|---|---|---|
| Professional Arranger | Pa600 | Z103A | public reverse-engineering evidence |
| Professional Arranger | Pa900 | Z104A | public reverse-engineering evidence |
| Professional Arranger | Pa300 | Z106A | public reverse-engineering evidence |
| Professional Arranger | Pa3XLe | Z107A | public reverse-engineering evidence |
| Professional Arranger | Havian 30 | Z108A | public reverse-engineering evidence |
| Professional Arranger | Pa4X | Z110A | public reverse-engineering evidence |

No ID is invented for models not in this table. They remain research targets until confirmed from firmware or reliable technical sources.
