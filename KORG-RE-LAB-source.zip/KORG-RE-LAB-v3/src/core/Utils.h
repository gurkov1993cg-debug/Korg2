#pragma once
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

inline std::vector<std::uint8_t> readFile(const std::string& path) {
    std::ifstream f(path.c_str(), std::ios::binary);
    if (!f) throw std::runtime_error("Cannot open file: " + path);
    f.seekg(0, std::ios::end);
    const std::streamoff n = f.tellg();
    f.seekg(0, std::ios::beg);
    if (n < 0) throw std::runtime_error("Cannot determine file size");
    std::vector<std::uint8_t> data(static_cast<std::size_t>(n));
    if (!data.empty()) f.read(reinterpret_cast<char*>(data.data()), n);
    return data;
}

inline bool startsWith(const std::vector<std::uint8_t>& d, std::initializer_list<std::uint8_t> sig) {
    if (d.size() < sig.size()) return false;
    std::size_t i = 0;
    for (auto b : sig) if (d[i++] != b) return false;
    return true;
}

inline bool containsAscii(const std::vector<std::uint8_t>& d, const std::string& needle) {
    if (needle.empty() || d.size() < needle.size()) return false;
    return std::search(d.begin(), d.end(), needle.begin(), needle.end()) != d.end();
}

inline std::vector<std::uint64_t> findBytes(const std::vector<std::uint8_t>& d,
                                            const std::vector<std::uint8_t>& needle,
                                            std::size_t limit = 64) {
    std::vector<std::uint64_t> out;
    if (needle.empty() || d.size() < needle.size()) return out;
    auto it = d.begin();
    while (it != d.end() && out.size() < limit) {
        it = std::search(it, d.end(), needle.begin(), needle.end());
        if (it == d.end()) break;
        out.push_back(static_cast<std::uint64_t>(std::distance(d.begin(), it)));
        ++it;
    }
    return out;
}

inline std::uint16_t rd16le(const std::vector<std::uint8_t>& d, std::size_t o) {
    if (o + 2 > d.size()) return 0;
    return static_cast<std::uint16_t>(d[o] | (static_cast<std::uint16_t>(d[o+1]) << 8));
}
inline std::uint16_t rd16be(const std::vector<std::uint8_t>& d, std::size_t o) {
    if (o + 2 > d.size()) return 0;
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(d[o]) << 8) | d[o+1]);
}
inline std::uint32_t rd32le(const std::vector<std::uint8_t>& d, std::size_t o) {
    if (o + 4 > d.size()) return 0;
    return static_cast<std::uint32_t>(d[o]) |
           (static_cast<std::uint32_t>(d[o+1]) << 8) |
           (static_cast<std::uint32_t>(d[o+2]) << 16) |
           (static_cast<std::uint32_t>(d[o+3]) << 24);
}
inline std::uint32_t rd32be(const std::vector<std::uint8_t>& d, std::size_t o) {
    if (o + 4 > d.size()) return 0;
    return (static_cast<std::uint32_t>(d[o]) << 24) |
           (static_cast<std::uint32_t>(d[o+1]) << 16) |
           (static_cast<std::uint32_t>(d[o+2]) << 8) |
            static_cast<std::uint32_t>(d[o+3]);
}

inline std::string hexOffset(std::uint64_t v) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << v;
    return ss.str();
}

inline std::string jsonEscape(const std::string& s) {
    std::ostringstream o;
    for (std::size_t i = 0; i < s.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\b': o << "\\b"; break;
            case '\f': o << "\\f"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default:
                if (c < 0x20) {
                    const char* hex = "0123456789ABCDEF";
                    o << "\\u00" << hex[(c >> 4) & 0xF] << hex[c & 0xF];
                } else {
                    o << s[i];
                }
        }
    }
    return o.str();
}
