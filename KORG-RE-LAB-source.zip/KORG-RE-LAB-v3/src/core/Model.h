#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Evidence {
    std::string kind;
    std::string value;
    int weight = 0;
};

struct Candidate {
    std::string name;
    int score = 0;
    std::string confidence;
    std::vector<Evidence> evidence;
};

struct EmbeddedObject {
    std::string type;
    std::uint64_t offset = 0;
    std::string note;
};

struct KorgModelHit {
    std::string family;
    std::string model;
    std::string machineId;
    std::string confidence;
    std::string evidence;
};


struct KorgPkgChunk {
    std::uint32_t id = 0;
    std::uint32_t size = 0;
    std::uint64_t offset = 0;
    std::uint64_t payloadOffset = 0;
    std::uint64_t dataOffset = 0;
    std::uint32_t dataSize = 0;
    std::string type;
    std::string path;
    std::string date;
    std::string time;
    std::string md5;
    std::uint16_t owner = 0;
    std::uint16_t group = 0;
    std::uint16_t attributes = 0;
    std::uint16_t condition = 0;
    std::uint8_t compression = 0;
};

struct KorgPkgInfo {
    bool recognized = false;
    std::string packageMd5;
    std::string pkgLibVersion;
    std::uint32_t packageType = 0;
    std::uint16_t unknown1 = 0;
    std::uint16_t unknown2 = 0;
    std::string systemType;
    std::string buildSystem1;
    std::string buildSystem2;
    std::string creationDate;
    std::string creationTime;
    std::string packageType1;
    std::string packageType2;
    std::uint64_t parsedBytes = 0;
    std::vector<KorgPkgChunk> chunks;
    std::vector<std::string> warnings;
};



struct KorgUpdEntry {
    std::uint32_t tag = 0;
    std::uint32_t length = 0;
    std::uint64_t offset = 0;
    std::uint64_t payloadOffset = 0;
    std::string type;
    std::string md5;
    std::uint16_t attributes = 0;
    std::uint32_t unpackedSize = 0;
    std::uint32_t compressedSize = 0;
    std::uint32_t unpackedSizeBE = 0;
    std::uint8_t flag = 0;
    std::string path;
    std::string date;
    std::string time;
    std::uint64_t dataOffset = 0;
    bool zlibStream = false;
    bool ecdsaDer = false;
};


struct KorgUpdTagStat {
    std::uint32_t tag = 0;
    std::uint32_t count = 0;
    std::uint64_t totalPayloadBytes = 0;
    std::string type;
};

struct KorgPlatformFact {
    std::string category;
    std::string name;
    std::string value;
    std::string confidence;
    std::string evidence;
};

struct KorgUpdContainerInfo {
    bool recognized = false;
    bool exactEof = false;
    std::string packageHeader16;
    std::uint64_t parsedBytes = 0;
    std::vector<std::uint32_t> metaNumbers;
    std::vector<std::string> metaStrings;
    std::vector<KorgUpdEntry> entries;
    std::vector<KorgUpdTagStat> tagStats;
    std::string systemType;
    std::string softwareFamily;
    std::string platformCode;
    std::string packageDate;
    std::string packageTime;
    std::string packageLabel;
    std::string packageName;
    std::uint32_t fileCount = 0;
    std::uint32_t dirCount = 0;
    std::uint32_t rawFileCount = 0;
    std::uint32_t signatureCount = 0;
    std::vector<std::string> warnings;
};

struct KorgUpdateInfo {
    bool recognized = false;
    std::string family;
    std::string extension;
    std::string modelHint;
    std::string versionHint;
    std::string splitPart;
    std::string evidence;
};

struct AnalysisResult {
    std::string path;
    std::uint64_t size = 0;
    std::string format = "Unknown / raw";
    std::string architecture = "Unknown";
    std::string endian = "Unknown";
    int bits = 0;
    std::string headerHex;
    std::vector<std::string> printableStrings;
    std::vector<Candidate> languages;
    std::vector<Candidate> toolchains;
    std::vector<Candidate> platforms;
    std::vector<EmbeddedObject> embedded;
    std::vector<KorgModelHit> korgModels;
    KorgPkgInfo korgPkg;
    KorgUpdContainerInfo korgUpdContainer;
    KorgUpdateInfo korgUpdate;
    std::string korgReferenceProfile;
    std::vector<KorgPlatformFact> korgPlatformFacts;
    std::vector<std::string> notes;
};
