#pragma once
#include "core/Model.h"
#include <string>

class Analyzer {
public:
    static AnalysisResult analyzeFile(const std::string& path);
    static void printReport(const AnalysisResult& r);
    static void printJson(const AnalysisResult& r);
};
