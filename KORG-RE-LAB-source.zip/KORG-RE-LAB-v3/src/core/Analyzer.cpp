#include "core/Analyzer.h"
#include "core/Utils.h"
#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include "korg/pkg/PkgParser.h"
#include <algorithm>
#include <iostream>

AnalysisResult Analyzer::analyzeFile(const std::string& path) {
    const auto data = readFile(path);
    AnalysisResult r;
    r.path = path;
    r.size = data.size();
    FormatDetector::analyze(data,r);
    PkgParser::analyze(data,r);
    LanguageDetector::analyze(data,r);
    KorgDetector::analyze(data,r);
    return r;
}

namespace {
void printCandidates(const char* title, const std::vector<Candidate>& v) {
    std::cout << "\n" << title << ":\n";
    if (v.empty()) { std::cout << "  Unknown\n"; return; }
    const std::size_t max = std::min<std::size_t>(v.size(),5);
    for (std::size_t i=0;i<max;++i) {
        const auto& c=v[i];
        std::cout << "  " << c.name << "  score=" << c.score << "  [" << c.confidence << "]\n";
        const std::size_t evmax = std::min<std::size_t>(c.evidence.size(),4);
        for (std::size_t j=0;j<evmax;++j)
            std::cout << "    - " << c.evidence[j].kind << ": " << c.evidence[j].value << " (+" << c.evidence[j].weight << ")\n";
    }
}

void jsonCandidates(const std::vector<Candidate>& v) {
    std::cout << "[";
    for (std::size_t i=0;i<v.size();++i) {
        if (i) std::cout << ",";
        const auto& c=v[i];
        std::cout << "{\"name\":\"" << jsonEscape(c.name) << "\",\"score\":" << c.score
                  << ",\"confidence\":\"" << jsonEscape(c.confidence) << "\",\"evidence\":[";
        for (std::size_t j=0;j<c.evidence.size();++j) {
            if (j) std::cout << ",";
            const auto& e=c.evidence[j];
            std::cout << "{\"kind\":\"" << jsonEscape(e.kind) << "\",\"value\":\"" << jsonEscape(e.value)
                      << "\",\"weight\":" << e.weight << "}";
        }
        std::cout << "]}";
    }
    std::cout << "]";
}
}

void Analyzer::printReport(const AnalysisResult& r) {
    std::cout << "KORG RE LAB V3 - static fingerprint + PKG report\n";
    std::cout << "File: " << r.path << "\nSize: " << r.size << " bytes\n";
    std::cout << "Format: " << r.format << "\nArchitecture: " << r.architecture;
    if (r.bits) std::cout << " (" << r.bits << "-bit)";
    std::cout << "\nEndian: " << r.endian << "\n";

    printCandidates("Source-language/runtime candidates", r.languages);
    printCandidates("Compiler/toolchain candidates", r.toolchains);
    printCandidates("Platform/ABI candidates", r.platforms);

    std::cout << "\nKorg model candidates:\n";
    if (r.korgModels.empty()) std::cout << "  Unknown / no proven model signature\n";
    for (const auto& m : r.korgModels)
        std::cout << "  " << m.family << " / " << m.model << "  " << m.machineId << "  [" << m.confidence << "]\n"
                  << "    - " << m.evidence << "\n";

    if (r.korgPkg.recognized) {
        std::cout << "\nKorg PKG structure:\n";
        std::cout << "  Package MD5 field: " << r.korgPkg.packageMd5 << "\n";
        std::cout << "  PKG lib version: " << r.korgPkg.pkgLibVersion << "\n";
        std::cout << "  Package type: " << r.korgPkg.packageType;
        if (r.korgPkg.packageType == 2) std::cout << " (upgrade)";
        else if (r.korgPkg.packageType == 3) std::cout << " (full installation)";
        std::cout << "\n";
        std::cout << "  System type: " << r.korgPkg.systemType << "\n";
        std::cout << "  Build systems: " << r.korgPkg.buildSystem1 << " / " << r.korgPkg.buildSystem2 << "\n";
        std::cout << "  Created: " << r.korgPkg.creationDate << " " << r.korgPkg.creationTime << "\n";
        std::cout << "  Chunks: " << r.korgPkg.chunks.size() << "\n";
        const std::size_t maxChunks = std::min<std::size_t>(r.korgPkg.chunks.size(), 64);
        for (std::size_t i=0;i<maxChunks;++i) {
            const auto& c = r.korgPkg.chunks[i];
            std::cout << "    " << hexOffset(c.offset) << " id=" << c.id << " " << c.type
                      << " size=" << c.size;
            if (!c.path.empty()) std::cout << " path=" << c.path;
            if (c.id == 18) std::cout << " compression=" << static_cast<unsigned>(c.compression);
            std::cout << "\n";
        }
        for (const auto& w : r.korgPkg.warnings) std::cout << "  warning: " << w << "\n";
    }

    std::cout << "\nEmbedded objects:\n";
    if (r.embedded.empty()) std::cout << "  none recognized\n";
    for (const auto& e:r.embedded) std::cout << "  " << hexOffset(e.offset) << "  " << e.type << "  - " << e.note << "\n";

    std::cout << "\nAnalysis notes:\n";
    if (r.notes.empty()) std::cout << "  none\n";
    for (const auto& n:r.notes) std::cout << "  - " << n << "\n";
    std::cout << "\nConfidence rule: evidence is reported as Detected/Probable/Possible; unknown stays unknown.\n";
}

void Analyzer::printJson(const AnalysisResult& r) {
    std::cout << "{\"version\":\"3.0.0\",\"path\":\"" << jsonEscape(r.path) << "\",\"size\":" << r.size
              << ",\"format\":\"" << jsonEscape(r.format) << "\",\"architecture\":\"" << jsonEscape(r.architecture)
              << "\",\"bits\":" << r.bits << ",\"endian\":\"" << jsonEscape(r.endian) << "\",";
    std::cout << "\"languages\":"; jsonCandidates(r.languages); std::cout << ",\"toolchains\":"; jsonCandidates(r.toolchains);
    std::cout << ",\"platforms\":"; jsonCandidates(r.platforms);
    std::cout << ",\"korg_models\":[";
    for (std::size_t i=0;i<r.korgModels.size();++i) {
        if (i) std::cout << ",";
        const auto& m=r.korgModels[i];
        std::cout << "{\"family\":\"" << jsonEscape(m.family) << "\",\"model\":\"" << jsonEscape(m.model)
                  << "\",\"machine_id\":\"" << jsonEscape(m.machineId) << "\",\"confidence\":\""
                  << jsonEscape(m.confidence) << "\",\"evidence\":\"" << jsonEscape(m.evidence) << "\"}";
    }
    std::cout << "],\"korg_pkg\":{";
    std::cout << "\"recognized\":" << (r.korgPkg.recognized ? "true" : "false");
    if (r.korgPkg.recognized) {
        std::cout << ",\"package_md5\":\"" << jsonEscape(r.korgPkg.packageMd5) << "\""
                  << ",\"pkg_lib_version\":\"" << jsonEscape(r.korgPkg.pkgLibVersion) << "\""
                  << ",\"package_type\":" << r.korgPkg.packageType
                  << ",\"system_type\":\"" << jsonEscape(r.korgPkg.systemType) << "\""
                  << ",\"build_system_1\":\"" << jsonEscape(r.korgPkg.buildSystem1) << "\""
                  << ",\"build_system_2\":\"" << jsonEscape(r.korgPkg.buildSystem2) << "\""
                  << ",\"creation_date\":\"" << jsonEscape(r.korgPkg.creationDate) << "\""
                  << ",\"creation_time\":\"" << jsonEscape(r.korgPkg.creationTime) << "\""
                  << ",\"chunks\":[";
        for (std::size_t i=0;i<r.korgPkg.chunks.size();++i) {
            if (i) std::cout << ",";
            const auto& c=r.korgPkg.chunks[i];
            std::cout << "{\"id\":" << c.id << ",\"type\":\"" << jsonEscape(c.type)
                      << "\",\"offset\":" << c.offset << ",\"size\":" << c.size
                      << ",\"path\":\"" << jsonEscape(c.path) << "\",\"data_offset\":" << c.dataOffset
                      << ",\"data_size\":" << c.dataSize << ",\"compression\":" << static_cast<unsigned>(c.compression)
                      << ",\"md5\":\"" << jsonEscape(c.md5) << "\"}";
        }
        std::cout << "]";
    }
    std::cout << "},\"embedded\":[";
    for (std::size_t i=0;i<r.embedded.size();++i) {
        if (i) std::cout << ",";
        const auto& e=r.embedded[i];
        std::cout << "{\"type\":\"" << jsonEscape(e.type) << "\",\"offset\":" << e.offset
                  << ",\"note\":\"" << jsonEscape(e.note) << "\"}";
    }
    std::cout << "],\"notes\":[";
    for (std::size_t i=0;i<r.notes.size();++i) {
        if (i) std::cout << ",";
        std::cout << "\"" << jsonEscape(r.notes[i]) << "\"";
    }
    std::cout << "]}\n";
}
