#include "core/Analyzer.h"
#include "core/Utils.h"
#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "korg/KorgDetector.h"
#include "korg/KorgKnowledgeBase.h"
#include "korg/UpdateDetector.h"
#include "korg/UpdParser.h"
#include "korg/pkg/PkgParser.h"
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace {
std::string headerHex(const std::vector<std::uint8_t>& data, std::size_t maxBytes = 64) {
    std::ostringstream ss;
    ss << std::hex << std::uppercase << std::setfill('0');
    const std::size_t n = std::min(maxBytes, data.size());
    for (std::size_t i = 0; i < n; ++i) {
        if (i && i % 16 == 0) ss << "\n";
        else if (i) ss << " ";
        ss << std::setw(2) << static_cast<unsigned>(data[i]);
    }
    return ss.str();
}

std::vector<std::string> printableStrings(const std::vector<std::uint8_t>& data,
                                          std::size_t minLen = 6,
                                          std::size_t maxCount = 80) {
    std::vector<std::string> result;
    std::string current;
    current.reserve(128);
    auto flush = [&]() {
        if (current.size() >= minLen && result.size() < maxCount) result.push_back(current);
        current.clear();
    };
    for (std::uint8_t b : data) {
        if (b >= 0x20 && b <= 0x7E) {
            if (current.size() < 240) current.push_back(static_cast<char>(b));
        } else {
            flush();
            if (result.size() >= maxCount) break;
        }
    }
    if (result.size() < maxCount) flush();
    return result;
}
}

AnalysisResult Analyzer::analyzeFile(const std::string& path) {
    const auto data = readFile(path);
    AnalysisResult r;
    r.path = path;
    r.size = data.size();
    r.headerHex = headerHex(data);
    r.printableStrings = printableStrings(data);
    FormatDetector::analyze(data,r);
    const bool updTlv = UpdParser::analyze(data,r);
    if (!updTlv) PkgParser::analyze(data,r);
    LanguageDetector::analyze(data,r);
    KorgDetector::analyze(data,r);
    UpdateDetector::analyze(path,data,r);
    KorgKnowledgeBase::enrichUpd(r);
    return r;
}

namespace {
void printCandidates(const char* title, const std::vector<Candidate>& v) {
    std::cout << "\n" << title << ":\n";
    if (v.empty()) { std::cout << "  Unknown\n"; return; }
    const std::size_t max = std::min<std::size_t>(v.size(),5);
    for (std::size_t i=0;i<max;++i) {
        const auto& c=v[i];
        std::cout << "  " << c.name << "  score=" << c.score << "  [" << c.confidence << "]\n";
        const std::size_t evmax = std::min<std::size_t>(c.evidence.size(),4);
        for (std::size_t j=0;j<evmax;++j)
            std::cout << "    - " << c.evidence[j].kind << ": " << c.evidence[j].value << " (+" << c.evidence[j].weight << ")\n";
    }
}

void jsonCandidates(const std::vector<Candidate>& v) {
    std::cout << "[";
    for (std::size_t i=0;i<v.size();++i) {
        if (i) std::cout << ",";
        const auto& c=v[i];
        std::cout << "{\"name\":\"" << jsonEscape(c.name) << "\",\"score\":" << c.score
                  << ",\"confidence\":\"" << jsonEscape(c.confidence) << "\",\"evidence\":[";
        for (std::size_t j=0;j<c.evidence.size();++j) {
            if (j) std::cout << ",";
            const auto& e=c.evidence[j];
            std::cout << "{\"kind\":\"" << jsonEscape(e.kind) << "\",\"value\":\"" << jsonEscape(e.value)
                      << "\",\"weight\":" << e.weight << "}";
        }
        std::cout << "]}";
    }
    std::cout << "]";
}
}

void Analyzer::printReport(const AnalysisResult& r) {
    std::cout << "KORG RE LAB V3 - static fingerprint + PKG report\n";
    std::cout << "File: " << r.path << "\nSize: " << r.size << " bytes\n";
    std::cout << "Format: " << r.format << "\nArchitecture: " << r.architecture;
    if (r.bits) std::cout << " (" << r.bits << "-bit)";
    std::cout << "\nEndian: " << r.endian << "\n";
    std::cout << "\nKorg update classification:\n";
    if (r.korgUpdate.recognized) {
        std::cout << "  Type: " << r.korgUpdate.family << "\n"
                  << "  Extension: " << r.korgUpdate.extension << "\n";
        if (!r.korgUpdate.modelHint.empty()) std::cout << "  Model hint: " << r.korgUpdate.modelHint << " [filename]\n";
        if (!r.korgUpdate.versionHint.empty()) std::cout << "  Version hint: " << r.korgUpdate.versionHint << " [filename]\n";
    } else {
        std::cout << "  Not classified as UPD/PKG by filename.\n";
    }

    printCandidates("Source-language/runtime candidates", r.languages);
    printCandidates("Compiler/toolchain candidates", r.toolchains);
    printCandidates("Platform/ABI candidates", r.platforms);

    std::cout << "\nKorg model candidates:\n";
    if (r.korgModels.empty()) std::cout << "  Unknown / no proven model signature\n";
    for (const auto& m : r.korgModels)
        std::cout << "  " << m.family << " / " << m.model << "  " << m.machineId << "  [" << m.confidence << "]\n"
                  << "    - " << m.evidence << "\n";

    if (r.korgUpdContainer.recognized) {
        std::cout << "\nKorg UPD TLV container:\n";
        std::cout << "  Header[16]: " << r.korgUpdContainer.packageHeader16 << "\n";
        std::cout << "  TLV records: " << r.korgUpdContainer.entries.size() << "\n";
        std::cout << "  Parsed bytes: " << r.korgUpdContainer.parsedBytes << " / " << r.size
                  << "  exact EOF=" << (r.korgUpdContainer.exactEof ? "yes" : "no") << "\n";
        std::cout << "  Directories: " << r.korgUpdContainer.dirCount
                  << "  zlib files: " << r.korgUpdContainer.fileCount
                  << "  raw files: " << r.korgUpdContainer.rawFileCount
                  << "  signature records: " << r.korgUpdContainer.signatureCount << "\n";
        if (!r.korgUpdContainer.metaStrings.empty()) {
            std::cout << "  Metadata: ";
            for (std::size_t i=0;i<r.korgUpdContainer.metaStrings.size();++i) {
                if (i) std::cout << " | ";
                std::cout << r.korgUpdContainer.metaStrings[i];
            }
            std::cout << "\n";
        }
        const std::size_t maxEntries = std::min<std::size_t>(r.korgUpdContainer.entries.size(), 160);
        for (std::size_t i=0;i<maxEntries;++i) {
            const auto& e = r.korgUpdContainer.entries[i];
            std::cout << "    " << hexOffset(e.offset) << " tag=0x" << std::hex << std::setw(4)
                      << std::setfill('0') << e.tag << std::dec << std::setfill(' ')
                      << " " << e.type << " len=" << e.length;
            if (!e.path.empty()) std::cout << " path=" << e.path;
            if (e.zlibStream) std::cout << " [zlib]";
            if (e.ecdsaDer) std::cout << " [DER signature candidate]";
            std::cout << "\n";
        }
        for (const auto& w : r.korgUpdContainer.warnings) std::cout << "  warning: " << w << "\n";
    }

    if (r.korgUpdContainer.recognized) {
        std::cout << "\nUPD metadata fields:\n";
        if (!r.korgUpdContainer.systemType.empty()) std::cout << "  System type: " << r.korgUpdContainer.systemType << "\n";
        if (!r.korgUpdContainer.softwareFamily.empty()) std::cout << "  Software family: " << r.korgUpdContainer.softwareFamily << "\n";
        if (!r.korgUpdContainer.platformCode.empty()) std::cout << "  Platform code: " << r.korgUpdContainer.platformCode << "\n";
        if (!r.korgUpdContainer.packageLabel.empty()) std::cout << "  Package label: " << r.korgUpdContainer.packageLabel << "\n";
        if (!r.korgUpdContainer.packageName.empty()) std::cout << "  Package name: " << r.korgUpdContainer.packageName << "\n";
        std::cout << "  Tag summary:\n";
        for (const auto& st : r.korgUpdContainer.tagStats) {
            std::cout << "    tag=0x" << std::hex << std::setw(4) << std::setfill('0') << st.tag
                      << std::dec << std::setfill(' ') << "  " << st.type
                      << "  count=" << st.count << "  bytes=" << st.totalPayloadBytes << "\n";
        }
    }

    if (!r.korgPlatformFacts.empty()) {
        std::cout << "\nKorg platform knowledge";
        if (!r.korgReferenceProfile.empty()) std::cout << " — " << r.korgReferenceProfile;
        std::cout << ":\n";
        for (const auto& f : r.korgPlatformFacts) {
            std::cout << "  [" << f.confidence << "] " << f.category << " / " << f.name << ": " << f.value << "\n";
            if (!f.evidence.empty()) std::cout << "    - " << f.evidence << "\n";
        }
    }

    if (r.korgPkg.recognized) {
        std::cout << "\nKorg PKG structure:\n";
        std::cout << "  Package MD5 field: " << r.korgPkg.packageMd5 << "\n";
        std::cout << "  PKG lib version: " << r.korgPkg.pkgLibVersion << "\n";
        std::cout << "  Package type: " << r.korgPkg.packageType;
        if (r.korgPkg.packageType == 2) std::cout << " (upgrade)";
        else if (r.korgPkg.packageType == 3) std::cout << " (full installation)";
        std::cout << "\n";
        std::cout << "  System type: " << r.korgPkg.systemType << "\n";
        std::cout << "  Build systems: " << r.korgPkg.buildSystem1 << " / " << r.korgPkg.buildSystem2 << "\n";
        std::cout << "  Created: " << r.korgPkg.creationDate << " " << r.korgPkg.creationTime << "\n";
        std::cout << "  Chunks: " << r.korgPkg.chunks.size() << "\n";
        const std::size_t maxChunks = std::min<std::size_t>(r.korgPkg.chunks.size(), 64);
        for (std::size_t i=0;i<maxChunks;++i) {
            const auto& c = r.korgPkg.chunks[i];
            std::cout << "    " << hexOffset(c.offset) << " id=" << c.id << " " << c.type
                      << " size=" << c.size;
            if (!c.path.empty()) std::cout << " path=" << c.path;
            if (c.id == 18) std::cout << " compression=" << static_cast<unsigned>(c.compression);
            std::cout << "\n";
        }
        for (const auto& w : r.korgPkg.warnings) std::cout << "  warning: " << w << "\n";
    }

    std::cout << "\nEmbedded objects:\n";
    if (r.embedded.empty()) std::cout << "  none recognized\n";
    for (const auto& e:r.embedded) std::cout << "  " << hexOffset(e.offset) << "  " << e.type << "  - " << e.note << "\n";

    std::cout << "\nAnalysis notes:\n";
    if (r.notes.empty()) std::cout << "  none\n";
    for (const auto& n:r.notes) std::cout << "  - " << n << "\n";
    std::cout << "\nConfidence rule: evidence is reported as Detected/Probable/Possible; unknown stays unknown.\n";
}

void Analyzer::printJson(const AnalysisResult& r) {
    std::cout << "{\"version\":\"3.0.0\",\"path\":\"" << jsonEscape(r.path) << "\",\"size\":" << r.size
              << ",\"format\":\"" << jsonEscape(r.format) << "\",\"architecture\":\"" << jsonEscape(r.architecture)
              << "\",\"bits\":" << r.bits << ",\"endian\":\"" << jsonEscape(r.endian) << "\",";
    std::cout << "\"languages\":"; jsonCandidates(r.languages);
    std::cout << ",\"toolchains\":"; jsonCandidates(r.toolchains);
    std::cout << ",\"platforms\":"; jsonCandidates(r.platforms);

    std::cout << ",\"korg_models\":[";
    for (std::size_t i=0;i<r.korgModels.size();++i) {
        if (i) std::cout << ",";
        const auto& m=r.korgModels[i];
        std::cout << "{\"family\":\"" << jsonEscape(m.family) << "\",\"model\":\"" << jsonEscape(m.model)
                  << "\",\"machine_id\":\"" << jsonEscape(m.machineId) << "\",\"confidence\":\""
                  << jsonEscape(m.confidence) << "\",\"evidence\":\"" << jsonEscape(m.evidence) << "\"}";
    }

    std::cout << "],\"korg_update\":{"
              << "\"recognized\":" << (r.korgUpdate.recognized ? "true" : "false")
              << ",\"family\":\"" << jsonEscape(r.korgUpdate.family) << "\""
              << ",\"extension\":\"" << jsonEscape(r.korgUpdate.extension) << "\""
              << ",\"model_hint\":\"" << jsonEscape(r.korgUpdate.modelHint) << "\""
              << ",\"version_hint\":\"" << jsonEscape(r.korgUpdate.versionHint) << "\""
              << ",\"split_part\":\"" << jsonEscape(r.korgUpdate.splitPart) << "\"}";

    std::cout << ",\"korg_upd_container\":{"
              << "\"recognized\":" << (r.korgUpdContainer.recognized ? "true" : "false")
              << ",\"exact_eof\":" << (r.korgUpdContainer.exactEof ? "true" : "false")
              << ",\"parsed_bytes\":" << r.korgUpdContainer.parsedBytes
              << ",\"files\":" << r.korgUpdContainer.fileCount
              << ",\"dirs\":" << r.korgUpdContainer.dirCount
              << ",\"raw_files\":" << r.korgUpdContainer.rawFileCount
              << ",\"signatures\":" << r.korgUpdContainer.signatureCount
              << ",\"system_type\":\"" << jsonEscape(r.korgUpdContainer.systemType) << "\""
              << ",\"software_family\":\"" << jsonEscape(r.korgUpdContainer.softwareFamily) << "\""
              << ",\"platform_code\":\"" << jsonEscape(r.korgUpdContainer.platformCode) << "\""
              << ",\"package_date\":\"" << jsonEscape(r.korgUpdContainer.packageDate) << "\""
              << ",\"package_time\":\"" << jsonEscape(r.korgUpdContainer.packageTime) << "\""
              << ",\"package_label\":\"" << jsonEscape(r.korgUpdContainer.packageLabel) << "\""
              << ",\"package_name\":\"" << jsonEscape(r.korgUpdContainer.packageName) << "\""
              << ",\"tag_stats\":[";
    for (std::size_t i=0;i<r.korgUpdContainer.tagStats.size();++i) {
        if (i) std::cout << ",";
        const auto& st=r.korgUpdContainer.tagStats[i];
        std::cout << "{\"tag\":" << st.tag << ",\"type\":\"" << jsonEscape(st.type)
                  << "\",\"count\":" << st.count << ",\"payload_bytes\":" << st.totalPayloadBytes << "}";
    }
    std::cout << ",\"entries\":[";
    for (std::size_t i=0;i<r.korgUpdContainer.entries.size();++i) {
        if (i) std::cout << ",";
        const auto& e=r.korgUpdContainer.entries[i];
        std::cout << "{\"tag\":" << e.tag << ",\"type\":\"" << jsonEscape(e.type)
                  << "\",\"offset\":" << e.offset << ",\"length\":" << e.length
                  << ",\"path\":\"" << jsonEscape(e.path) << "\",\"unpacked_size\":" << e.unpackedSize
                  << ",\"compressed_size\":" << e.compressedSize
                  << ",\"zlib\":" << (e.zlibStream ? "true" : "false")
                  << ",\"ecdsa_der_candidate\":" << (e.ecdsaDer ? "true" : "false") << "}";
    }
    std::cout << "]}";

    std::cout << ",\"korg_reference_profile\":\"" << jsonEscape(r.korgReferenceProfile) << "\""
              << ",\"korg_platform_facts\":[";
    for (std::size_t i=0;i<r.korgPlatformFacts.size();++i) {
        if (i) std::cout << ",";
        const auto& f=r.korgPlatformFacts[i];
        std::cout << "{\"category\":\"" << jsonEscape(f.category) << "\",\"name\":\"" << jsonEscape(f.name)
                  << "\",\"value\":\"" << jsonEscape(f.value) << "\",\"confidence\":\"" << jsonEscape(f.confidence)
                  << "\",\"evidence\":\"" << jsonEscape(f.evidence) << "\"}";
    }

    std::cout << "],\"korg_pkg\":{";
    std::cout << "\"recognized\":" << (r.korgPkg.recognized ? "true" : "false");
    if (r.korgPkg.recognized) {
        std::cout << ",\"package_md5\":\"" << jsonEscape(r.korgPkg.packageMd5) << "\""
                  << ",\"pkg_lib_version\":\"" << jsonEscape(r.korgPkg.pkgLibVersion) << "\""
                  << ",\"package_type\":" << r.korgPkg.packageType
                  << ",\"system_type\":\"" << jsonEscape(r.korgPkg.systemType) << "\""
                  << ",\"build_system_1\":\"" << jsonEscape(r.korgPkg.buildSystem1) << "\""
                  << ",\"build_system_2\":\"" << jsonEscape(r.korgPkg.buildSystem2) << "\""
                  << ",\"creation_date\":\"" << jsonEscape(r.korgPkg.creationDate) << "\""
                  << ",\"creation_time\":\"" << jsonEscape(r.korgPkg.creationTime) << "\""
                  << ",\"chunks\":[";
        for (std::size_t i=0;i<r.korgPkg.chunks.size();++i) {
            if (i) std::cout << ",";
            const auto& c=r.korgPkg.chunks[i];
            std::cout << "{\"id\":" << c.id << ",\"type\":\"" << jsonEscape(c.type)
                      << "\",\"offset\":" << c.offset << ",\"size\":" << c.size
                      << ",\"path\":\"" << jsonEscape(c.path) << "\",\"data_offset\":" << c.dataOffset
                      << ",\"data_size\":" << c.dataSize << ",\"compression\":" << static_cast<unsigned>(c.compression)
                      << ",\"md5\":\"" << jsonEscape(c.md5) << "\"}";
        }
        std::cout << "]";
    }
    std::cout << "},\"embedded\":[";
    for (std::size_t i=0;i<r.embedded.size();++i) {
        if (i) std::cout << ",";
        const auto& e=r.embedded[i];
        std::cout << "{\"type\":\"" << jsonEscape(e.type) << "\",\"offset\":" << e.offset
                  << ",\"note\":\"" << jsonEscape(e.note) << "\"}";
    }
    std::cout << "],\"notes\":[";
    for (std::size_t i=0;i<r.notes.size();++i) {
        if (i) std::cout << ",";
        std::cout << "\"" << jsonEscape(r.notes[i]) << "\"";
    }
    std::cout << "]}\n";
}
