#pragma once
#include "core/Model.h"
#include <cstdint>
#include <vector>

class FormatDetector {
public:
    static void analyze(const std::vector<std::uint8_t>& data, AnalysisResult& out);
};
