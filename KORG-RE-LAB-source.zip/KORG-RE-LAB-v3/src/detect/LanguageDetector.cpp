#include "detect/LanguageDetector.h"
#include "core/Utils.h"
#include <algorithm>
#include <map>

namespace {
struct Scorer {
    std::map<std::string, Candidate> m;
    void hit(const std::string& name, int weight, const std::string& kind, const std::string& value) {
        Candidate& c = m[name];
        c.name = name;
        c.score += weight;
        c.evidence.push_back({kind,value,weight});
    }
    std::vector<Candidate> finish() {
        std::vector<Candidate> v;
        for (auto& kv : m) {
            Candidate c = kv.second;
            if (c.score >= 80) c.confidence = "Detected";
            else if (c.score >= 45) c.confidence = "Probable";
            else c.confidence = "Possible";
            v.push_back(c);
        }
        std::sort(v.begin(), v.end(), [](const Candidate& a,const Candidate& b){return a.score>b.score;});
        return v;
    }
};

void sig(const std::vector<std::uint8_t>& d, Scorer& s, const std::string& name, int w,
         const std::string& needle, const std::string& kind="signature") {
    if (containsAscii(d, needle)) s.hit(name,w,kind,needle);
}
}

void LanguageDetector::analyze(const std::vector<std::uint8_t>& d, AnalysisResult& out) {
    Scorer lang, tool, plat;

    // Native languages / runtimes. These are fingerprints, not source recovery.
    sig(d,lang,"C++",55,"__cxa_throw"); sig(d,lang,"C++",55,"_ZSt"); sig(d,lang,"C++",35,"GLIBCXX_"); sig(d,lang,"C++",40,"_ZTV");
    sig(d,lang,"C++",35,"std::"); sig(d,lang,"C++",30,"__gxx_personality");
    sig(d,lang,"Objective-C",80,"objc_msgSend"); sig(d,lang,"Objective-C",70,"OBJC_CLASS_$_"); sig(d,lang,"Objective-C",60,"__objc_classlist");
    sig(d,lang,"Swift",80,"swift_release"); sig(d,lang,"Swift",80,"swift_retain"); sig(d,lang,"Swift",55,"libswiftCore");
    sig(d,lang,"Rust",85,"rust_eh_personality"); sig(d,lang,"Rust",70,"rust_begin_unwind"); sig(d,lang,"Rust",55,"core::panicking"); sig(d,lang,"Rust",50,"alloc::");
    sig(d,lang,"Go",95,".gopclntab"); sig(d,lang,"Go",95,".go.buildinfo"); sig(d,lang,"Go",70,"Go build ID:"); sig(d,lang,"Go",60,"runtime.main");
    sig(d,lang,"D",70,"_Dmain"); sig(d,lang,"D",50,"core.runtime");
    sig(d,lang,"Nim",75,"NimMain"); sig(d,lang,"Nim",45,"nimGC");
    sig(d,lang,"Zig",55,"zig_panic"); sig(d,lang,"Zig",45,"std.debug.panic");
    sig(d,lang,"Delphi/Object Pascal",70,"Borland Delphi"); sig(d,lang,"Free Pascal",85,"FPC"); sig(d,lang,"Free Pascal",60,"SYSTEM_$$_");
    sig(d,lang,"Ada",75,"GNAT"); sig(d,lang,"Ada",50,"ada__");
    sig(d,lang,"Fortran",65,"gfortran_"); sig(d,lang,"Fortran",55,"libgfortran");
    sig(d,lang,"Haskell",80,"GHC RTS"); sig(d,lang,"Haskell",60,"hs_init");
    sig(d,lang,"OCaml",80,"caml_startup"); sig(d,lang,"OCaml",60,"caml_raise");
    sig(d,lang,"Crystal",70,"Crystal::");

    if (out.format == "Java class") lang.hit("Java/JVM language",95,"format","Java class");
    if (out.format == "Android DEX") lang.hit("Java/Kotlin/other JVM language",90,"format","DEX");
    sig(d,lang,"Kotlin",90,"kotlin/Metadata"); sig(d,lang,"Kotlin",70,"kotlin/jvm/internal");
    sig(d,lang,"Scala",85,"scala/Predef"); sig(d,lang,"Scala",65,"ScalaSignature");
    sig(d,lang,".NET IL language",90,"BSJB"); sig(d,lang,".NET IL language",80,"mscoree.dll");
    sig(d,lang,"C#",35,"Microsoft.CSharp"); sig(d,lang,"F#",70,"FSharp.Core"); sig(d,lang,"VB.NET",45,"Microsoft.VisualBasic");
    if (out.format == "Erlang BEAM") lang.hit("Erlang/Elixir/BEAM language",95,"format","BEAM");
    if (out.format == "Lua bytecode") lang.hit("Lua",100,"format","Lua bytecode");
    if (out.format == "WebAssembly") lang.hit("WebAssembly source language unknown",90,"format","WASM");

    sig(d,lang,"Python",90,"#!/usr/bin/python"); sig(d,lang,"Python",70,"Py_Initialize"); sig(d,lang,"Python",60,"libpython");
    sig(d,lang,"Lua",80,"lua_pcall"); sig(d,lang,"Lua",70,"luaL_newstate");
    sig(d,lang,"JavaScript",80,"#!/usr/bin/env node"); sig(d,lang,"JavaScript",60,"node::Start"); sig(d,lang,"JavaScript",50,"libnode");
    sig(d,lang,"Ruby",90,"#!/usr/bin/ruby"); sig(d,lang,"Perl",90,"#!/usr/bin/perl");
    sig(d,lang,"POSIX shell",90,"#!/bin/sh"); sig(d,lang,"Bash",90,"#!/bin/bash");
    sig(d,lang,"PHP",90,"<?php");

    // Compiler / linker fingerprints.
    sig(d,tool,"GCC",85,"GCC: ("); sig(d,tool,"GCC",55,"GCC_");
    sig(d,tool,"Clang/LLVM",90,"clang version"); sig(d,tool,"Clang/LLVM",50,"LLVM");
    sig(d,tool,"Apple Clang",95,"Apple LLVM version");
    sig(d,tool,"MSVC",80,"Microsoft Visual C++"); sig(d,tool,"MSVC",55,"__security_cookie");
    sig(d,tool,"Intel ICC/ICX",80,"Intel(R) C++"); sig(d,tool,"Intel ICC/ICX",60,"Intel(R) oneAPI");
    sig(d,tool,"ARMCC/ARMClang",80,"ARM C/C++ Compiler"); sig(d,tool,"ARMCC/ARMClang",70,"ARM Compiler");
    sig(d,tool,"IAR",90,"IAR C/C++ Compiler"); sig(d,tool,"Green Hills",85,"Green Hills Software");
    sig(d,tool,"Metrowerks/CodeWarrior",85,"Metrowerks"); sig(d,tool,"Borland",80,"Borland C++");
    sig(d,tool,"Watcom",80,"Open Watcom"); sig(d,tool,"TinyCC",80,"tcc version");
    sig(d,tool,"rustc",95,"rust_eh_personality"); sig(d,tool,"Go toolchain",95,"Go build ID:");
    sig(d,tool,"Free Pascal Compiler",95,"FPC"); sig(d,tool,"GNAT",90,"GNAT"); sig(d,tool,"GFortran",90,"libgfortran");
    sig(d,tool,"GHC",90,"GHC RTS"); sig(d,tool,"Emscripten",90,"emscripten");
    sig(d,tool,"GNU ld/binutils",65,"GNU ld"); sig(d,tool,"gold linker",70,"GNU gold"); sig(d,tool,"LLD",70,"LLD");

    sig(d,plat,"Linux",85,"Linux version "); sig(d,plat,"Linux",65,"/lib/ld-linux"); sig(d,plat,"Linux",50,"GLIBC_");
    sig(d,plat,"U-Boot",95,"U-Boot "); sig(d,plat,"ARM EABI",75,"__aeabi_");
    sig(d,plat,"GNU/Linux userspace",65,"/bin/sh"); sig(d,plat,"BusyBox",95,"BusyBox v");
    sig(d,plat,"Qt",80,"libQtCore"); sig(d,plat,"Qt",65,"QObject");

    if ((out.format == "ELF" || out.format == "PE/COFF" || out.format == "Mach-O") && lang.m.empty()) {
        lang.hit("C or C++ (not distinguishable yet)",25,"heuristic","native binary with no distinctive managed/runtime signature");
    }

    out.languages = lang.finish();
    out.toolchains = tool.finish();
    out.platforms = plat.finish();
}
