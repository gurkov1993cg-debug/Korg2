#include "detect/FormatDetector.h"
#include "core/Utils.h"

namespace {
std::string elfMachine(std::uint16_t m) {
    switch (m) {
        case 2: return "SPARC";
        case 3: return "x86";
        case 8: return "MIPS";
        case 20: return "PowerPC";
        case 21: return "PowerPC64";
        case 40: return "ARM";
        case 42: return "SuperH";
        case 62: return "x86_64";
        case 140: return "TI TMS320C6000";
        case 183: return "AArch64";
        case 243: return "RISC-V";
        default: return "ELF machine " + std::to_string(m);
    }
}

std::string peMachine(std::uint16_t m) {
    switch (m) {
        case 0x014c: return "x86";
        case 0x8664: return "x86_64";
        case 0x01c0: case 0x01c2: case 0x01c4: return "ARM";
        case 0xaa64: return "AArch64";
        default: return "PE machine " + std::to_string(m);
    }
}

std::string machoCpu(std::uint32_t cpu) {
    const std::uint32_t base = cpu & 0x00ffffffu;
    const bool abi64 = (cpu & 0x01000000u) != 0;
    switch (base) {
        case 7: return abi64 ? "x86_64" : "x86";
        case 12: return abi64 ? "AArch64" : "ARM";
        case 18: return abi64 ? "PowerPC64" : "PowerPC";
        default: return "Mach-O CPU " + std::to_string(cpu);
    }
}
}

void FormatDetector::analyze(const std::vector<std::uint8_t>& d, AnalysisResult& out) {
    if (startsWith(d, {0x7f,'E','L','F'})) {
        out.format = "ELF";
        if (d.size() > 19) {
            out.bits = d[4] == 1 ? 32 : (d[4] == 2 ? 64 : 0);
            out.endian = d[5] == 1 ? "Little" : (d[5] == 2 ? "Big" : "Unknown");
            const std::uint16_t mach = (d[5] == 2) ? rd16be(d,18) : rd16le(d,18);
            out.architecture = elfMachine(mach);
        }
        return;
    }

    if (startsWith(d, {'M','Z'})) {
        const std::uint32_t peoff = rd32le(d, 0x3c);
        if (peoff + 26 <= d.size() && d[peoff]=='P' && d[peoff+1]=='E' && d[peoff+2]==0 && d[peoff+3]==0) {
            out.format = "PE/COFF";
            out.endian = "Little";
            out.architecture = peMachine(rd16le(d, peoff+4));
            const std::uint16_t magic = rd16le(d, peoff+24);
            out.bits = magic == 0x20b ? 64 : (magic == 0x10b ? 32 : 0);
            return;
        }
        out.format = "DOS MZ / unknown PE-like";
        return;
    }

    if (d.size() >= 8) {
        const std::uint32_t be = rd32be(d,0);
        if (be == 0xfeedfaceu || be == 0xfeedfacfu || be == 0xcefaedfeu || be == 0xcffaedfeu) {
            const bool swapped = (be == 0xcefaedfeu || be == 0xcffaedfeu);
            out.format = "Mach-O";
            out.bits = (be == 0xfeedfacfu || be == 0xcffaedfeu) ? 64 : 32;
            out.endian = swapped ? "Little" : "Big";
            const std::uint32_t cpu = swapped ? rd32le(d,4) : rd32be(d,4);
            out.architecture = machoCpu(cpu);
            return;
        }
        if (be == 0xcafebabeu || be == 0xbebafecau) {
            out.format = containsAscii(d, "java/lang/Object") ? "Java class" : "Mach-O FAT / universal binary";
            return;
        }
    }

    if (startsWith(d, {'d','e','x','\n'})) { out.format = "Android DEX"; return; }
    if (startsWith(d, {0x00,'a','s','m'})) { out.format = "WebAssembly"; return; }
    if (startsWith(d, {'P','K',0x03,0x04})) { out.format = "ZIP-compatible container"; return; }
    if (startsWith(d, {'#','!'})) { out.format = "Script / text executable"; return; }
    if (startsWith(d, {0x1b,'L','u','a'})) { out.format = "Lua bytecode"; return; }
    if (startsWith(d, {'F','O','R','1'})) { out.format = "Erlang BEAM"; return; }
    if (startsWith(d, {0x1f,0x8b,0x08})) { out.format = "gzip stream"; return; }
    if (startsWith(d, {'h','s','q','s'}) || startsWith(d, {'s','q','s','h'})) { out.format = "SquashFS image"; return; }
    if (startsWith(d, {'0','7','0','7','0','1'})) { out.format = "CPIO newc archive"; return; }
}
