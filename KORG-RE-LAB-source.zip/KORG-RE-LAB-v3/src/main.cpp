#include "core/Analyzer.h"
#include <exception>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    bool json = false;
    std::vector<std::string> files;

    for (int i=1;i<argc;++i) {
        const std::string a = argv[i];
        if (a == "--json") json = true;
        else if (a == "--version") { std::cout << "KORG RE LAB 3.0.0\n"; return 0; }
        else if (a == "--help" || a == "-h") {
            std::cout << "Usage: korg-re-lab [--json] <firmware-or-binary> [more files...]\n";
            return 0;
        } else files.push_back(a);
    }

    if (files.empty()) {
        std::cout << "Usage: korg-re-lab [--json] <firmware-or-binary> [more files...]\n";
        return 0;
    }

    try {
        for (std::size_t i=0;i<files.size();++i) {
            if (!json && i>0) std::cout << "\n============================================================\n";
            const AnalysisResult r = Analyzer::analyzeFile(files[i]);
            if (json) Analyzer::printJson(r); else Analyzer::printReport(r);
        }
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
