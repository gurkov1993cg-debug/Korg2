#import <Cocoa/Cocoa.h>

#include "core/Analyzer.h"
#include <algorithm>
#include <exception>
#include <sstream>
#include <string>

static std::string buildReport(const AnalysisResult& r) {
    std::ostringstream out;
    out << "KORG RE LAB 3.0.0\n";
    out << "============================================================\n";
    out << "File: " << r.path << "\n";
    out << "Size: " << r.size << " bytes\n";
    out << "Format: " << r.format << "\n";
    out << "Architecture: " << r.architecture;
    if (r.bits) out << " (" << r.bits << "-bit)";
    out << "\nEndian: " << r.endian << "\n\n";

    auto candidates = [&out](const char* title, const std::vector<Candidate>& v) {
        out << title << ":\n";
        if (v.empty()) {
            out << "  UNKNOWN\n\n";
            return;
        }
        const std::size_t count = std::min<std::size_t>(v.size(), 8);
        for (std::size_t i = 0; i < count; ++i) {
            const Candidate& c = v[i];
            out << "  " << c.name << "   score=" << c.score << "   [" << c.confidence << "]\n";
            const std::size_t evCount = std::min<std::size_t>(c.evidence.size(), 5);
            for (std::size_t j = 0; j < evCount; ++j) {
                out << "    - " << c.evidence[j].kind << ": " << c.evidence[j].value
                    << " (+" << c.evidence[j].weight << ")\n";
            }
        }
        out << "\n";
    };

    candidates("Source language / runtime", r.languages);
    candidates("Compiler / toolchain", r.toolchains);
    candidates("Platform / ABI", r.platforms);

    out << "Korg model candidates:\n";
    if (r.korgModels.empty()) out << "  UNKNOWN / no proven model signature\n";
    for (const auto& m : r.korgModels) {
        out << "  " << m.family << " / " << m.model;
        if (!m.machineId.empty()) out << "   " << m.machineId;
        out << "   [" << m.confidence << "]\n";
        if (!m.evidence.empty()) out << "    - " << m.evidence << "\n";
    }
    out << "\n";

    if (r.korgPkg.recognized) {
        out << "Korg PKG structure:\n";
        out << "  Package MD5 field: " << r.korgPkg.packageMd5 << "\n";
        out << "  PKG lib version: " << r.korgPkg.pkgLibVersion << "\n";
        out << "  Package type: " << r.korgPkg.packageType << "\n";
        out << "  System type: " << r.korgPkg.systemType << "\n";
        out << "  Build systems: " << r.korgPkg.buildSystem1 << " / " << r.korgPkg.buildSystem2 << "\n";
        out << "  Created: " << r.korgPkg.creationDate << " " << r.korgPkg.creationTime << "\n";
        out << "  Chunks: " << r.korgPkg.chunks.size() << "\n";
        const std::size_t chunkCount = std::min<std::size_t>(r.korgPkg.chunks.size(), 128);
        for (std::size_t i = 0; i < chunkCount; ++i) {
            const auto& c = r.korgPkg.chunks[i];
            out << "    id=" << c.id << "  " << c.type << "  size=" << c.size;
            if (!c.path.empty()) out << "  path=" << c.path;
            out << "\n";
        }
        for (const auto& w : r.korgPkg.warnings) out << "  WARNING: " << w << "\n";
        out << "\n";
    }

    out << "Embedded objects:\n";
    if (r.embedded.empty()) out << "  none recognized\n";
    for (const auto& e : r.embedded) {
        out << "  offset=0x" << std::hex << e.offset << std::dec << "  " << e.type;
        if (!e.note.empty()) out << "  - " << e.note;
        out << "\n";
    }
    out << "\nAnalysis notes:\n";
    if (r.notes.empty()) out << "  none\n";
    for (const auto& n : r.notes) out << "  - " << n << "\n";
    out << "\nEvidence rule: DETECTED / PROBABLE / POSSIBLE / UNKNOWN. Unknowns are not guessed.\n";
    return out.str();
}

@interface KorgRELabDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, strong) NSWindow *window;
@property(nonatomic, strong) NSTextView *reportView;
@property(nonatomic, strong) NSTextField *statusLabel;
@end

@implementation KorgRELabDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    (void)notification;

    const NSRect frame = NSMakeRect(0, 0, 980, 680);
    self.window = [[NSWindow alloc] initWithContentRect:frame
                                             styleMask:(NSWindowStyleMaskTitled |
                                                        NSWindowStyleMaskClosable |
                                                        NSWindowStyleMaskMiniaturizable |
                                                        NSWindowStyleMaskResizable)
                                               backing:NSBackingStoreBuffered
                                                 defer:NO];
    [self.window setTitle:@"KORG RE LAB 3.0.0"];
    [self.window center];
    [self.window setMinSize:NSMakeSize(760, 500)];

    NSView *content = [self.window contentView];

    NSTextField *title = [[NSTextField alloc] initWithFrame:NSMakeRect(22, 630, 560, 30)];
    [title setStringValue:@"KORG RE LAB"];
    [title setFont:[NSFont boldSystemFontOfSize:22.0]];
    [title setBezeled:NO];
    [title setDrawsBackground:NO];
    [title setEditable:NO];
    [title setSelectable:NO];
    [title setAutoresizingMask:NSViewMaxXMargin | NSViewMinYMargin];
    [content addSubview:title];

    NSTextField *subtitle = [[NSTextField alloc] initWithFrame:NSMakeRect(24, 607, 720, 20)];
    [subtitle setStringValue:@"Korg firmware, package and binary reverse-engineering laboratory"];
    [subtitle setTextColor:[NSColor secondaryLabelColor]];
    [subtitle setBezeled:NO];
    [subtitle setDrawsBackground:NO];
    [subtitle setEditable:NO];
    [subtitle setSelectable:NO];
    [subtitle setAutoresizingMask:NSViewWidthSizable | NSViewMinYMargin];
    [content addSubview:subtitle];

    NSButton *openButton = [[NSButton alloc] initWithFrame:NSMakeRect(800, 616, 150, 34)];
    [openButton setTitle:@"Open File…"];
    [openButton setBezelStyle:NSBezelStyleRounded];
    [openButton setTarget:self];
    [openButton setAction:@selector(openFile:)];
    [openButton setAutoresizingMask:NSViewMinXMargin | NSViewMinYMargin];
    [content addSubview:openButton];

    self.statusLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(24, 578, 920, 20)];
    [self.statusLabel setStringValue:@"Ready — open a Korg PKG/UPD/firmware image or any binary for analysis."];
    [self.statusLabel setBezeled:NO];
    [self.statusLabel setDrawsBackground:NO];
    [self.statusLabel setEditable:NO];
    [self.statusLabel setSelectable:NO];
    [self.statusLabel setAutoresizingMask:NSViewWidthSizable | NSViewMinYMargin];
    [content addSubview:self.statusLabel];

    NSScrollView *scroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(20, 20, 940, 545)];
    [scroll setBorderType:NSBezelBorder];
    [scroll setHasVerticalScroller:YES];
    [scroll setHasHorizontalScroller:YES];
    [scroll setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];

    self.reportView = [[NSTextView alloc] initWithFrame:[[scroll contentView] bounds]];
    [self.reportView setMinSize:NSMakeSize(0.0, 0.0)];
    [self.reportView setMaxSize:NSMakeSize(CGFLOAT_MAX, CGFLOAT_MAX)];
    [self.reportView setVerticallyResizable:YES];
    [self.reportView setHorizontallyResizable:YES];
    [self.reportView setAutoresizingMask:NSViewWidthSizable];
    [[self.reportView textContainer] setContainerSize:NSMakeSize(CGFLOAT_MAX, CGFLOAT_MAX)];
    [[self.reportView textContainer] setWidthTracksTextView:NO];
    [self.reportView setEditable:NO];
    [self.reportView setSelectable:YES];
    [self.reportView setFont:[NSFont userFixedPitchFontOfSize:12.0]];
    [self.reportView setString:@"KORG RE LAB 3.0.0\n\nOpen a file to begin analysis.\n"];
    [scroll setDocumentView:self.reportView];
    [content addSubview:scroll];

    [self.window makeKeyAndOrderFront:nil];
    [NSApp activateIgnoringOtherApps:YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    (void)sender;
    return YES;
}

- (void)openFile:(id)sender {
    (void)sender;
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setCanChooseFiles:YES];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO];
    [panel setTitle:@"Choose Korg firmware, package or binary"];
    if ([panel runModal] == NSModalResponseOK) {
        [self analyzeURL:[[panel URLs] firstObject]];
    }
}

- (void)analyzeURL:(NSURL *)url {
    if (!url) return;
    NSString *path = [url path];
    [self.statusLabel setStringValue:[NSString stringWithFormat:@"Analyzing %@…", [path lastPathComponent]]];
    [self.reportView setString:@"Analyzing…\n"];
    [[self.reportView enclosingScrollView] displayIfNeeded];

    @try {
        try {
            const AnalysisResult result = Analyzer::analyzeFile(std::string([path fileSystemRepresentation]));
            const std::string report = buildReport(result);
            NSString *text = [[NSString alloc] initWithBytes:report.data()
                                                     length:report.size()
                                                   encoding:NSUTF8StringEncoding];
            if (!text) text = @"Analysis completed, but the report could not be converted to UTF-8.";
            [self.reportView setString:text];
            [self.reportView scrollRangeToVisible:NSMakeRange(0, 0)];
            [self.statusLabel setStringValue:[NSString stringWithFormat:@"Analysis complete — %@", [path lastPathComponent]]];
        } catch (const std::exception& e) {
            NSString *message = [NSString stringWithUTF8String:e.what()];
            [self.reportView setString:[NSString stringWithFormat:@"Analysis failed:\n%@\n", message ?: @"Unknown C++ error"]];
            [self.statusLabel setStringValue:@"Analysis failed"];
        }
    } @catch (NSException *exception) {
        [self.reportView setString:[NSString stringWithFormat:@"Application error:\n%@\n", [exception reason]]];
        [self.statusLabel setStringValue:@"Application error"];
    }
}

- (void)application:(NSApplication *)sender openFiles:(NSArray<NSString *> *)filenames {
    (void)sender;
    if ([filenames count] > 0) {
        [self analyzeURL:[NSURL fileURLWithPath:[filenames objectAtIndex:0]]];
    }
    [NSApp replyToOpenOrPrint:NSApplicationDelegateReplySuccess];
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        for (int i = 1; i < argc; ++i) {
            const std::string arg(argv[i]);
            if (arg == "--version") {
                fprintf(stdout, "KORG RE LAB 3.0.0\n");
                return 0;
            }
            if (arg == "--self-test") {
                fprintf(stdout, "KORG RE LAB GUI bundle self-test OK\n");
                return 0;
            }
            if (arg == "--help" || arg == "-h") {
                fprintf(stdout, "KORG RE LAB is a native macOS GUI application. Use Open File in the application window.\n");
                return 0;
            }
        }

        NSApplication *app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        KorgRELabDelegate *delegate = [[KorgRELabDelegate alloc] init];
        [app setDelegate:delegate];
        [app run];
    }
    return 0;
}
