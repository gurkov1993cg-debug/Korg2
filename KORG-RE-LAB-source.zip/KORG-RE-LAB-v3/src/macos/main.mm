#import <Cocoa/Cocoa.h>

#include "core/Analyzer.h"
#include <algorithm>
#include <exception>
#include <iomanip>
#include <sstream>
#include <string>

static std::string buildReport(const AnalysisResult& r) {
    std::ostringstream out;
    out << "KORG RE LAB 3.0.0\n";
    out << "============================================================\n";
    out << "File: " << r.path << "\n";
    out << "Size: " << r.size << " bytes\n";
    out << "Format: " << r.format << "\n";
    out << "Architecture: " << r.architecture;
    if (r.bits) out << " (" << r.bits << "-bit)";
    out << "\nEndian: " << r.endian << "\n\n";

    out << "Korg update classification:\n";
    if (r.korgUpdate.recognized) {
        out << "  Type: " << r.korgUpdate.family << "\n";
        out << "  Extension: " << r.korgUpdate.extension << "\n";
        if (!r.korgUpdate.modelHint.empty()) out << "  Model hint: " << r.korgUpdate.modelHint << "  [filename evidence]\n";
        if (!r.korgUpdate.versionHint.empty()) out << "  Version hint: " << r.korgUpdate.versionHint << "  [filename evidence]\n";
        if (!r.korgUpdate.splitPart.empty()) out << "  Split part: " << r.korgUpdate.splitPart << "\n";
        out << "  Evidence: " << r.korgUpdate.evidence << "\n";
    } else {
        out << "  Not classified as UPD/PKG by filename.\n";
    }
    out << "\n";

    auto candidates = [&out](const char* title, const std::vector<Candidate>& v) {
        out << title << ":\n";
        if (v.empty()) {
            out << "  UNKNOWN\n\n";
            return;
        }
        const std::size_t count = std::min<std::size_t>(v.size(), 8);
        for (std::size_t i = 0; i < count; ++i) {
            const Candidate& c = v[i];
            out << "  " << c.name << "   score=" << c.score << "   [" << c.confidence << "]\n";
            const std::size_t evCount = std::min<std::size_t>(c.evidence.size(), 5);
            for (std::size_t j = 0; j < evCount; ++j) {
                out << "    - " << c.evidence[j].kind << ": " << c.evidence[j].value
                    << " (+" << c.evidence[j].weight << ")\n";
            }
        }
        out << "\n";
    };

    candidates("Source language / runtime", r.languages);
    candidates("Compiler / toolchain", r.toolchains);
    candidates("Platform / ABI", r.platforms);

    out << "Korg model candidates:\n";
    if (r.korgModels.empty()) out << "  UNKNOWN / no proven model signature\n";
    for (const auto& m : r.korgModels) {
        out << "  " << m.family << " / " << m.model;
        if (!m.machineId.empty()) out << "   " << m.machineId;
        out << "   [" << m.confidence << "]\n";
        if (!m.evidence.empty()) out << "    - " << m.evidence << "\n";
    }
    out << "\n";

    if (r.korgUpdContainer.recognized) {
        out << "Korg UPD TLV container — VERIFIED STRUCTURE:\n";
        out << "  16-byte package header: " << r.korgUpdContainer.packageHeader16 << "\n";
        out << "  Parsed TLV records: " << r.korgUpdContainer.entries.size() << "\n";
        out << "  Parsed bytes: " << r.korgUpdContainer.parsedBytes << " / " << r.size << "\n";
        out << "  Chain ends exactly at EOF: " << (r.korgUpdContainer.exactEof ? "YES" : "NO") << "\n";
        out << "  Directories: " << r.korgUpdContainer.dirCount
            << "   zlib files: " << r.korgUpdContainer.fileCount
            << "   raw files: " << r.korgUpdContainer.rawFileCount
            << "   signatures: " << r.korgUpdContainer.signatureCount << "\n";
        if (!r.korgUpdContainer.metaStrings.empty()) {
            out << "  Metadata:\n";
            if (!r.korgUpdContainer.systemType.empty()) out << "    System type: " << r.korgUpdContainer.systemType << "\n";
            if (!r.korgUpdContainer.softwareFamily.empty()) out << "    Software family: " << r.korgUpdContainer.softwareFamily << "\n";
            if (!r.korgUpdContainer.platformCode.empty()) out << "    Platform code: " << r.korgUpdContainer.platformCode << "\n";
            if (!r.korgUpdContainer.packageDate.empty()) out << "    Package date/time: " << r.korgUpdContainer.packageDate << " " << r.korgUpdContainer.packageTime << "\n";
            if (!r.korgUpdContainer.packageLabel.empty()) out << "    Package label: " << r.korgUpdContainer.packageLabel << "\n";
            if (!r.korgUpdContainer.packageName.empty()) out << "    Package name: " << r.korgUpdContainer.packageName << "\n";
        }
        out << "\n  TLV tag summary:\n";
        for (const auto& st : r.korgUpdContainer.tagStats) {
            out << "    tag=0x" << std::hex << std::setw(4) << std::setfill('0') << st.tag
                << std::dec << std::setfill(' ') << "  " << st.type
                << "  count=" << st.count << "  payload-bytes=" << st.totalPayloadBytes << "\n";
        }
        out << "\n  Container entries / firmware file table:\n";
        const std::size_t entryCount = std::min<std::size_t>(r.korgUpdContainer.entries.size(), 220);
        for (std::size_t i=0;i<entryCount;++i) {
            const auto& e = r.korgUpdContainer.entries[i];
            out << "    " << hexOffset(e.offset) << "  tag=0x" << std::hex << std::setw(4)
                << std::setfill('0') << e.tag << std::dec << std::setfill(' ')
                << "  " << e.type << "  len=" << e.length;
            if (!e.path.empty()) out << "  " << e.path;
            if (e.zlibStream) out << "  [zlib]";
            if (e.ecdsaDer) out << "  [DER/ECDSA candidate]";
            out << "\n";
        }
        for (const auto& w : r.korgUpdContainer.warnings) out << "  WARNING: " << w << "\n";
        out << "\n";
    }

    if (!r.korgPlatformFacts.empty()) {
        out << "Korg platform / firmware knowledge";
        if (!r.korgReferenceProfile.empty()) out << " — " << r.korgReferenceProfile;
        out << ":\n";
        out << "  DETECTED = evidence exists in the current package.\n";
        out << "  REFERENCE-VERIFIED = validated on the supplied Pa600 v2.1.1 research profile.\n\n";
        std::string lastCategory;
        for (const auto& f : r.korgPlatformFacts) {
            if (f.category != lastCategory) {
                out << "  [" << f.category << "]\n";
                lastCategory = f.category;
            }
            out << "    " << f.name << ": " << f.value << "  [" << f.confidence << "]\n";
            if (!f.evidence.empty()) out << "      evidence: " << f.evidence << "\n";
        }
        out << "\n";
    }

    if (r.korgPkg.recognized) {
        out << "Korg PKG structure:\n";
        out << "  Package MD5 field: " << r.korgPkg.packageMd5 << "\n";
        out << "  PKG lib version: " << r.korgPkg.pkgLibVersion << "\n";
        out << "  Package type: " << r.korgPkg.packageType << "\n";
        out << "  System type: " << r.korgPkg.systemType << "\n";
        out << "  Build systems: " << r.korgPkg.buildSystem1 << " / " << r.korgPkg.buildSystem2 << "\n";
        out << "  Created: " << r.korgPkg.creationDate << " " << r.korgPkg.creationTime << "\n";
        out << "  Chunks: " << r.korgPkg.chunks.size() << "\n";
        const std::size_t chunkCount = std::min<std::size_t>(r.korgPkg.chunks.size(), 128);
        for (std::size_t i = 0; i < chunkCount; ++i) {
            const auto& c = r.korgPkg.chunks[i];
            out << "    id=" << c.id << "  " << c.type << "  size=" << c.size;
            if (!c.path.empty()) out << "  path=" << c.path;
            out << "\n";
        }
        for (const auto& w : r.korgPkg.warnings) out << "  WARNING: " << w << "\n";
        out << "\n";
    }

    out << "Embedded objects:\n";
    if (r.embedded.empty()) out << "  none recognized\n";
    for (const auto& e : r.embedded) {
        out << "  offset=0x" << std::hex << e.offset << std::dec << "  " << e.type;
        if (!e.note.empty()) out << "  - " << e.note;
        out << "\n";
    }
    out << "\nRaw header preview (first 64 bytes):\n";
    if (r.headerHex.empty()) out << "  <empty file>\n";
    else out << r.headerHex << "\n";

    out << "\nPrintable strings (first " << r.printableStrings.size() << "):\n";
    if (r.printableStrings.empty()) out << "  none found\n";
    for (const auto& str : r.printableStrings) out << "  " << str << "\n";

    out << "\nAnalysis notes:\n";
    if (r.notes.empty()) out << "  none\n";
    for (const auto& n : r.notes) out << "  - " << n << "\n";
    out << "\nEvidence rule: DETECTED / PROBABLE / POSSIBLE / UNKNOWN. Unknowns are not guessed.\n";
    return out.str();
}

@interface KorgRELabDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, strong) NSWindow *window;
@property(nonatomic, strong) NSTextView *reportView;
@property(nonatomic, strong) NSTextField *statusLabel;
@end

@implementation KorgRELabDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    (void)notification;

    const NSRect frame = NSMakeRect(0, 0, 980, 680);
    self.window = [[NSWindow alloc] initWithContentRect:frame
                                             styleMask:(NSWindowStyleMaskTitled |
                                                        NSWindowStyleMaskClosable |
                                                        NSWindowStyleMaskMiniaturizable |
                                                        NSWindowStyleMaskResizable)
                                               backing:NSBackingStoreBuffered
                                                 defer:NO];
    [self.window setTitle:@"KORG RE LAB 3.0.0"];
    [self.window center];
    [self.window setMinSize:NSMakeSize(760, 500)];

    NSView *content = [self.window contentView];

    NSTextField *title = [[NSTextField alloc] initWithFrame:NSMakeRect(22, 630, 560, 30)];
    [title setStringValue:@"KORG RE LAB"];
    [title setFont:[NSFont boldSystemFontOfSize:22.0]];
    [title setBezeled:NO];
    [title setDrawsBackground:NO];
    [title setEditable:NO];
    [title setSelectable:NO];
    [title setAutoresizingMask:NSViewMaxXMargin | NSViewMinYMargin];
    [content addSubview:title];

    NSTextField *subtitle = [[NSTextField alloc] initWithFrame:NSMakeRect(24, 607, 720, 20)];
    [subtitle setStringValue:@"Korg firmware, package and binary reverse-engineering laboratory"];
    [subtitle setTextColor:[NSColor secondaryLabelColor]];
    [subtitle setBezeled:NO];
    [subtitle setDrawsBackground:NO];
    [subtitle setEditable:NO];
    [subtitle setSelectable:NO];
    [subtitle setAutoresizingMask:NSViewWidthSizable | NSViewMinYMargin];
    [content addSubview:subtitle];

    NSButton *openButton = [[NSButton alloc] initWithFrame:NSMakeRect(800, 616, 150, 34)];
    [openButton setTitle:@"Open File…"];
    [openButton setBezelStyle:NSBezelStyleRounded];
    [openButton setTarget:self];
    [openButton setAction:@selector(openFile:)];
    [openButton setAutoresizingMask:NSViewMinXMargin | NSViewMinYMargin];
    [content addSubview:openButton];

    self.statusLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(24, 578, 920, 20)];
    [self.statusLabel setStringValue:@"Ready — open a Korg PKG/UPD/firmware image or any binary for analysis."];
    [self.statusLabel setBezeled:NO];
    [self.statusLabel setDrawsBackground:NO];
    [self.statusLabel setEditable:NO];
    [self.statusLabel setSelectable:NO];
    [self.statusLabel setAutoresizingMask:NSViewWidthSizable | NSViewMinYMargin];
    [content addSubview:self.statusLabel];

    NSScrollView *scroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(20, 20, 940, 545)];
    [scroll setBorderType:NSBezelBorder];
    [scroll setHasVerticalScroller:YES];
    [scroll setHasHorizontalScroller:NO];
    [scroll setAutohidesScrollers:YES];
    [scroll setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];

    NSRect textFrame = [[scroll contentView] bounds];
    if (textFrame.size.width < 400.0) textFrame.size.width = 920.0;
    if (textFrame.size.height < 200.0) textFrame.size.height = 525.0;
    self.reportView = [[NSTextView alloc] initWithFrame:textFrame];
    [self.reportView setMinSize:NSMakeSize(400.0, textFrame.size.height)];
    [self.reportView setMaxSize:NSMakeSize(CGFLOAT_MAX, CGFLOAT_MAX)];
    [self.reportView setVerticallyResizable:YES];
    [self.reportView setHorizontallyResizable:NO];
    [self.reportView setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    [[self.reportView textContainer] setContainerSize:NSMakeSize(textFrame.size.width, CGFLOAT_MAX)];
    [[self.reportView textContainer] setWidthTracksTextView:YES];
    [[self.reportView textContainer] setLineFragmentPadding:6.0];
    [self.reportView setTextContainerInset:NSMakeSize(8.0, 8.0)];
    [self.reportView setEditable:NO];
    [self.reportView setSelectable:YES];
    [self.reportView setRichText:NO];
    [self.reportView setFont:[NSFont userFixedPitchFontOfSize:12.0]];
    [self.reportView setString:@"KORG RE LAB 3.0.0\n\nOpen a Korg UPD, PKG or firmware file to begin analysis.\n"];
    [scroll setDocumentView:self.reportView];
    [content addSubview:scroll];

    [self.window makeKeyAndOrderFront:nil];
    [NSApp activateIgnoringOtherApps:YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    (void)sender;
    return YES;
}

- (void)openFile:(id)sender {
    (void)sender;
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setCanChooseFiles:YES];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO];
    [panel setTitle:@"Choose Korg firmware, package or binary"];
    if ([panel runModal] == NSModalResponseOK) {
        [self analyzeURL:[[panel URLs] firstObject]];
    }
}

- (void)analyzeURL:(NSURL *)url {
    if (!url) return;
    NSString *path = [url path];
    [self.statusLabel setStringValue:[NSString stringWithFormat:@"Analyzing %@…", [path lastPathComponent]]];
    [self.reportView setString:@"Analyzing…\n"];
    [[self.reportView enclosingScrollView] displayIfNeeded];

    @try {
        try {
            const AnalysisResult result = Analyzer::analyzeFile(std::string([path fileSystemRepresentation]));
            const std::string report = buildReport(result);
            NSString *text = [[NSString alloc] initWithBytes:report.data()
                                                     length:report.size()
                                                   encoding:NSUTF8StringEncoding];
            if (!text) text = @"Analysis completed, but the report could not be converted to UTF-8.";
            if ([text length] == 0) text = @"Analysis completed, but no report text was generated. This is an analyzer error.";
            [self.reportView setString:text];
            [[self.reportView layoutManager] ensureLayoutForTextContainer:[self.reportView textContainer]];
            [self.reportView scrollRangeToVisible:NSMakeRange(0, 0)];
            [self.reportView setNeedsDisplay:YES];
            [self.statusLabel setStringValue:[NSString stringWithFormat:@"Analysis complete — %@", [path lastPathComponent]]];
        } catch (const std::exception& e) {
            NSString *message = [NSString stringWithUTF8String:e.what()];
            [self.reportView setString:[NSString stringWithFormat:@"Analysis failed:\n%@\n", message ?: @"Unknown C++ error"]];
            [self.statusLabel setStringValue:@"Analysis failed"];
        }
    } @catch (NSException *exception) {
        [self.reportView setString:[NSString stringWithFormat:@"Application error:\n%@\n", [exception reason]]];
        [self.statusLabel setStringValue:@"Application error"];
    }
}

- (void)application:(NSApplication *)sender openFiles:(NSArray<NSString *> *)filenames {
    (void)sender;
    if ([filenames count] > 0) {
        [self analyzeURL:[NSURL fileURLWithPath:[filenames objectAtIndex:0]]];
    }
    [NSApp replyToOpenOrPrint:NSApplicationDelegateReplySuccess];
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        for (int i = 1; i < argc; ++i) {
            const std::string arg(argv[i]);
            if (arg == "--version") {
                fprintf(stdout, "KORG RE LAB 3.0.0\n");
                return 0;
            }
            if (arg == "--self-test") {
                fprintf(stdout, "KORG RE LAB GUI bundle self-test OK\n");
                return 0;
            }
            if (arg == "--help" || arg == "-h") {
                fprintf(stdout, "KORG RE LAB is a native macOS GUI application. Use Open File in the application window.\n");
                return 0;
            }
        }

        NSApplication *app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        KorgRELabDelegate *delegate = [[KorgRELabDelegate alloc] init];
        [app setDelegate:delegate];
        [app run];
    }
    return 0;
}
