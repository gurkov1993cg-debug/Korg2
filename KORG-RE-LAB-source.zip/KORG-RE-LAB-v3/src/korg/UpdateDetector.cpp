#include "korg/UpdateDetector.h"
#include "core/Utils.h"
#include <algorithm>
#include <cctype>

namespace {
std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

std::string basenameOf(const std::string& path) {
    const std::size_t p = path.find_last_of("/\\");
    return p == std::string::npos ? path : path.substr(p + 1);
}

bool endsWith(const std::string& s, const std::string& suffix) {
    return s.size() >= suffix.size() && s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}

bool splitSuffix(const std::string& name, const std::string& ext, std::string& part) {
    const std::string marker = ext + ".";
    const std::size_t pos = name.rfind(marker);
    if (pos == std::string::npos) return false;
    const std::string tail = name.substr(pos + marker.size());
    if (tail.empty()) return false;
    for (char c : tail) if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    part = tail;
    return true;
}

std::string modelHintFromName(const std::string& filenameLower) {
    struct Hint { const char* token; const char* model; };
    static const Hint hints[] = {
        {"pa5x", "Pa5X"}, {"pa4x", "Pa4X"}, {"pa3xle", "Pa3XLe"}, {"pa3x", "Pa3X"},
        {"pa2x", "Pa2X"}, {"pa1x", "Pa1X"}, {"pa1000", "Pa1000"}, {"pa900", "Pa900"},
        {"pa800", "Pa800"}, {"pa700", "Pa700"}, {"pa600", "Pa600"}, {"pa500", "Pa500"},
        {"pa300", "Pa300"}, {"pa80", "Pa80"}, {"pa60", "Pa60"}, {"pa50", "Pa50"},
        {"havian30", "Havian 30"}, {"havian_30", "Havian 30"},
        {"kronos", "KRONOS"}, {"nautilus", "Nautilus"}, {"krome", "Krome"},
        {"kross", "Kross"}, {"oasys", "OASYS"}, {"m50", "M50"}, {"m3", "M3"}, {"triton", "Triton"}
    };
    for (const auto& h : hints) if (filenameLower.find(h.token) != std::string::npos) return h.model;
    return std::string();
}

std::string versionHintFromName(const std::string& filenameLower) {
    for (std::size_t i = 0; i + 1 < filenameLower.size(); ++i) {
        if (filenameLower[i] != 'v' || !std::isdigit(static_cast<unsigned char>(filenameLower[i+1]))) continue;
        std::size_t j = i + 1;
        while (j < filenameLower.size() && (std::isdigit(static_cast<unsigned char>(filenameLower[j])) || filenameLower[j] == '.' || filenameLower[j] == '_')) ++j;
        std::string v = filenameLower.substr(i, j - i);
        while (!v.empty() && (v.back() == '_' || v.back() == '.')) v.pop_back();
        if (v.size() > 1) return v;
    }
    return std::string();
}

void addEmbeddedIfFound(const std::vector<std::uint8_t>& d,
                        const std::vector<std::uint8_t>& sig,
                        const char* type,
                        const char* note,
                        AnalysisResult& out) {
    for (auto off : findBytes(d, sig, 128)) {
        bool duplicate = false;
        for (const auto& existing : out.embedded) {
            if (existing.offset == off && existing.type == type) { duplicate = true; break; }
        }
        if (!duplicate) out.embedded.push_back({type, off, note});
    }
}
}

void UpdateDetector::analyze(const std::string& path,
                             const std::vector<std::uint8_t>& data,
                             AnalysisResult& out) {
    const std::string filename = basenameOf(path);
    const std::string name = lower(filename);

    bool upd = endsWith(name, ".upd");
    bool pkg = endsWith(name, ".pkg");
    std::string splitPart;
    if (!upd) upd = splitSuffix(name, ".upd", splitPart);
    if (!pkg) pkg = splitSuffix(name, ".pkg", splitPart);

    if (upd || pkg) {
        out.korgUpdate.recognized = true;
        out.korgUpdate.extension = upd ? "UPD" : "PKG";
        out.korgUpdate.family = upd ? "Korg OS / firmware update" : "Korg package";
        out.korgUpdate.modelHint = modelHintFromName(name);
        out.korgUpdate.versionHint = versionHintFromName(name);
        out.korgUpdate.splitPart = splitPart;
        out.korgUpdate.evidence = "file extension / filename classification";

        if (upd) {
            out.format = out.korgPkg.recognized
                ? "Korg OS Update (UPD) with recognized PKG structure"
                : "Korg OS Update (UPD)";
            out.notes.push_back("UPD extension recognized as a Korg OS/firmware update family file. Internal structure is analyzed independently from the extension.");
        } else if (!out.korgPkg.recognized) {
            out.format = "Korg Package (PKG) - structure not yet recognized";
            out.notes.push_back("PKG extension recognized; parser did not yet validate the known Professional Arranger PKG chunk structure.");
        }

        if (!out.korgUpdate.modelHint.empty())
            out.notes.push_back("Model hint from filename: " + out.korgUpdate.modelHint + " (filename evidence only). ");
        if (!out.korgUpdate.versionHint.empty())
            out.notes.push_back("Version hint from filename: " + out.korgUpdate.versionHint + " (not yet validated against internal metadata). ");
        if (!out.korgUpdate.splitPart.empty())
            out.notes.push_back("Split package/update part detected: " + out.korgUpdate.splitPart + ".");
    }

    // Recursive-container clues useful even when the outer UPD structure is proprietary.
    addEmbeddedIfFound(data, {0x27,0x05,0x19,0x56}, "U-Boot uImage", "legacy kernel/image header candidate", out);
    addEmbeddedIfFound(data, {0x1f,0x8b,0x08}, "gzip stream", "compressed member candidate", out);
    addEmbeddedIfFound(data, {0xfd,0x37,0x7a,0x58,0x5a,0x00}, "XZ stream", "compressed member candidate", out);
    addEmbeddedIfFound(data, {'B','Z','h'}, "bzip2 stream", "compressed member candidate", out);
    addEmbeddedIfFound(data, {'P','K',0x03,0x04}, "ZIP member/container", "ZIP-compatible data candidate", out);
    addEmbeddedIfFound(data, {0x7f,'E','L','F'}, "ELF", "embedded executable/shared object candidate", out);
    addEmbeddedIfFound(data, {'0','7','0','7','0','1'}, "CPIO newc", "archive/initramfs candidate", out);
    addEmbeddedIfFound(data, {'h','s','q','s'}, "SquashFS", "filesystem image candidate", out);
    addEmbeddedIfFound(data, {'s','q','s','h'}, "SquashFS", "filesystem image candidate", out);
}
