#include "korg/KorgKnowledgeBase.h"
#include <algorithm>
#include <cctype>

namespace {
std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s;
}

bool containsI(const std::string& haystack, const std::string& needle) {
    return lower(haystack).find(lower(needle)) != std::string::npos;
}

bool metaHas(const KorgUpdContainerInfo& info, const std::string& needle) {
    for (const auto& s : info.metaStrings) if (containsI(s, needle)) return true;
    return false;
}

const KorgUpdEntry* findPath(const KorgUpdContainerInfo& info, const std::string& needle) {
    for (const auto& e : info.entries) {
        if (!e.path.empty() && containsI(e.path, needle)) return &e;
    }
    return nullptr;
}

void addFact(AnalysisResult& out,
             const std::string& category,
             const std::string& name,
             const std::string& value,
             const std::string& confidence,
             const std::string& evidence) {
    KorgPlatformFact f;
    f.category = category;
    f.name = name;
    f.value = value;
    f.confidence = confidence;
    f.evidence = evidence;
    out.korgPlatformFacts.push_back(f);
}

void addObservedPathFact(AnalysisResult& out,
                         const KorgUpdContainerInfo& info,
                         const std::string& needle,
                         const std::string& category,
                         const std::string& name,
                         const std::string& value) {
    const KorgUpdEntry* e = findPath(info, needle);
    if (!e) return;
    addFact(out, category, name, value, "DETECTED",
            std::string("UPD file table contains ") + e->path);
}
}

void KorgKnowledgeBase::enrichUpd(AnalysisResult& out) {
    const auto& info = out.korgUpdContainer;
    if (!info.recognized) return;

    // Direct observations from the package file table.
    addObservedPathFact(out, info, "/user-release.tar", "Container", "Root filesystem payload",
                        "Raw user-release.tar member is present");
    addObservedPathFact(out, info, "/omega_sys/OPOS", "Application", "OPOS",
                        "Main Korg application member is present");
    addObservedPathFact(out, info, "tgondsp.out", "DSP", "Tone-generator DSP image",
                        "tgondsp.out member is present");
    addObservedPathFact(out, info, "audio-app", "Application", "audio-app",
                        "Host audio application member is present");
    addObservedPathFact(out, info, "HwCtrlServer", "Application", "HwCtrlServer",
                        "Hardware-control server member is present");
    addObservedPathFact(out, info, "PCMLoader", "PCM", "PCMLoader",
                        "PCM loader member is present");
    addObservedPathFact(out, info, "SOUNDS.xml", "Resources", "Sound resource browser",
                        "SOUNDS.xml member is present");
    addObservedPathFact(out, info, "PCMIMAGE/Banks.cfg", "PCM", "PCM bank configuration",
                        "Banks.cfg member is present");
    addObservedPathFact(out, info, "midi_def.sh", "MIDI", "MIDI routing definition",
                        "midi_def.sh member is present");

    // The following profile is tied narrowly to the reference package supplied by
    // the user and only activates when its metadata fingerprint is present.
    const bool pa600Profile = metaHas(info, "103ASTD") &&
                              metaHas(info, "KORG-SW6") &&
                              metaHas(info, "workhorse6") &&
                              metaHas(info, "Z103A");
    if (!pa600Profile) return;

    out.korgReferenceProfile = "Pa600 / Z103A reference profile";

    const std::string ref = "validated reference: Pa600_Operating_System_v211.upd supplied research";
    addFact(out, "Identity", "Machine / package", "Pa600 family, machine ID Z103A; KORG-SW6 / workhorse6", "REFERENCE-VERIFIED", ref);
    addFact(out, "Operating system", "OS family", "LFO (Linux For Omega), Korg Italy s.p.a.", "REFERENCE-VERIFIED", ref);
    addFact(out, "Operating system", "Kernel", "Linux 4.9.45-rt23-arvon-release with PREEMPT_RT", "REFERENCE-VERIFIED", ref);
    addFact(out, "Hardware", "Board codename", "ARVON", "REFERENCE-VERIFIED", ref);
    addFact(out, "Hardware", "Host CPU ABI", "ARM 32-bit armhf", "REFERENCE-VERIFIED", ref);
    addFact(out, "Root filesystem", "Userspace", "Buildroot / BusyBox, glibc 2.24 armhf", "REFERENCE-VERIFIED", ref);
    addFact(out, "GUI", "Framework", "Qt 4.6.2", "REFERENCE-VERIFIED", ref);
    addFact(out, "Audio", "Linux audio stack", "ALSA", "REFERENCE-VERIFIED", ref);
    addFact(out, "DSP", "Tone-generator processor", "TI TMS320C6000; tgondsp.out ELF e_machine=0x8C", "REFERENCE-VERIFIED", ref);
    addFact(out, "Applications", "ARM host programs", "audio-app, HwCtrlServer and PCMLoader are ARM 32-bit ELF", "REFERENCE-VERIFIED", ref);
    addFact(out, "Application", "OPOS", "~10.2 MB main application; high-entropy/encrypted in the validated reference", "REFERENCE-VERIFIED", ref);
    addFact(out, "Security", "High-entropy payload", "Tag 0x0003 is encrypted/high-entropy in the validated reference", "REFERENCE-VERIFIED", ref);
    addFact(out, "Resources", "Sound catalogue", "SOUNDS.xml: 1100 sounds in 52 folders", "REFERENCE-VERIFIED", ref);
    addFact(out, "Resources", "packedPC mapping", "0x00790A00 => [reserved][MSB=121][PC=10][LSB=0]; observed MSB 120/121/127", "REFERENCE-VERIFIED", ref);
    addFact(out, "PCM", "DSP PCM window", "StartAddr=0x89000000, Size=0x16000000 (352 MB)", "REFERENCE-VERIFIED", ref);
    addFact(out, "PCM", "PCM bank", "/emmc/omega_sys/PCMIMAGE/BANK00.BIN", "REFERENCE-VERIFIED", ref);
    addFact(out, "MIDI", "Virtual ports", "16 virtual MIDI ports; DIN5, USB and BTLE routing", "REFERENCE-VERIFIED", ref);
    addFact(out, "Package scope", "Minimal package", "Operating-system package only; no styles in this reference package", "REFERENCE-VERIFIED", ref);
    addFact(out, "Package scope", "Factory data location", "Styles/factory data live under eMMC /omega_sys and arrive through separate factory-data content", "REFERENCE-VERIFIED", ref);

    out.notes.push_back("Pa600/Z103A reference profile matched by metadata fingerprint; REFERENCE-VERIFIED facts are kept separate from directly DETECTED file evidence.");
}
