#pragma once
#include <vector>

struct KorgMachineSignature {
    const char* family;
    const char* model;
    const char* machineId;
    const char* evidenceStatus;
};

class ModelDatabase {
public:
    static const std::vector<KorgMachineSignature>& machineSignatures();
};
