#include "korg/pkg/PkgParser.h"
#include "core/Utils.h"
#include <algorithm>
#include <iomanip>
#include <sstream>

namespace {

std::string hexBytes(const std::vector<std::uint8_t>& d, std::size_t off, std::size_t n) {
    if (off + n > d.size()) return std::string();
    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    for (std::size_t i = 0; i < n; ++i) ss << std::setw(2) << static_cast<unsigned>(d[off+i]);
    return ss.str();
}

bool readCString(const std::vector<std::uint8_t>& d, std::size_t& p, std::size_t end, std::string& out) {
    if (p >= end || end > d.size()) return false;
    const std::size_t start = p;
    while (p < end && d[p] != 0) {
        const std::uint8_t c = d[p];
        // Korg header/path strings observed in this package family are ordinary 8-bit text.
        // Reject obvious binary runs so random data is not misclassified as a header string.
        if (c < 0x09 || (c > 0x0d && c < 0x20)) return false;
        ++p;
    }
    if (p >= end) return false;
    out.assign(reinterpret_cast<const char*>(&d[start]), p - start);
    ++p; // NUL
    return true;
}

std::size_t align4(std::size_t v) { return (v + 3u) & ~std::size_t(3u); }

const char* chunkType(std::uint32_t id) {
    if (id == 1) return "header";
    if (id >= 2 && id <= 14) return "system-file";
    if (id == 15) return "installer-script";
    if (id == 16) return "directory";
    if (id == 17) return "link";
    if (id == 18) return "file";
    if (id == 19) return "rootfs";
    return "unknown";
}

const char* systemPath(std::uint32_t id) {
    switch (id) {
        case 2:  return "/update/uImage";
        case 3:  return "/update/ramdisk.gz";
        case 4:  return "/update/lfo-pkg-install";
        case 5:  return "/update/lfo-pkg-install.xml";
        case 6:  return "/service/uImage";
        case 7:  return "/service/ramdisk.gz";
        case 8:  return "/service/lfo-service";
        case 9:  return "/service/lfo-service.xml";
        case 10: return "/service/lfo-pkg-launcher";
        case 11: return "/service/lfo-pkg-launcher.xml";
        case 12: return "/boot/MLO";
        case 13: return "/boot/u-boot.bin";
        case 14: return "/kernel/uImage";
        default: return "";
    }
}

std::string versionString(const std::vector<std::uint8_t>& d, std::size_t off) {
    if (off + 4 > d.size()) return std::string();
    std::ostringstream ss;
    ss << static_cast<unsigned>(d[off]) << "."
       << static_cast<unsigned>(d[off+1]) << "."
       << static_cast<unsigned>(d[off+2]) << "."
       << static_cast<unsigned>(d[off+3]);
    return ss.str();
}

bool parseHeader(const std::vector<std::uint8_t>& d, std::size_t payload, std::size_t end, KorgPkgInfo& pkg) {
    if (payload + 12 > end) return false;
    pkg.pkgLibVersion = versionString(d, payload);
    pkg.packageType = rd32le(d, payload + 4);
    pkg.unknown1 = rd16le(d, payload + 8);
    pkg.unknown2 = rd16le(d, payload + 10);
    std::size_t p = payload + 12;
    return readCString(d,p,end,pkg.systemType) &&
           readCString(d,p,end,pkg.buildSystem1) &&
           readCString(d,p,end,pkg.buildSystem2) &&
           readCString(d,p,end,pkg.creationDate) &&
           readCString(d,p,end,pkg.creationTime) &&
           readCString(d,p,end,pkg.packageType1) &&
           readCString(d,p,end,pkg.packageType2);
}

void parseChunkMetadata(const std::vector<std::uint8_t>& d, std::size_t payload, std::size_t end, KorgPkgChunk& c) {
    std::size_t p = payload;
    if (c.id >= 2 && c.id <= 14) {
        c.path = systemPath(c.id);
        if (p + 16 <= end) {
            c.md5 = hexBytes(d,p,16);
            c.dataOffset = p + 16;
            c.dataSize = static_cast<std::uint32_t>(end - c.dataOffset);
        }
        return;
    }
    if (c.id == 15) {
        if (p + 18 > end) return;
        c.md5 = hexBytes(d,p,16); p += 16;
        c.condition = rd16le(d,p); p += 2;
        if (!readCString(d,p,end,c.path)) return;
        c.dataOffset = p;
        c.dataSize = static_cast<std::uint32_t>(end - p);
        return;
    }
    if (c.id == 16) {
        if (p + 8 > end) return;
        c.owner = rd16le(d,p); p += 2;
        c.group = rd16le(d,p); p += 2;
        c.attributes = rd16le(d,p); p += 2;
        c.condition = rd16le(d,p); p += 2;
        readCString(d,p,end,c.path);
        return;
    }
    if (c.id == 18) {
        if (p + 29 > end) return;
        c.md5 = hexBytes(d,p,16); p += 16;
        c.owner = rd16le(d,p); p += 2;
        c.group = rd16le(d,p); p += 2;
        c.attributes = rd16le(d,p); p += 2;
        c.condition = rd16le(d,p); p += 2;
        c.dataSize = rd32le(d,p); p += 4;
        c.compression = d[p++];
        if (!readCString(d,p,end,c.path)) return;
        if (!readCString(d,p,end,c.date)) return;
        if (!readCString(d,p,end,c.time)) return;
        c.dataOffset = p;
        return;
    }
    if (c.id == 19) {
        if (p + 22 > end) return;
        c.md5 = hexBytes(d,p,16); p += 16;
        c.dataSize = rd32le(d,p); p += 4;
        c.condition = rd16le(d,p); p += 2;
        if (!readCString(d,p,end,c.path)) return;
        c.dataOffset = p;
    }
}

} // namespace

bool PkgParser::analyze(const std::vector<std::uint8_t>& d, AnalysisResult& out) {
    // Known family begins with a 16-byte MD5 of all bytes following the hash.
    // The first aligned chunk is the header (id 1), with little-endian id/size.
    if (d.size() < 32) return false;
    const std::size_t first = 16;
    if (rd32le(d, first) != 1) return false;
    const std::uint32_t firstSize = rd32le(d, first + 4);
    if (firstSize < 20 || first + 8ull + firstSize > d.size()) return false;

    KorgPkgInfo pkg;
    pkg.recognized = true;
    pkg.packageMd5 = hexBytes(d,0,16);

    const std::size_t firstPayload = first + 8;
    const std::size_t firstEnd = firstPayload + firstSize;
    if (!parseHeader(d,firstPayload,firstEnd,pkg)) return false;

    // A plausible package type is strong supporting evidence but unknown future values
    // are preserved rather than rejected.
    if (pkg.systemType.empty()) return false;

    std::size_t off = first;
    std::size_t guard = 0;
    while (off + 8 <= d.size() && guard++ < 100000) {
        const std::uint32_t id = rd32le(d,off);
        const std::uint32_t size = rd32le(d,off+4);
        const std::size_t payload = off + 8;
        if (size > d.size() - payload) {
            pkg.warnings.push_back("Chunk at " + hexOffset(off) + " exceeds package boundary; parsing stopped.");
            break;
        }
        const std::size_t end = payload + size;
        KorgPkgChunk c;
        c.id = id;
        c.size = size;
        c.offset = off;
        c.payloadOffset = payload;
        c.type = chunkType(id);
        parseChunkMetadata(d,payload,end,c);
        pkg.chunks.push_back(c);

        const std::size_t next = align4(end);
        if (next <= off || next > d.size()) break;
        off = next;
        if (off == d.size()) break;
    }

    if (pkg.chunks.empty() || pkg.chunks.front().id != 1) return false;
    pkg.parsedBytes = off > d.size() ? d.size() : off;
    if (pkg.parsedBytes < d.size()) {
        pkg.warnings.push_back("Trailing or unparsed bytes remain after the recognized chunk sequence.");
    }

    out.korgPkg = pkg;
    out.format = "Korg Professional Arranger PKG";
    out.endian = "Little (PKG metadata)";
    out.notes.push_back("Read-only PKG chunk parser recognized a structurally valid Korg package header.");
    out.notes.push_back("Package-level MD5 is recorded but not yet cryptographically verified in V3.");
    return true;
}
