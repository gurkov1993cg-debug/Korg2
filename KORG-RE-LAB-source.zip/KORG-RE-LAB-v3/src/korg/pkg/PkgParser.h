#pragma once
#include "core/Model.h"
#include <cstdint>
#include <vector>

class PkgParser {
public:
    // Read-only parser for the known Korg Professional Arranger PKG family.
    // Returns true only when the top-level chunk structure is internally plausible.
    static bool analyze(const std::vector<std::uint8_t>& data, AnalysisResult& out);
};
