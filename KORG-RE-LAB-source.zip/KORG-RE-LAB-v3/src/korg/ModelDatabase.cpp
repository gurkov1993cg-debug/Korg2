#include "korg/ModelDatabase.h"

const std::vector<KorgMachineSignature>& ModelDatabase::machineSignatures() {
    // Only signatures with public reverse-engineering evidence belong here.
    // The overall project covers the whole Korg range, but unknown IDs must stay unknown.
    static const std::vector<KorgMachineSignature> k = {
        {"Professional Arranger", "Pa600",     "Z103A", "public-research"},
        {"Professional Arranger", "Pa900",     "Z104A", "public-research"},
        {"Professional Arranger", "Pa300",     "Z106A", "public-research"},
        {"Professional Arranger", "Pa3XLe",    "Z107A", "public-research"},
        {"Professional Arranger", "Havian 30", "Z108A", "public-research"},
        {"Professional Arranger", "Pa4X",      "Z110A", "public-research"}
    };
    return k;
}
