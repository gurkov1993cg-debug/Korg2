#pragma once
#include "core/Model.h"
#include <cstdint>
#include <vector>

class UpdParser {
public:
    // Read-only parser for the TLV-based Korg Professional Arranger UPD family
    // validated from Pa600_Operating_System_v211.upd research supplied by the user.
    // The parser does not modify or flash firmware.
    static bool analyze(const std::vector<std::uint8_t>& data, AnalysisResult& out);
};
