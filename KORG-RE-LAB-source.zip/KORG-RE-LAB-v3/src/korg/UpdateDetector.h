#pragma once
#include "core/Model.h"
#include <cstdint>
#include <string>
#include <vector>

class UpdateDetector {
public:
    static void analyze(const std::string& path,
                        const std::vector<std::uint8_t>& data,
                        AnalysisResult& out);
};
