#include "korg/KorgDetector.h"
#include "korg/ModelDatabase.h"
#include "core/Utils.h"

void KorgDetector::analyze(const std::vector<std::uint8_t>& d, AnalysisResult& out) {
    for (const auto& m : ModelDatabase::machineSignatures()) {
        if (containsAscii(d,m.machineId)) {
            out.korgModels.push_back({m.family,m.model,m.machineId,"Detected",
                std::string("machine-id signature ") + m.machineId + " (" + m.evidenceStatus + ")"});
        }
    }

    const char* paths[] = {
        "/update/uImage", "/update/ramdisk.gz", "/update/lfo-pkg-install",
        "/service/uImage", "/service/ramdisk.gz", "/service/lfo-service",
        "/boot/MLO", "/boot/u-boot.bin", "/kernel/uImage"
    };
    int korgPkgClues = 0;
    for (const char* p : paths) if (containsAscii(d,p)) ++korgPkgClues;
    if (korgPkgClues >= 2) {
        out.notes.push_back("Strong Korg Professional Arranger PKG structure fingerprint detected (multiple known system paths).");
    } else if (korgPkgClues == 1) {
        out.notes.push_back("Possible Korg Professional Arranger PKG clue detected; more evidence required.");
    }

    for (auto off : findBytes(d,{0x7f,'E','L','F'},128)) out.embedded.push_back({"ELF",off,"embedded executable/shared object candidate"});
    for (auto off : findBytes(d,{0x27,0x05,0x19,0x56},128)) out.embedded.push_back({"U-Boot uImage",off,"legacy uImage header magic"});
    for (auto off : findBytes(d,{0x1f,0x8b,0x08},128)) out.embedded.push_back({"gzip stream",off,"compressed member candidate"});
    for (auto off : findBytes(d,{'h','s','q','s'},128)) out.embedded.push_back({"SquashFS",off,"filesystem candidate"});
    for (auto off : findBytes(d,{'s','q','s','h'},128)) out.embedded.push_back({"SquashFS",off,"filesystem candidate"});
    for (auto off : findBytes(d,{'0','7','0','7','0','1'},128)) out.embedded.push_back({"CPIO newc",off,"initramfs/archive candidate"});

    if (containsAscii(d,"KORG")) out.notes.push_back("Literal KORG marker present; this is supporting evidence only, not model identification.");
}
