#include "korg/UpdParser.h"
#include "core/Utils.h"
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <map>
#include <sstream>

namespace {

std::size_t align4(std::size_t v) { return (v + 3u) & ~std::size_t(3u); }

std::string hexBytes(const std::vector<std::uint8_t>& d, std::size_t off, std::size_t n) {
    if (off + n > d.size()) return std::string();
    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    for (std::size_t i = 0; i < n; ++i)
        ss << std::setw(2) << static_cast<unsigned>(d[off+i]);
    return ss.str();
}

bool readCString(const std::vector<std::uint8_t>& d,
                 std::size_t& p,
                 std::size_t end,
                 std::string& out) {
    if (p >= end || end > d.size()) return false;
    const std::size_t start = p;
    while (p < end && d[p] != 0) {
        const std::uint8_t c = d[p];
        if (c < 0x09 || (c > 0x0D && c < 0x20)) return false;
        ++p;
    }
    if (p >= end) return false;
    out.assign(reinterpret_cast<const char*>(&d[start]), p - start);
    ++p;
    return true;
}

const char* tagType(std::uint32_t tag) {
    switch (tag) {
        case 0x0001: return "package-metadata";
        case 0x0002: return "arm-image";
        case 0x0003: return "payload-encrypted-or-high-entropy";
        case 0x0004: return "payload";
        case 0x0005: return "small-record";
        case 0x000e: return "arm-image-copy";
        case 0x000f: return "aux-record";
        case 0x0010: return "directory";
        case 0x0011: return "file-zlib";
        case 0x0013: return "file-raw";
        case 0x0015: return "aux-block";
        default:
            if (tag >= 0x0600 && tag < 0x0700) return "signature";
            return "unknown";
    }
}

bool looksLikeZlibHeader(const std::vector<std::uint8_t>& d, std::size_t p, std::size_t end) {
    if (p + 2 > end || p + 2 > d.size()) return false;
    const std::uint8_t cmf = d[p];
    const std::uint8_t flg = d[p+1];
    if ((cmf & 0x0F) != 8) return false; // DEFLATE
    const unsigned word = (static_cast<unsigned>(cmf) << 8) | flg;
    return (word % 31u) == 0u;
}

std::size_t findZlib(const std::vector<std::uint8_t>& d,
                     std::size_t start,
                     std::size_t end,
                     std::size_t limit = 512) {
    if (start >= end) return std::string::npos;
    const std::size_t stop = std::min(end, start + limit);
    for (std::size_t p = start; p + 2 <= stop; ++p)
        if (looksLikeZlibHeader(d,p,end)) return p;
    return std::string::npos;
}

bool parseFileEntry(const std::vector<std::uint8_t>& d,
                    std::size_t payload,
                    std::size_t end,
                    KorgUpdEntry& e) {
    if (payload + 0x1d > end) return false;
    e.md5 = hexBytes(d,payload,16);
    e.attributes = rd16le(d,payload + 0x14);
    e.unpackedSize = rd32le(d,payload + 0x18);
    e.flag = d[payload + 0x1c];

    std::size_t p = payload + 0x1d;
    if (!readCString(d,p,end,e.path)) return false;
    if (p < end && !readCString(d,p,end,e.date)) return false;
    if (p < end && !readCString(d,p,end,e.time)) return false;

    // Research-supplied layout after the variable cstrings:
    //   u32 constant, u32 compressed-size LE, u32 unpacked-size BE, data
    if (p + 12 <= end) {
        e.compressedSize = rd32le(d,p + 4);
        e.unpackedSizeBE = rd32be(d,p + 8);
        e.dataOffset = p + 12;
    } else {
        e.dataOffset = p;
    }

    if (e.tag == 0x0011) {
        std::size_t z = std::string::npos;
        if (e.dataOffset < end && looksLikeZlibHeader(d,static_cast<std::size_t>(e.dataOffset),end))
            z = static_cast<std::size_t>(e.dataOffset);
        if (z == std::string::npos)
            z = findZlib(d,p,end);
        if (z != std::string::npos) {
            e.dataOffset = z;
            e.zlibStream = true;
        }
    }
    return true;
}

bool parseMetadata(const std::vector<std::uint8_t>& d,
                   std::size_t payload,
                   std::size_t end,
                   KorgUpdContainerInfo& info) {
    if (payload + 12 > end) return false;
    info.metaNumbers.push_back(rd16le(d,payload + 0));
    info.metaNumbers.push_back(rd16le(d,payload + 2));
    info.metaNumbers.push_back(rd16le(d,payload + 4));
    info.metaNumbers.push_back(rd16le(d,payload + 6));
    info.metaNumbers.push_back(rd32le(d,payload + 8));

    std::size_t p = payload + 12;
    while (p < end) {
        if (d[p] == 0) { ++p; continue; }
        std::string s;
        if (!readCString(d,p,end,s)) return false;
        if (!s.empty()) info.metaStrings.push_back(s);
    }
    return true;
}

bool looksLikeEcdsaDer(const std::vector<std::uint8_t>& d,
                       std::size_t payload,
                       std::size_t end) {
    // Observed signature record payload: 01 00 + DER SEQUENCE (30 45/46 ...)
    if (payload + 4 > end) return false;
    if (d[payload] != 0x01 || d[payload+1] != 0x00 || d[payload+2] != 0x30) return false;
    const std::uint8_t seqLen = d[payload+3];
    return payload + 4u + seqLen <= end;
}

} // namespace

bool UpdParser::analyze(const std::vector<std::uint8_t>& d, AnalysisResult& out) {
    if (d.size() < 32) return false;
    if (rd32le(d,0x10) != 0x0001) return false;

    KorgUpdContainerInfo info;
    info.packageHeader16 = hexBytes(d,0,16);

    std::size_t off = 0x10;
    std::size_t guard = 0;
    bool sawMeta = false;

    while (off < d.size()) {
        if (off + 8 > d.size()) {
            info.warnings.push_back("Trailing bytes smaller than a TLV header at " + hexOffset(off) + ".");
            break;
        }
        if (++guard > 200000) {
            info.warnings.push_back("TLV guard limit reached.");
            break;
        }

        const std::uint32_t tag = rd32le(d,off);
        const std::uint32_t len = rd32le(d,off+4);
        const std::size_t payload = off + 8;
        if (len > d.size() - payload) {
            info.warnings.push_back("TLV at " + hexOffset(off) + " exceeds file boundary.");
            break;
        }
        const std::size_t end = payload + len;

        KorgUpdEntry e;
        e.tag = tag;
        e.length = len;
        e.offset = off;
        e.payloadOffset = payload;
        e.type = tagType(tag);

        if (tag == 0x0001) {
            sawMeta = parseMetadata(d,payload,end,info);
            if (!sawMeta) info.warnings.push_back("Metadata tag exists but its string table was not fully decoded.");
        } else if (tag == 0x0010 || tag == 0x0011 || tag == 0x0013) {
            if (!parseFileEntry(d,payload,end,e))
                info.warnings.push_back("Could not fully decode file-entry header at " + hexOffset(off) + ".");
            if (tag == 0x0010) ++info.dirCount;
            if (tag == 0x0011) ++info.fileCount;
            if (tag == 0x0013) ++info.rawFileCount;
        } else if (tag >= 0x0600 && tag < 0x0700) {
            e.ecdsaDer = looksLikeEcdsaDer(d,payload,end);
            ++info.signatureCount;
        } else if ((tag == 0x0002 || tag == 0x000e) && len >= 16) {
            e.md5 = hexBytes(d,payload,16);
            e.dataOffset = payload + 16;
        }

        info.entries.push_back(e);

        const std::size_t next = align4(end);
        if (next <= off || next > d.size()) {
            if (end == d.size()) off = d.size();
            else info.warnings.push_back("Invalid TLV alignment after " + hexOffset(off) + ".");
            break;
        }
        off = next;
    }

    info.parsedBytes = std::min<std::size_t>(off,d.size());
    info.exactEof = sawMeta && off == d.size();

    if (!info.metaStrings.empty()) {
        if (info.metaStrings.size() > 0) info.systemType = info.metaStrings[0];
        if (info.metaStrings.size() > 1) info.softwareFamily = info.metaStrings[1];
        if (info.metaStrings.size() > 2) info.platformCode = info.metaStrings[2];
        if (info.metaStrings.size() > 3) info.packageDate = info.metaStrings[3];
        if (info.metaStrings.size() > 4) info.packageTime = info.metaStrings[4];
        if (info.metaStrings.size() > 5) info.packageLabel = info.metaStrings[5];
        if (info.metaStrings.size() > 6) info.packageName = info.metaStrings[6];
    }

    std::map<std::uint32_t, KorgUpdTagStat> stats;
    for (const auto& e : info.entries) {
        auto& st = stats[e.tag];
        st.tag = e.tag;
        st.type = e.type;
        ++st.count;
        st.totalPayloadBytes += e.length;
    }
    for (const auto& kv : stats) info.tagStats.push_back(kv.second);

    // Require a decoded metadata tag and a meaningful multi-record chain.
    if (!sawMeta || info.entries.size() < 2) return false;

    info.recognized = true;
    out.korgUpdContainer = info;
    out.format = "Korg UPD/PKG TLV container";
    out.endian = "Little (TLV metadata)";
    out.notes.push_back("Validated TLV chain starts at 0x10 with little-endian tag/length and 4-byte alignment.");
    if (info.exactEof)
        out.notes.push_back("TLV chain reaches EOF exactly: strong structural evidence for this Korg update-container family.");
    else
        out.notes.push_back("TLV container recognized, but parsing did not end exactly at EOF; inspect warnings.");
    if (info.signatureCount)
        out.notes.push_back("0x06xx signature records were found; DER-shaped ECDSA candidates are reported but not cryptographically verified.");
    return true;
}
