#pragma once
#include "core/Model.h"

class KorgKnowledgeBase {
public:
    // Enriches a structurally decoded Korg update with model/platform knowledge.
    // Reference facts are explicitly labelled as such and are never reported as
    // directly detected from the current file unless corresponding evidence exists.
    static void enrichUpd(AnalysisResult& out);
};
