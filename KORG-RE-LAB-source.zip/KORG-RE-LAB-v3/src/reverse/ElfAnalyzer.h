#pragma once
#include "core/Model.h"
#include <cstdint>
#include <string>
#include <vector>

class ElfAnalyzer {
public:
    static bool analyze(const std::vector<std::uint8_t>& data,
                        const std::string& logicalPath,
                        std::uint64_t sourceOffset,
                        bool fromCompressedEntry,
                        ExecutableInfo& out);
};
