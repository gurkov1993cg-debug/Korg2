#include "reverse/FirmwareExecutableScanner.h"
#include "core/Utils.h"
#include "detect/FormatDetector.h"
#include "detect/LanguageDetector.h"
#include "reverse/ElfAnalyzer.h"
#include "reverse/DeviceTreeAnalyzer.h"
#include <algorithm>
#include <cmath>
#include <cctype>
#include <string>
#include <vector>
#include <zlib.h>

namespace {
std::string lower(std::string s){for(char&c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return s;}
std::string baseName(const std::string&p){const std::size_t n=p.find_last_of('/');return n==std::string::npos?p:p.substr(n+1);}
bool executableLookingPath(const std::string&p){
    if(p.empty())return false;const std::string b=lower(baseName(p)); if(b.empty())return false;
    if(b=="opos"||b=="audio-app"||b=="hwctrlserver"||b=="pcmloader"||b=="tgondsp.out")return true;
    if(b.size()>4&&(b.substr(b.size()-4)==".out"||b.substr(b.size()-3)==".so"||b.substr(b.size()-4)==".elf"||b.substr(b.size()-4)==".bin"))return true;
    if(b.find('.')==std::string::npos && (p.find("/bin/")!=std::string::npos||p.find("/sbin/")!=std::string::npos||p.find("omega_sys/")!=std::string::npos))return true;
    return false;
}
double entropy(const std::vector<std::uint8_t>& d){if(d.empty())return 0.0;double f[256]={0};for(auto b:d)f[b]+=1.0;double h=0;for(double n:f)if(n){double p=n/d.size();h-=p*std::log(p)/std::log(2.0);}return h;}
bool inflateEntry(const std::vector<std::uint8_t>& src,const KorgUpdEntry&e,std::vector<std::uint8_t>& dst,std::string& err){
    if(!e.zlibStream||e.dataOffset>=src.size()||!e.unpackedSize)return false;
    const std::uint64_t tlvEnd=e.payloadOffset+e.length;if(tlvEnd>src.size()||e.dataOffset>=tlvEnd)return false;
    if(e.unpackedSize>64u*1024u*1024u){err="unpacked file exceeds 64 MiB analysis safety cap";return false;}
    dst.assign(e.unpackedSize,0);z_stream z{};z.next_in=const_cast<Bytef*>(reinterpret_cast<const Bytef*>(&src[static_cast<std::size_t>(e.dataOffset)]));z.avail_in=static_cast<uInt>(std::min<std::uint64_t>(tlvEnd-e.dataOffset,0xFFFFFFFFu));z.next_out=reinterpret_cast<Bytef*>(dst.data());z.avail_out=static_cast<uInt>(dst.size());
    int rc=inflateInit(&z);if(rc!=Z_OK){err="inflateInit failed";dst.clear();return false;}rc=inflate(&z,Z_FINISH);inflateEnd(&z);if(rc!=Z_STREAM_END){err="zlib inflate did not reach stream end (rc="+std::to_string(rc)+")";dst.clear();return false;}dst.resize(z.total_out);return true;
}
void analyzeSimple(const std::vector<std::uint8_t>& d,const std::string&path,std::uint64_t off,bool compressed,AnalysisResult&root){
    AnalysisResult t;FormatDetector::analyze(d,t);LanguageDetector::analyze(d,t);if(t.format=="Unknown / raw")return;ExecutableInfo x;x.path=path;x.format=t.format;x.architecture=t.architecture;x.endian=t.endian;x.bits=t.bits;x.languages=t.languages;x.toolchains=t.toolchains;x.platforms=t.platforms;x.sourceOffset=off;x.fromCompressedEntry=compressed;x.unpackedSize=d.size();root.executables.push_back(x);
}
void analyzeOne(const std::vector<std::uint8_t>& d,const std::string&path,std::uint64_t off,bool compressed,bool pathLooksExec,AnalysisResult&root){
    ExecutableInfo x;if(ElfAnalyzer::analyze(d,path,off,compressed,x)){root.executables.push_back(x);return;}
    AnalysisResult t;FormatDetector::analyze(d,t);if(t.format!="Unknown / raw"){analyzeSimple(d,path,off,compressed,root);return;}
    if(pathLooksExec){x.path=path;x.format="Unknown binary";x.architecture="Unknown";x.sourceOffset=off;x.fromCompressedEntry=compressed;x.unpackedSize=d.size();const double h=entropy(d);if(h>7.65){x.format="High-entropy / encrypted binary candidate";x.warnings.push_back("Programming language cannot be inferred from encrypted/high-entropy bytes without decrypted executable code.");}else{x.warnings.push_back("Executable-looking firmware path, but no supported executable header was found.");}root.executables.push_back(x);}
}
}

void FirmwareExecutableScanner::analyze(const std::vector<std::uint8_t>& data,AnalysisResult& out){
    DeviceTreeAnalyzer::analyze(data,out.path,0,false,out);
    if(out.format=="ELF"){ExecutableInfo x;if(ElfAnalyzer::analyze(data,out.path,0,false,x))out.executables.push_back(x);return;}
    if(!out.korgUpdContainer.recognized)return;
    std::uint64_t totalInflated=0;std::size_t attempted=0,decoded=0;
    for(const auto&e:out.korgUpdContainer.entries){
        if(e.tag!=0x0011&&e.tag!=0x0013)continue;const bool likely=executableLookingPath(e.path);
        if(e.tag==0x0011){if(!e.zlibStream||!e.unpackedSize)continue;if(totalInflated+e.unpackedSize>256u*1024u*1024u){if(likely)out.notes.push_back("Executable scan safety cap reached before "+e.path+".");continue;}std::vector<std::uint8_t> unpacked;std::string err;++attempted;if(!inflateEntry(data,e,unpacked,err)){if(likely)out.notes.push_back("Could not decompress executable-looking entry "+e.path+": "+err);continue;}totalInflated+=unpacked.size();DeviceTreeAnalyzer::analyze(unpacked,e.path,e.dataOffset,true,out);const std::size_t before=out.executables.size();analyzeOne(unpacked,e.path,e.dataOffset,true,likely,out);if(out.executables.size()>before)++decoded;
        }else{const std::uint64_t tlvEnd=e.payloadOffset+e.length;if(e.dataOffset>=data.size()||tlvEnd>data.size()||e.dataOffset>=tlvEnd)continue;const std::uint64_t n=tlvEnd-e.dataOffset;if(n>64u*1024u*1024u&&!likely)continue;std::vector<std::uint8_t> raw(data.begin()+static_cast<std::ptrdiff_t>(e.dataOffset),data.begin()+static_cast<std::ptrdiff_t>(tlvEnd));DeviceTreeAnalyzer::analyze(raw,e.path,e.dataOffset,false,out);const std::size_t before=out.executables.size();analyzeOne(raw,e.path,e.dataOffset,false,likely,out);if(out.executables.size()>before)++decoded;}
    }
    out.notes.push_back("Recursive executable scan: inspected "+std::to_string(attempted)+" zlib firmware files, inflated "+std::to_string(totalInflated)+" bytes, reported "+std::to_string(decoded)+" executable/code candidates.");
}
