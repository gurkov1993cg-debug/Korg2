#pragma once
#include "core/Model.h"
#include <cstdint>
#include <string>
#include <vector>

class DeviceTreeAnalyzer {
public:
    static bool analyze(const std::vector<std::uint8_t>& data,
                        const std::string& path,
                        std::uint64_t sourceOffset,
                        bool fromCompressedEntry,
                        AnalysisResult& out);
};
