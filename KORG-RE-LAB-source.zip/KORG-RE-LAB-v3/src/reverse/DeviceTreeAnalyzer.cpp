#include "reverse/DeviceTreeAnalyzer.h"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <map>
#include <set>
#include <sstream>

namespace {
constexpr std::uint32_t FDT_MAGIC = 0xd00dfeedu;
constexpr std::uint32_t FDT_BEGIN_NODE = 1u;
constexpr std::uint32_t FDT_END_NODE = 2u;
constexpr std::uint32_t FDT_PROP = 3u;
constexpr std::uint32_t FDT_NOP = 4u;
constexpr std::uint32_t FDT_END = 9u;

std::uint32_t be32(const std::vector<std::uint8_t>& d, std::size_t o) {
    if (o + 4 > d.size()) return 0;
    return (static_cast<std::uint32_t>(d[o]) << 24) |
           (static_cast<std::uint32_t>(d[o+1]) << 16) |
           (static_cast<std::uint32_t>(d[o+2]) << 8) |
           static_cast<std::uint32_t>(d[o+3]);
}
std::uint64_t be64cells(const std::vector<std::uint8_t>& v, std::size_t o, unsigned cells) {
    if (cells == 0) return 0;
    std::uint64_t r = 0;
    for (unsigned i=0;i<cells && i<2;++i) r = (r << 32) | be32(v,o+i*4);
    return r;
}
std::size_t align4(std::size_t x) { return (x + 3u) & ~std::size_t(3u); }
std::string lower(std::string s){ for(char& c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c))); return s; }
std::string joinCompat(const std::vector<std::uint8_t>& v) {
    std::ostringstream ss; bool first=true; std::size_t p=0;
    while (p < v.size()) {
        std::size_t e=p; while(e<v.size() && v[e]) ++e;
        if (e>p) { if(!first) ss << " | "; ss.write(reinterpret_cast<const char*>(&v[p]), static_cast<std::streamsize>(e-p)); first=false; }
        p=e+1;
    }
    return ss.str();
}
std::string cstr(const std::vector<std::uint8_t>& v) {
    std::size_t n=0; while(n<v.size() && v[n]) ++n;
    return std::string(reinterpret_cast<const char*>(v.data()), n);
}
bool containsI(const std::string& a,const std::string& b){return lower(a).find(lower(b))!=std::string::npos;}
bool statusOkay(const std::string& s){const std::string x=lower(s);return x.empty()||x=="okay"||x=="ok"||x.find("okay (")==0;}
std::string categoryFor(const DeviceTreeNodeInfo& n){
    const std::string s=lower(n.name+" "+n.compatible);
    if(s.find("iommu")!=std::string::npos||s.find("mmu")!=std::string::npos)return "IOMMU";
    if(s.find("dsp")!=std::string::npos||s.find("remoteproc")!=std::string::npos)return "DSP";
    if(s.find("mailbox")!=std::string::npos)return "Mailbox";
    if(s.find("mcasp")!=std::string::npos||s.find("audio")!=std::string::npos||s.find("sound")!=std::string::npos||s.find("codec")!=std::string::npos||s.find("tlv320")!=std::string::npos||s.find("cs42")!=std::string::npos||s.find("ak4")!=std::string::npos||s.find("wm8")!=std::string::npos||s.find("pcm")!=std::string::npos)return "Audio";
    if(s.find("uart")!=std::string::npos||s.find("serial")!=std::string::npos)return "UART";
    if(s.find("i2c")!=std::string::npos)return "I2C";
    if(s.find("spi")!=std::string::npos||s.find("qspi")!=std::string::npos)return "SPI";
    if(s.find("mmc")!=std::string::npos)return "MMC";
    if(s.find("gpio")!=std::string::npos)return "GPIO";
    if(s.find("usb")!=std::string::npos)return "USB";
    if(s.find("ethernet")!=std::string::npos||s.find("cpsw")!=std::string::npos)return "Ethernet";
    if(s.find("pwm")!=std::string::npos)return "PWM";
    if(s.find("can")!=std::string::npos)return "CAN";
    if(s.find("rtc")!=std::string::npos||s.find("mcp794")!=std::string::npos)return "RTC";
    if(s.find("touch")!=std::string::npos||s.find("ft5")!=std::string::npos)return "Touch";
    if(s.find("tps659")!=std::string::npos||s.find("pmic")!=std::string::npos)return "PMIC";
    if(s.find("tmp102")!=std::string::npos||s.find("temperature")!=std::string::npos)return "Sensor";
    if(s.find("ipu")!=std::string::npos)return "IPU";
    return "Other";
}
void addFact(AnalysisResult& out,const std::string& cat,const std::string& name,const std::string& value,const std::string& evidence){
    for(const auto& f:out.korgPlatformFacts) if(f.category==cat&&f.name==name&&f.value==value) return;
    KorgPlatformFact f; f.category=cat;f.name=name;f.value=value;f.confidence="DETECTED";f.evidence=evidence;out.korgPlatformFacts.push_back(f);
}
std::string hex64(std::uint64_t v){std::ostringstream s;s<<"0x"<<std::hex<<std::uppercase<<v;return s.str();}
}

bool DeviceTreeAnalyzer::analyze(const std::vector<std::uint8_t>& data,
                                 const std::string& path,
                                 std::uint64_t sourceOffset,
                                 bool fromCompressedEntry,
                                 AnalysisResult& out) {
    if (data.size() < 40 || be32(data,0) != FDT_MAGIC) return false;
    const std::uint32_t total=be32(data,4), offStruct=be32(data,8), offStrings=be32(data,12), version=be32(data,20), sizeStrings=be32(data,32), sizeStruct=be32(data,36);
    if(total<40||total>data.size()||offStruct>=total||offStrings>=total||static_cast<std::uint64_t>(offStrings)+sizeStrings>total||static_cast<std::uint64_t>(offStruct)+sizeStruct>total) return false;

    DeviceTreeInfo info; info.recognized=true; info.path=path; info.sourceOffset=sourceOffset; info.fromCompressedEntry=fromCompressedEntry; info.totalSize=total; info.version=version;
    std::size_t pos=offStruct, structEnd=offStruct+sizeStruct;
    std::vector<int> stack;
    struct WorkNode { DeviceTreeNodeInfo n; int parent=-1; std::map<std::string,std::vector<std::uint8_t>> props; };
    std::vector<WorkNode> work;
    bool sawEnd=false;

    auto strAt=[&](std::uint32_t off)->std::string{
        if(off>=sizeStrings)return {};
        std::size_t p=offStrings+off,e=p; while(e<offStrings+sizeStrings&&data[e])++e;
        if(e>=offStrings+sizeStrings)return {};
        return std::string(reinterpret_cast<const char*>(&data[p]),e-p);
    };

    while(pos+4<=structEnd){
        const std::uint32_t tok=be32(data,pos); pos+=4;
        if(tok==FDT_BEGIN_NODE){
            std::size_t e=pos; while(e<structEnd&&data[e])++e; if(e>=structEnd){info.warnings.push_back("Unterminated FDT node name.");break;}
            const std::string name(reinterpret_cast<const char*>(&data[pos]),e-pos); pos=align4(e+1); if(pos>structEnd)break;
            WorkNode w; w.n.name=name.empty()?"/":name; w.parent=stack.empty()?-1:stack.back();
            if(w.parent<0) w.n.path="/"; else { const std::string& pp=work[static_cast<std::size_t>(w.parent)].n.path; w.n.path=(pp=="/"?"/":pp+"/")+w.n.name; }
            work.push_back(w); stack.push_back(static_cast<int>(work.size()-1));
        } else if(tok==FDT_END_NODE){ if(!stack.empty())stack.pop_back(); }
        else if(tok==FDT_PROP){
            if(pos+8>structEnd||stack.empty())break; const std::uint32_t len=be32(data,pos), no=be32(data,pos+4); pos+=8; if(static_cast<std::uint64_t>(pos)+len>structEnd)break;
            const std::string pn=strAt(no); std::vector<std::uint8_t> v(data.begin()+static_cast<std::ptrdiff_t>(pos),data.begin()+static_cast<std::ptrdiff_t>(pos+len)); pos=align4(pos+len);
            if(!pn.empty())work[static_cast<std::size_t>(stack.back())].props[pn]=std::move(v);
        } else if(tok==FDT_NOP) continue;
        else if(tok==FDT_END){sawEnd=true;break;}
        else {info.warnings.push_back("Unknown FDT structure token "+std::to_string(tok)+".");break;}
    }
    if(!sawEnd) info.warnings.push_back("FDT_END token was not reached.");

    for(std::size_t i=0;i<work.size();++i){
        auto& w=work[i]; auto& n=w.n;
        auto it=w.props.find("compatible"); if(it!=w.props.end())n.compatible=joinCompat(it->second);
        it=w.props.find("status"); if(it!=w.props.end())n.status=cstr(it->second); if(n.status.empty())n.status="okay (implicit)";
        it=w.props.find("device_type"); if(it!=w.props.end())n.deviceType=cstr(it->second);
        unsigned addrCells=1,sizeCells=1;
        if(w.parent>=0){const auto& pp=work[static_cast<std::size_t>(w.parent)].props; auto a=pp.find("#address-cells");if(a!=pp.end()&&a->second.size()>=4)addrCells=be32(a->second,0);auto s=pp.find("#size-cells");if(s!=pp.end()&&s->second.size()>=4)sizeCells=be32(s->second,0);}
        it=w.props.find("reg"); if(it!=w.props.end() && addrCells>=1 && addrCells<=2 && it->second.size()>=4u*(addrCells+sizeCells)){
            n.hasReg=true;n.regAddress=be64cells(it->second,0,addrCells);if(sizeCells>=1&&sizeCells<=2)n.regSize=be64cells(it->second,4u*addrCells,sizeCells);
        }
        n.category=categoryFor(n);
        if(i==0){auto m=w.props.find("model");if(m!=w.props.end())info.model=cstr(m->second);info.rootCompatible=n.compatible;}
        if(statusOkay(n.status))++info.activeNodeCount;else if(containsI(n.status,"disabled"))++info.disabledNodeCount;
        info.nodes.push_back(n);
    }
    info.nodeCount=static_cast<std::uint32_t>(info.nodes.size());

    // Decode boot console arguments, aliases and concrete child devices on serial buses.
    for (std::size_t i=0;i<work.size();++i) {
        const auto& w=work[i];
        auto b=w.props.find("bootargs");
        if (b!=w.props.end() && info.bootargs.empty()) info.bootargs=cstr(b->second);

        if (w.n.path=="/aliases") {
            for (const auto& kv:w.props) {
                const std::string k=lower(kv.first);
                if (k.find("serial")==0 || k.find("i2c")==0 || k.find("spi")==0 || k.find("mmc")==0 || k.find("ethernet")==0) {
                    DeviceTreeAliasInfo a; a.name=kv.first; a.target=cstr(kv.second);
                    if (!a.target.empty()) info.aliases.push_back(a);
                }
            }
        }

        if (w.parent>=0) {
            const auto& parent=work[static_cast<std::size_t>(w.parent)];
            const std::string pn=lower(parent.n.name);
            std::string busType;
            if (pn.find("i2c@") == 0) busType="I2C";
            else if (pn.find("spi@") == 0 || pn.find("qspi@") == 0) busType="SPI";
            if (!busType.empty() && !w.n.compatible.empty()) {
                DeviceTreeBusDeviceInfo bd;
                bd.busType=busType; bd.busPath=parent.n.path; bd.nodePath=w.n.path; bd.name=w.n.name;
                bd.compatible=w.n.compatible; bd.status=w.n.status; bd.hasAddress=w.n.hasReg; bd.address=w.n.regAddress;
                auto sf=w.props.find("spi-max-frequency");
                if (sf!=w.props.end() && sf->second.size()>=4) { bd.hasSpiMaxFrequency=true; bd.spiMaxFrequency=be32(sf->second,0); }
                info.busDevices.push_back(bd);
            }
        }
    }
    std::sort(info.aliases.begin(),info.aliases.end(),[](const DeviceTreeAliasInfo& a,const DeviceTreeAliasInfo& b){return a.name<b.name;});

    std::set<std::string> compatSeen;
    for(const auto& n:info.nodes){
        if(containsI(n.compatible,"ti,dra7")||containsI(n.compatible,"ti,dra742")) compatSeen.insert("TI DRA7 family");
    }
    if(!compatSeen.empty()) { info.platformHint=*compatSeen.begin(); addFact(out,"Hardware","SoC family","TI DRA7 family","Device-tree compatible strings contain ti,dra7 / ti,dra742 peripherals in "+path); }

    for(const auto& n:info.nodes){
        if(!statusOkay(n.status))continue;
        const std::string ev="DTB node "+n.path+" compatible="+n.compatible;
        if(containsI(n.compatible,"ti,dra7-dsp-iommu")) addFact(out,"DSP","DSP IOMMU",(n.hasReg?hex64(n.regAddress)+" ":"")+n.compatible,ev);
        else if(containsI(n.compatible,"ti,dra7-dsp")) addFact(out,"DSP","Active DSP",(n.hasReg?hex64(n.regAddress)+" ":"")+n.compatible,ev);
        else if(containsI(n.compatible,"ti,omap4-mailbox")) addFact(out,"DSP","Active mailbox",(n.hasReg?hex64(n.regAddress)+" ":"")+n.path,ev);
        else if(containsI(n.compatible,"ti,dra7-mcasp-audio")) addFact(out,"Audio","Active McASP",(n.hasReg?hex64(n.regAddress)+" ":"")+n.path,ev);
        else if(containsI(n.compatible,"ti,dra7-cpsw")) addFact(out,"Hardware","Ethernet CPSW",(n.hasReg?hex64(n.regAddress)+" ":"")+n.path,ev);
    }

    for (const auto& bd:info.busDevices) {
        if (!statusOkay(bd.status)) continue;
        const std::string ev="DTB bus child "+bd.nodePath+" compatible="+bd.compatible;
        std::string loc=bd.busPath; if (bd.hasAddress) loc += " addr="+hex64(bd.address);
        if (containsI(bd.compatible,"tlv320aic3104")) addFact(out,"Audio","Audio codec",loc+" TI TLV320AIC3104",ev);
        else if (containsI(bd.compatible,"tps65917")) addFact(out,"Hardware","Power-management IC",loc+" TPS65917",ev);
        else if (containsI(bd.compatible,"tmp102")) addFact(out,"Hardware","Temperature sensor",loc+" TMP102",ev);
        else if (containsI(bd.compatible,"mcp7941")) addFact(out,"Hardware","RTC",loc+" MCP7941x",ev);
        else if (containsI(bd.compatible,"edt-ft5") || containsI(bd.compatible,"ft5406")) addFact(out,"Hardware","Touch controller",loc+" EDT FT5x06",ev);
    }
    if (!info.bootargs.empty()) addFact(out,"Boot","Kernel bootargs",info.bootargs,"DTB bootargs property in "+path);

    out.deviceTrees.push_back(info);
    out.embedded.push_back({"Flattened Device Tree (DTB)",sourceOffset,"FDT magic 0xD00DFEED; "+std::to_string(info.nodeCount)+" nodes; "+info.platformHint});
    out.notes.push_back("Device-tree analysis: "+path+" -> "+std::to_string(info.nodeCount)+" nodes, "+std::to_string(info.activeNodeCount)+" active/implicit, "+std::to_string(info.disabledNodeCount)+" disabled.");
    return true;
}
