#include "reverse/ArmDisassembler.h"
#include "core/Utils.h"
#include <algorithm>
#include <iomanip>
#include <sstream>

namespace {
std::string hx(std::uint64_t v) {
    std::ostringstream s; s << "0x" << std::hex << std::uppercase << v; return s.str();
}
std::string reg(unsigned r) {
    if (r == 13) return "sp";
    if (r == 14) return "lr";
    if (r == 15) return "pc";
    return "r" + std::to_string(r);
}
std::int32_t signExtend(std::uint32_t v, unsigned bits) {
    const std::uint32_t m = 1u << (bits - 1);
    return static_cast<std::int32_t>((v ^ m) - m);
}
std::string armCond(unsigned c) {
    static const char* n[] = {"eq","ne","cs","cc","mi","pl","vs","vc","hi","ls","ge","lt","gt","le","","nv"};
    return n[c & 15u];
}
std::string arm32(std::uint32_t w, std::uint64_t pc) {
    const unsigned cond = w >> 28;
    const std::string cs = armCond(cond);
    if ((w & 0x0FFFFFF0u) == 0x012FFF10u) return "bx" + cs + " " + reg(w & 15u);
    if ((w & 0x0E000000u) == 0x0A000000u) {
        const bool link = (w & 0x01000000u) != 0;
        const std::int32_t off = signExtend(w & 0x00FFFFFFu,24) << 2;
        return std::string(link ? "bl" : "b") + cs + " " + hx(static_cast<std::uint64_t>(static_cast<std::int64_t>(pc) + 8 + off));
    }
    if ((w & 0x0FE00000u) == 0x03A00000u) {
        const unsigned rd=(w>>12)&15u, imm=w&0xFFu, rot=((w>>8)&15u)*2u;
        const std::uint32_t val = rot ? ((imm >> rot) | (imm << (32-rot))) : imm;
        return "mov" + cs + " " + reg(rd) + ", #" + hx(val);
    }
    if ((w & 0x0FE00000u) == 0x02800000u || (w & 0x0FE00000u) == 0x02400000u) {
        const bool sub=(w & 0x00400000u)==0;
        const unsigned rn=(w>>16)&15u, rd=(w>>12)&15u, imm=w&0xFFFu;
        return std::string(sub?"sub":"add") + cs + " " + reg(rd) + ", " + reg(rn) + ", #" + hx(imm);
    }
    if ((w & 0x0FF00000u) == 0x03500000u) {
        const unsigned rn=(w>>16)&15u, imm=w&0xFFFu;
        return "cmp" + cs + " " + reg(rn) + ", #" + hx(imm);
    }
    if ((w & 0x0C000000u) == 0x04000000u) {
        const bool load=(w & 0x00100000u)!=0, byte=(w&0x00400000u)!=0;
        const unsigned rn=(w>>16)&15u, rd=(w>>12)&15u, imm=w&0xFFFu;
        return std::string(load?(byte?"ldrb":"ldr"):(byte?"strb":"str")) + cs + " " + reg(rd) + ", [" + reg(rn) + ", #" + hx(imm) + "]";
    }
    if ((w & 0x0FFF0000u) == 0x092D0000u) return "push" + cs + " {reglist=" + hx(w & 0xFFFFu) + "}";
    if ((w & 0x0FFF0000u) == 0x08BD0000u) return "pop" + cs + " {reglist=" + hx(w & 0xFFFFu) + "}";
    std::ostringstream s; s << ".word 0x" << std::hex << std::setw(8) << std::setfill('0') << w; return s.str();
}
std::string thumb16(std::uint16_t h, std::uint64_t pc) {
    if (h == 0x4770) return "bx lr";
    if (h == 0x46C0 || h == 0xBF00) return "nop";
    if ((h & 0xFE00u) == 0xB400u) return "push {reglist=" + hx(h & 0x1FFu) + "}";
    if ((h & 0xFE00u) == 0xBC00u) return "pop {reglist=" + hx(h & 0x1FFu) + "}";
    if ((h & 0xF800u) == 0x2000u) return "movs " + reg((h>>8)&7u) + ", #" + hx(h&0xFFu);
    if ((h & 0xF800u) == 0x2800u) return "cmp " + reg((h>>8)&7u) + ", #" + hx(h&0xFFu);
    if ((h & 0xF800u) == 0x3000u) return "adds " + reg((h>>8)&7u) + ", #" + hx(h&0xFFu);
    if ((h & 0xF800u) == 0x3800u) return "subs " + reg((h>>8)&7u) + ", #" + hx(h&0xFFu);
    if ((h & 0xF000u) == 0xD000u && (h & 0x0F00u) != 0x0F00u) {
        const unsigned cond=(h>>8)&15u; const std::int32_t off=signExtend(h&0xFFu,8)<<1;
        return "b" + armCond(cond) + " " + hx(static_cast<std::uint64_t>(static_cast<std::int64_t>(pc)+4+off));
    }
    if ((h & 0xF800u) == 0xE000u) {
        const std::int32_t off=signExtend(h&0x7FFu,11)<<1;
        return "b " + hx(static_cast<std::uint64_t>(static_cast<std::int64_t>(pc)+4+off));
    }
    if ((h & 0xF800u) == 0x6800u || (h & 0xF800u) == 0x6000u) {
        const bool load=(h&0x0800u)!=0; const unsigned imm=((h>>6)&31u)*4u, rn=(h>>3)&7u, rd=h&7u;
        return std::string(load?"ldr":"str") + " " + reg(rd) + ", [" + reg(rn) + ", #" + hx(imm) + "]";
    }
    std::ostringstream s; s << ".hword 0x" << std::hex << std::setw(4) << std::setfill('0') << h; return s.str();
}
std::string pseudoFromAsm(const std::string& a) {
    if (a.find("push") == 0) return "// function prologue / save registers";
    if (a.find("pop") == 0) return "// restore registers";
    if (a == "bx lr") return "return;";
    if (a.find("bl ") == 0) return "call(" + a.substr(3) + ");";
    if (a.find("cmp ") == 0 || a.find("cmpeq ") == 0) return "// compare: " + a;
    if (a.size() > 1 && a[0]=='b' && a.find("bl ")!=0) return "// branch: " + a;
    if (a.find("mov") == 0 || a.find("add") == 0 || a.find("sub") == 0 || a.find("ldr") == 0 || a.find("str") == 0)
        return "// " + a;
    return std::string();
}
}

void ArmDisassembler::decodeFunction(const std::vector<std::uint8_t>& data,
                                     std::uint64_t fileOffset,
                                     std::uint64_t virtualAddress,
                                     std::uint64_t size,
                                     bool thumb,
                                     FunctionInfo& out,
                                     std::size_t maxInstructions) {
    if (fileOffset >= data.size()) return;
    const std::uint64_t maxBytes = size ? size : (thumb ? 48u : 96u);
    const std::uint64_t end = std::min<std::uint64_t>(data.size(), fileOffset + maxBytes);
    std::uint64_t o=fileOffset, pc=virtualAddress;
    for (std::size_t i=0; i<maxInstructions && o<end; ++i) {
        std::string a;
        unsigned n=thumb?2u:4u;
        if (o+n>end) break;
        if (thumb) a=thumb16(rd16le(data,static_cast<std::size_t>(o)),pc);
        else a=arm32(rd32le(data,static_cast<std::size_t>(o)),pc);
        std::ostringstream line; line << hx(pc) << "  " << a;
        out.disassembly.push_back(line.str());
        const std::string p=pseudoFromAsm(a); if (!p.empty()) out.pseudocode.push_back(p);
        o+=n; pc+=n;
        if (a=="bx lr") break;
    }
}
