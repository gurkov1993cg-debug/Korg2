#include "reverse/ElfAnalyzer.h"
#include "core/Utils.h"
#include "detect/LanguageDetector.h"
#include "reverse/ArmDisassembler.h"
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#ifdef __GNUG__
#include <cxxabi.h>
#endif

namespace {
std::uint64_t r64le(const std::vector<std::uint8_t>& d,std::size_t o){
    if(o+8>d.size())return 0; std::uint64_t v=0; for(unsigned i=0;i<8;++i)v|=static_cast<std::uint64_t>(d[o+i])<<(8*i); return v;
}
std::uint64_t r64be(const std::vector<std::uint8_t>& d,std::size_t o){
    if(o+8>d.size())return 0; std::uint64_t v=0; for(unsigned i=0;i<8;++i)v=(v<<8)|d[o+i]; return v;
}
std::string arch(std::uint16_t m){
    switch(m){case 3:return"x86";case 8:return"MIPS";case 20:return"PowerPC";case 21:return"PowerPC64";case 40:return"ARM";case 42:return"SuperH";case 62:return"x86_64";case 140:return"TI TMS320C6000";case 183:return"AArch64";case 243:return"RISC-V";default:return"ELF machine "+std::to_string(m);} }
std::string secType(std::uint32_t t){
    switch(t){case 0:return"NULL";case 1:return"PROGBITS";case 2:return"SYMTAB";case 3:return"STRTAB";case 4:return"RELA";case 5:return"HASH";case 6:return"DYNAMIC";case 7:return"NOTE";case 8:return"NOBITS";case 9:return"REL";case 11:return"DYNSYM";default:return std::to_string(t);} }
std::string symType(unsigned t){switch(t){case 0:return"NOTYPE";case 1:return"OBJECT";case 2:return"FUNC";case 3:return"SECTION";case 4:return"FILE";case 5:return"COMMON";case 6:return"TLS";default:return std::to_string(t);} }
std::string bindType(unsigned b){switch(b){case 0:return"LOCAL";case 1:return"GLOBAL";case 2:return"WEAK";default:return std::to_string(b);} }
std::string osabi(unsigned x){switch(x){case 0:return"System V";case 3:return"GNU/Linux";case 6:return"Solaris";case 9:return"FreeBSD";case 97:return"ARM";default:return"OSABI "+std::to_string(x);} }
std::string demangle(const std::string& s){
#ifdef __GNUG__
    if(s.size()>2 && s[0]=='_' && s[1]=='Z'){int st=0; char* p=abi::__cxa_demangle(s.c_str(),nullptr,nullptr,&st); if(st==0&&p){std::string r(p); std::free(p); return r;}}
#endif
    return std::string();
}
struct S {std::uint32_t name=0,type=0,link=0,info=0;std::uint64_t flags=0,addr=0,off=0,size=0,entsize=0;std::string n;};
bool range(std::uint64_t o,std::uint64_t n,std::size_t total){return o<=total && n<=total-o;}
std::string cstr(const std::vector<std::uint8_t>& d,std::uint64_t base,std::uint64_t size,std::uint32_t off){
    if(off>=size||base+off>=d.size())return{}; std::size_t p=static_cast<std::size_t>(base+off), e=static_cast<std::size_t>(std::min<std::uint64_t>(d.size(),base+size)); std::string s;
    while(p<e&&d[p]){unsigned char c=d[p++]; if(c<0x20||c>0x7e) return{}; s.push_back(static_cast<char>(c)); if(s.size()>512)break;} return s;
}
void hit(std::vector<Candidate>& v,const std::string& name,int w,const std::string& kind,const std::string& value){
    auto it=std::find_if(v.begin(),v.end(),[&](const Candidate& c){return c.name==name;}); if(it==v.end()){Candidate c;c.name=name;v.push_back(c);it=v.end()-1;} it->score+=w;it->evidence.push_back({kind,value,w});
}
void finish(std::vector<Candidate>& v){for(auto&c:v){c.score=std::min(c.score,100);if(c.score>=80)c.confidence="Detected";else if(c.score>=45)c.confidence="Probable";else c.confidence="Possible";}std::sort(v.begin(),v.end(),[](const Candidate&a,const Candidate&b){return a.score>b.score;});}
void addCompilerComment(ExecutableInfo& out,const std::string& s){if(s.empty())return;if(std::find(out.compilerComments.begin(),out.compilerComments.end(),s)==out.compilerComments.end())out.compilerComments.push_back(s); if(s.find("GCC")!=std::string::npos)hit(out.toolchains,"GCC",90,".comment",s); if(s.find("clang")!=std::string::npos||s.find("LLVM")!=std::string::npos)hit(out.toolchains,"Clang/LLVM",90,".comment",s);}
std::uint64_t virtToOff(const std::vector<S>& ss,std::uint64_t a){for(const auto&s:ss)if(s.size&&a>=s.addr&&a<s.addr+s.size&&s.type!=8)return s.off+(a-s.addr);return 0;}
std::vector<std::string> nulStrings(const std::vector<std::uint8_t>& d,std::uint64_t off,std::uint64_t size){std::vector<std::string> v;if(!range(off,size,d.size()))return v;std::string s;for(std::uint64_t i=0;i<size;++i){unsigned char c=d[static_cast<std::size_t>(off+i)];if(c==0){if(!s.empty())v.push_back(s);s.clear();}else if(c>=0x20&&c<=0x7e){if(s.size()<512)s.push_back(static_cast<char>(c));}else s.clear();}if(!s.empty())v.push_back(s);return v;}
}

bool ElfAnalyzer::analyze(const std::vector<std::uint8_t>& d,const std::string& logicalPath,std::uint64_t sourceOffset,bool compressed,ExecutableInfo& out){
    if(d.size()<52||!startsWith(d,{0x7f,'E','L','F'}))return false;
    const bool is64=d[4]==2, le=d[5]!=2; if(d[4]!=1&&d[4]!=2)return false;
    auto r16=[&](std::size_t o){return le?rd16le(d,o):rd16be(d,o);}; auto r32=[&](std::size_t o){return le?rd32le(d,o):rd32be(d,o);}; auto r64=[&](std::size_t o){return le?r64le(d,o):r64be(d,o);};
    const std::uint16_t machine=r16(18), etype=r16(16); const std::uint64_t entry=is64?r64(24):r32(24); const std::uint64_t phoff=is64?r64(32):r32(28), shoff=is64?r64(40):r32(32); const std::uint32_t flags=is64?r32(48):r32(36); const std::uint16_t phents=is64?r16(54):r16(42), phnum=is64?r16(56):r16(44), shents=is64?r16(58):r16(46), shnum=is64?r16(60):r16(48), shstr=is64?r16(62):r16(50);
    out.path=logicalPath;out.format="ELF";out.architecture=arch(machine);out.bits=is64?64:32;out.endian=le?"Little":"Big";out.entryPoint=entry;out.sourceOffset=sourceOffset;out.fromCompressedEntry=compressed;out.unpackedSize=d.size();
    out.abi=osabi(d[7]); if(machine==40){const unsigned ev=(flags>>24)&0xffu;if(ev)out.abi += ", ARM EABI"+std::to_string(ev);} if(machine==140)out.abi += ", TI C6000 ELF";
    // Program interpreter
    for(unsigned i=0;i<phnum&&phents;++i){std::uint64_t o=phoff+static_cast<std::uint64_t>(i)*phents;if(!range(o,phents,d.size()))break;std::uint32_t t=r32(static_cast<std::size_t>(o));if(t==3){std::uint64_t po=is64?r64(static_cast<std::size_t>(o+8)):r32(static_cast<std::size_t>(o+4));std::uint64_t ps=is64?r64(static_cast<std::size_t>(o+32)):r32(static_cast<std::size_t>(o+16));if(range(po,ps,d.size())){for(std::uint64_t j=0;j<ps&&d[static_cast<std::size_t>(po+j)];++j)out.interpreter.push_back(static_cast<char>(d[static_cast<std::size_t>(po+j)]));}}}
    // Sections
    std::vector<S> ss; ss.resize(shnum); for(unsigned i=0;i<shnum&&shents;++i){std::uint64_t o=shoff+static_cast<std::uint64_t>(i)*shents;if(!range(o,shents,d.size())){out.warnings.push_back("Section table truncated");break;}S&s=ss[i];s.name=r32(static_cast<std::size_t>(o));s.type=r32(static_cast<std::size_t>(o+4));if(is64){s.flags=r64(static_cast<std::size_t>(o+8));s.addr=r64(static_cast<std::size_t>(o+16));s.off=r64(static_cast<std::size_t>(o+24));s.size=r64(static_cast<std::size_t>(o+32));s.link=r32(static_cast<std::size_t>(o+40));s.info=r32(static_cast<std::size_t>(o+44));s.entsize=r64(static_cast<std::size_t>(o+56));}else{s.flags=r32(static_cast<std::size_t>(o+8));s.addr=r32(static_cast<std::size_t>(o+12));s.off=r32(static_cast<std::size_t>(o+16));s.size=r32(static_cast<std::size_t>(o+20));s.link=r32(static_cast<std::size_t>(o+24));s.info=r32(static_cast<std::size_t>(o+28));s.entsize=r32(static_cast<std::size_t>(o+36));}}
    if(shstr<ss.size()&&range(ss[shstr].off,ss[shstr].size,d.size()))for(auto&s:ss)s.n=cstr(d,ss[shstr].off,ss[shstr].size,s.name);
    bool hasSymtab=false, hasDynsym=false; for(const auto&s:ss){BinarySectionInfo b;b.name=s.n;b.type=secType(s.type);b.address=s.addr;b.offset=s.off;b.size=s.size;b.flags=s.flags;out.sections.push_back(b);if(s.n==".symtab")hasSymtab=true;if(s.n==".dynsym")hasDynsym=true;if(s.n==".comment")for(const auto&x:nulStrings(d,s.off,s.size))addCompilerComment(out,x);}
    out.stripped=!hasSymtab;
    AnalysisResult fp;fp.format="ELF";fp.architecture=out.architecture;fp.endian=out.endian;fp.bits=out.bits;LanguageDetector::analyze(d,fp);out.languages=fp.languages;out.toolchains=fp.toolchains;out.platforms=fp.platforms;
    // Symbols
    std::set<std::string> seenFunc;
    for(std::size_t si=0;si<ss.size();++si){const S&s=ss[si];if(s.type!=2&&s.type!=11)continue;if(s.link>=ss.size())continue;const S&str=ss[s.link];const std::uint64_t es=s.entsize?s.entsize:(is64?24:16);if(!es||!range(s.off,s.size,d.size())||!range(str.off,str.size,d.size()))continue;for(std::uint64_t p=0;p+es<=s.size;p+=es){const std::uint64_t o=s.off+p;std::uint32_t no=r32(static_cast<std::size_t>(o));std::uint64_t val=0,sz=0;unsigned info=0;std::uint16_t shndx=0;if(is64){info=d[static_cast<std::size_t>(o+4)];shndx=r16(static_cast<std::size_t>(o+6));val=r64(static_cast<std::size_t>(o+8));sz=r64(static_cast<std::size_t>(o+16));}else{val=r32(static_cast<std::size_t>(o+4));sz=r32(static_cast<std::size_t>(o+8));info=d[static_cast<std::size_t>(o+12)];shndx=r16(static_cast<std::size_t>(o+14));}const std::string name=cstr(d,str.off,str.size,no);if(name.empty())continue;BinarySymbolInfo bi;bi.name=name;bi.demangled=demangle(name);bi.address=val;bi.size=sz;bi.type=symType(info&15u);bi.binding=bindType(info>>4);bi.undefined=(shndx==0);if(bi.undefined&&(bi.binding=="GLOBAL"||bi.binding=="WEAK")){if(out.imports.size()<200)out.imports.push_back(bi);}else if(!bi.undefined&&(bi.binding=="GLOBAL"||bi.binding=="WEAK")){if(out.exports.size()<200)out.exports.push_back(bi);}if((info&15u)==2&&!bi.undefined&&out.functions.size()<160&&seenFunc.insert(name).second){FunctionInfo f;f.name=name;f.demangled=bi.demangled;f.address=val;f.size=sz;f.thumb=(machine==40)&&((val&1u)!=0);const std::uint64_t codeAddr=f.thumb?(val&~std::uint64_t(1)):val;f.fileOffset=virtToOff(ss,codeAddr);out.functions.push_back(f);}if(name.compare(0,2,"_Z")==0 || name.find("_ZTV")!=std::string::npos || name=="__cxa_throw" || name.find("__gxx_personality")!=std::string::npos)
            hit(out.languages,"C++",50,"ELF symbol",name);if(name.find("QObject")!=std::string::npos||name.find("QApplication")!=std::string::npos)hit(out.languages,"C++",35,"Qt C++ symbol",name);if(name.find("__aeabi_")!=std::string::npos)hit(out.platforms,"ARM EABI",50,"ELF symbol",name);}}
    if(machine==40){hit(out.platforms,"ARM EABI",60,"ELF header",out.abi);}
    if(machine==140){hit(out.platforms,"TI C6000 DSP",95,"ELF e_machine","0x8C / 140");}
    bool strongNonC=false;for(const auto&c:out.languages)if(c.name!="C++"&&c.name!="C or C++ (not distinguishable yet)"&&c.score>=70)strongNonC=true;
    bool cpp=false;for(const auto&c:out.languages)if(c.name=="C++"&&c.score>=45)cpp=true;
    if(!strongNonC&&!cpp){hit(out.languages,"C",48,"native ELF heuristic","no managed/runtime or C++ ABI evidence found");}
    if(hasDynsym)hit(out.toolchains,"GNU-compatible ELF toolchain",30,"section",".dynsym");
    finish(out.languages);finish(out.toolchains);finish(out.platforms);
    // Sort and disassemble first useful ARM functions. Prefer named non-underscore functions.
    std::stable_sort(out.functions.begin(),out.functions.end(),[](const FunctionInfo&a,const FunctionInfo&b){const bool aa=!a.name.empty()&&a.name[0]!='_';const bool bb=!b.name.empty()&&b.name[0]!='_';if(aa!=bb)return aa>bb;return a.address<b.address;});
    if(machine==40){std::size_t decoded=0;for(auto&f:out.functions){if(decoded>=24)break;if(!f.fileOffset||f.fileOffset>=d.size())continue;ArmDisassembler::decodeFunction(d,f.fileOffset,f.thumb?(f.address&~std::uint64_t(1)):f.address,f.size,f.thumb,f,24);if(!f.disassembly.empty())++decoded;}if(out.functions.empty()){FunctionInfo f;f.name="<entry_point>";f.address=entry;f.fileOffset=virtToOff(ss,entry);if(f.fileOffset){ArmDisassembler::decodeFunction(d,f.fileOffset,entry,0,false,f,24);out.functions.push_back(f);}}}
    if(out.stripped)out.warnings.push_back("Static symbol table (.symtab) is absent; original function/local names may have been stripped.");
    if(machine==140)out.warnings.push_back("TI C6000 architecture detected; language/toolchain fingerprints are analyzed, but C6x instruction decoding is not implemented yet.");
    if(etype==3)out.warnings.push_back("ELF type is shared object / PIE; addresses may be relocation-relative at runtime.");
    return true;
}
