#pragma once
#include "core/Model.h"
#include <cstdint>
#include <vector>

class ArmDisassembler {
public:
    static void decodeFunction(const std::vector<std::uint8_t>& data,
                               std::uint64_t fileOffset,
                               std::uint64_t virtualAddress,
                               std::uint64_t size,
                               bool thumb,
                               FunctionInfo& out,
                               std::size_t maxInstructions = 24);
};
