#pragma once
#include "core/Model.h"
#include <cstdint>
#include <vector>

class FirmwareExecutableScanner {
public:
    static void analyze(const std::vector<std::uint8_t>& data, AnalysisResult& out);
};
